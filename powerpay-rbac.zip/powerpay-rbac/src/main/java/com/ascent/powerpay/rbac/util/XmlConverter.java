package com.ascent.powerpay.rbac.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.util.List;
import java.util.Map;

public class XmlConverter {

    private static final XmlMapper xmlMapper = new XmlMapper();

    private static ObjectWriter objectWriter = xmlMapper.writer().withRootName("");


    public static String convertMapToXml(List<Map<String, Object>> data, String header) {
        data.add(Map.of("header", header));
        StringBuilder xml = new StringBuilder();
        for (Map<String, Object> map : data) {
            String x = toXML(map);
            xml.append(x.replace("<>", "").replace("</>", ""));
        }
        String XML_TAG = "<?xml version=\"1.0\"?><data>";
        return XML_TAG + xml.toString() + "</data>";
    }


    private static String toXML(Object allData) {
        try {
            return objectWriter.writeValueAsString(allData);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Failed to convert to XML", e);
        }
    }


}
