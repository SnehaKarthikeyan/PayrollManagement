package com.example.privilege.controller;

import com.example.privilege.exception.NotFoundException;
import com.example.privilege.model.MenuPrivilege;
import com.example.privilege.repository.ManagedEntityRepository;
import com.example.privilege.repository.MenuPrivilegeRepository;
import com.example.privilege.service.PrivilegeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;


@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/privilege", "/manage/privilege"})
public class PrivilegeController {

    @Autowired
    private PrivilegeService privilegeService;

    @CrossOrigin
    @PostMapping("/managedentity/{managedEntityCode}")
    public ResponseEntity<?> savePrivilege(@PathVariable String managedEntityCode, @RequestBody List<MenuPrivilege> menuPrivilegeList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<MenuPrivilege> menuPrivileges = privilegeService.savePrivilege(managedEntityCode,menuPrivilegeList);
             if(menuPrivileges.size()==0)
                 responseEntity = new ResponseEntity<String>(
                         "Unable to save Privilege ",
                         HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<MenuPrivilege>>(
                    menuPrivileges, HttpStatus.CREATED); //201-created}

        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Privilege ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @PostMapping("/managedentity/{managedEntityCode}/privilege/{privilegeId}")
    public ResponseEntity<?> updateOrCopyById(@RequestBody MenuPrivilege menuPrivilege, @PathVariable String managedEntityCode,@PathVariable String privilegeId) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            MenuPrivilege menuPrivilegeDB = privilegeService.findPrivilegeById(managedEntityCode,privilegeId);
            String Id= privilegeService.getManagedEntity(managedEntityCode);
            menuPrivilegeDB.setManagedEntityId(Id);
            menuPrivilegeDB.setName( menuPrivilege.getName());
            menuPrivilegeDB.setActive(menuPrivilege.isActive());
            menuPrivilegeDB.setMenuOrder( menuPrivilege.getMenuOrder());
            menuPrivilegeDB.setCode( menuPrivilege.getCode());
            menuPrivilegeDB.setParent( menuPrivilege.getParent());
            privilegeService.updatePrivilege(menuPrivilegeDB);
            resp = new ResponseEntity<MenuPrivilege>( menuPrivilege, HttpStatus.CREATED); //202-accepted
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Privilege doesn't exist", HttpStatus.BAD_REQUEST);
        }

        return resp;
    }

    @GetMapping("/managedentity/{managedEntityCode}/privilege")
        public ResponseEntity<?> getAllPrivileges(@PathVariable("managedEntityCode") String managedEntityCode,
                                                  @RequestParam(required = false) String privilegeCode) throws NotFoundException {
            ResponseEntity<?> resp=null;

                if(privilegeCode == null || privilegeCode.length() == 0) {
                    List<MenuPrivilege> menuPrivilegeList = privilegeService.getPrivileges(managedEntityCode);
                    try{
                    resp= new ResponseEntity<List<MenuPrivilege>>(
                            menuPrivilegeList, HttpStatus.OK);
                }
                    catch (Exception exception){
                        log.error(exception.getMessage(),exception);
                        resp = new ResponseEntity<String>("Privilege doesn't exist", HttpStatus.BAD_REQUEST);
                    }
                    }
                else{
                   resp= getPrivilegeByCode(managedEntityCode,privilegeCode);
                }
                return resp;
        }

    @GetMapping("/managedentity/{managedEntityCode}/privilege/{privilegeId}")
    public ResponseEntity<?> getPrivilegeById(@PathVariable String managedEntityCode,@PathVariable String privilegeId ) {
        ResponseEntity<?> resp=null;
        try {

            MenuPrivilege menuPrivilege=privilegeService.findPrivilegeById(managedEntityCode,privilegeId);
            if(menuPrivilege.getId()==null)
            {
                resp = new ResponseEntity<String>(
                        "Unable to save Privilege ",
                        HttpStatus.BAD_REQUEST);

            }
            resp= new ResponseEntity<MenuPrivilege>(menuPrivilege, HttpStatus.OK);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>(
                    "Unable to get Privileges",
                    HttpStatus.BAD_REQUEST);
        }
        return resp;
    }

    @NotNull
    public ResponseEntity<?> getPrivilegeByCode(@PathVariable String managedEntityCode,@RequestParam(required = false)String privilegeCode) {
        ResponseEntity<?> resp=null;
        try {

            MenuPrivilege menuPrivilege=privilegeService.findPrivilegeByCode(managedEntityCode,privilegeCode);
            if(menuPrivilege.getCode()==null)
            {
                resp = new ResponseEntity<String>(
                        "Unable to save Privilege ",
                        HttpStatus.BAD_REQUEST);

            }
            resp= new ResponseEntity<MenuPrivilege>(menuPrivilege, HttpStatus.OK);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>(
                    "Unable to get Privileges",
                    HttpStatus.BAD_REQUEST);
        }
        return resp;
    }



    @PutMapping("/managedentity/{managedEntityCode}/privilege/{privilegeCode}")
    public ResponseEntity<?> updateOrCopyByCode(@RequestBody MenuPrivilege menuPrivilege, @PathVariable String managedEntityCode,@PathVariable String privilegeCode) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            MenuPrivilege menuPrivilegeDB = privilegeService.findPrivilegeByCode(managedEntityCode,privilegeCode);
            String Id= privilegeService.getManagedEntity(managedEntityCode);
            menuPrivilegeDB.setManagedEntityId(Id);
            menuPrivilegeDB.setName( menuPrivilege.getName());
            menuPrivilegeDB.setActive( menuPrivilege.isActive());
            menuPrivilegeDB.setMenuOrder( menuPrivilege.getMenuOrder());
            menuPrivilegeDB.setParent( menuPrivilege.getParent());
            privilegeService.updatePrivilege(menuPrivilegeDB);
            resp = new ResponseEntity<MenuPrivilege>( menuPrivilege, HttpStatus.OK);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Privilege doesn't exist", HttpStatus.BAD_REQUEST);
        }

        return resp;
    }

     @PutMapping("/managedentity/{managedEntityCode}/privilege/{parentCode}/{childCode}")
    public ResponseEntity<?> mapPrivilegeItem(@PathVariable String managedEntityCode,@PathVariable String parentCode , @PathVariable String childCode) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{

            MenuPrivilege menuPrivilege = privilegeService.mapPrivilegeItem(managedEntityCode,parentCode,childCode);
            resp = new ResponseEntity<MenuPrivilege>(menuPrivilege,HttpStatus.ACCEPTED); //202-accepted
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Privilege doesn't exist", HttpStatus.BAD_REQUEST);
        }

        return resp;
    }


    @DeleteMapping("/managedentity/{managedEntityCode}/privilege")
    public ResponseEntity<String> deleteOnePrivilege(@PathVariable String managedEntityCode,@RequestParam String privilegeCode){

        ResponseEntity<String> responseEntity= null;
        try {
            privilegeService.deleteOnePrivilegeByCode(managedEntityCode,privilegeCode);
            responseEntity= new ResponseEntity<String> (
                    "privilege  '"+privilegeCode+"' deleted",HttpStatus.OK);

        }

        catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Privilege", HttpStatus.BAD_REQUEST);
        }

        return responseEntity;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/privilegeId/internal/{privilegeId}")
    public ResponseEntity<String> deleteOnePrivilegeById(@PathVariable String managedEntityCode,@PathVariable String privilegeId){
        ResponseEntity<String> responseEntity= null;
        try {
            privilegeService.deleteOnePrivilegeById(managedEntityCode,privilegeId);
            responseEntity= new ResponseEntity<String> (
                    "privilege  '"+privilegeId+"' deleted",HttpStatus.OK);

        }
        catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Privilege", HttpStatus.BAD_REQUEST);
        }

        return responseEntity;
    }

    }


