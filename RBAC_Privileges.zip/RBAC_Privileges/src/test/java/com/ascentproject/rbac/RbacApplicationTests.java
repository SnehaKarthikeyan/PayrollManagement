package com.ascentproject.rbac;

import com.ascentproject.rbac.model.Privilege;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.junit.Assert;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.net.URI;
import java.net.URISyntaxException;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RbacApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@Rollback
@Transactional
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RbacApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	@Contract(pure = true)
	private @NotNull String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	@Order(1)
	public void testGetAllPrivileges() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/managedEntity/api/v2/16/privilege",
				HttpMethod.GET, entity, String.class);
		assertNotNull(response.getBody());
		System.out.println(response.getBody());
	}

	@Test
	@Order(2)
	public void testGetPrivilegeById() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/managedEntity/api/v2/16/privilege/1234",
				HttpMethod.GET, entity, String.class);
		assertNotNull(response.getBody());
		System.out.println(response.getBody());
	}

	@Test
	@Order(3)
	public void testCreatePrivilege() throws URISyntaxException {
		final String baseUrl = getRootUrl() + "/managedEntity/api/v2/16/privilege/";
		URI uri = new URI(baseUrl);
		Privilege privilege = new Privilege();
		privilege.setId(123L);
		privilege.setFunction("Configuration");
		privilege.setAction("Read And Write");
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-COM-PERSIST", "true");
		HttpEntity<Privilege> request = new HttpEntity<>(privilege, headers);
		ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
		Assert.assertEquals(201, result.getStatusCodeValue());

		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/managedEntity/api/v2/16/privilege/123",
				HttpMethod.GET, entity, String.class);
		assertNotNull(response.getBody());
		System.out.println(response.getBody());
	}

	@Test
	@Order(4)
	public void testUpdatePrivilege() {
		Privilege privilege = new Privilege();
    	privilege.setFunction("Additional Configuration");
		privilege.setAction("Create, Read And Write");
		restTemplate.put(getRootUrl() + "/managedEntity/api/v2/16/privilege/123", privilege);

		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/managedEntity/api/v2/16/privilege/123",
				HttpMethod.GET, entity, String.class);
		assertNotNull(response.getBody());
		System.out.println(response.getBody());
	}

	@Test
	@Order(5)
	public void testDeletePrivilegeById() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/managedEntity/api/v2/16/privilege/123",
				HttpMethod.DELETE, entity, String.class);

		ResponseEntity<String> response1 = restTemplate.exchange(getRootUrl() + "/managedEntity/api/v2/16/privilege/123",
				HttpMethod.GET, entity, String.class);
		assertNull(response1.getBody());
		System.out.println(response1.getBody());
	}
}
