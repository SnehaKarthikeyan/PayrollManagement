package com.example.privilege.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@DiscriminatorColumn(name = "Dtype", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("MENU")
@AllArgsConstructor
@NoArgsConstructor
public class MenuPrivilege extends Privilege {

    @JsonManagedReference
    @OneToMany(mappedBy = "parent",cascade = CascadeType.ALL)
    private List<MenuPrivilege> children;

    @JsonBackReference
    @ManyToOne
    private MenuPrivilege parent;

}

