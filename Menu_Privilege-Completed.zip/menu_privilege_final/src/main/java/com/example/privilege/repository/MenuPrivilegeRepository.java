package com.example.privilege.repository;

import com.example.privilege.model.MenuPrivilege;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface MenuPrivilegeRepository extends JpaRepository<MenuPrivilege,String> {

    @Query("Select p from MenuPrivilege p where managedEntityId=:managedEntityId and id=:id")
    MenuPrivilege findByManagedEntityIdAndId(String managedEntityId, String id);
    @Query("Select p from MenuPrivilege p where managedEntityId=:managedEntityId order by menuOrder")
    List<MenuPrivilege> sortMenuOrder(String managedEntityId);
    @Query("Select p from MenuPrivilege p where managedEntityId=:managedEntityId and code=:privilegeCode")
    MenuPrivilege findByManagedEntityIdAndCode(String managedEntityId, String privilegeCode);
}
