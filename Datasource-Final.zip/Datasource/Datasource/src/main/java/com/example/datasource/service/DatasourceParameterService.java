package com.example.datasource.service;

import com.example.datasource.domain.DatasourceParameter;
import com.example.datasource.exception.NotFoundException;

import java.util.List;

public interface DatasourceParameterService {
    DatasourceParameter saveDatasourceParameter(String datasourceCode, DatasourceParameter datasourceParameter);

    DatasourceParameter getDatasourceParameterById(String datasourceCode, long datasourceParameterId) throws NotFoundException;

    List<Object> getAllDatasourceParameter(String datasourceCode);

    DatasourceParameter updateDatasourceParameter(String datasourceCode, long datasourceParameterId, DatasourceParameter datasourceParameter);

    void deleteDatasourceParameterById(String datasourceCode, long datasourceParameterId);
}
