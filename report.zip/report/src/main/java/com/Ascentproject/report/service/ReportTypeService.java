package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.ReportType;
import java.util.List;

public interface ReportTypeService {
    List<ReportType> saveReportType(List<ReportType> reportTypeList);
    List<ReportType> getReportType();
}