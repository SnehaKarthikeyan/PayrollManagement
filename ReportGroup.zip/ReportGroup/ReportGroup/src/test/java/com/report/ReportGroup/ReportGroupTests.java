package com.report.ReportGroup;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.report.ReportGroup.Domain.ReportGroup;
import com.sun.istack.NotNull;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.HttpClientErrorException;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@Transactional
class ReportGroupTests {
    @Autowired
    private MockMvc mockMvc;

    @NotNull
    protected ReportGroup getReportGroup(int parentId, String code, String name, int reportId, int sortOrder, String excelPassword,
                                         String excelSheetPassword, String reportNameFormat, byte includeBatch, byte includeDataRange,
                                         byte enableDataBackUp, int recordStatusId)  {
        ReportGroup reportGroup = new ReportGroup();
        reportGroup.setParentId(parentId);
        reportGroup.setCode(code);
        reportGroup.setName(name);
        reportGroup.setReportId(reportId);
        reportGroup.setSortOrder(sortOrder);
        reportGroup.setExcelPassword(excelPassword);
        reportGroup.setExcelSheetPassword(excelSheetPassword);
        reportGroup.setReportNameFormat(reportNameFormat);
        reportGroup.setIncludeBatch(includeBatch);
        reportGroup.setIncludeDataRange(includeDataRange);
        reportGroup.setEnableDataBackup(enableDataBackUp);
        reportGroup.setRecordStatusId(recordStatusId);
        return reportGroup;
    }

    private ReportGroup getReportGroup(MvcResult mvcResult) throws IOException{
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), ReportGroup.class);
    }

    protected List<ReportGroup> addReportGroupAPI(List<ReportGroup> datasource) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(datasource);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/reportgroup")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        List<ReportGroup> datasources = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<ReportGroup>>(){});
        return datasources;
    }

    private ReportGroup getReportGroupById(long id) throws Exception {
        ReportGroup reportGroup;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/reportgroup/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("id", String.valueOf(id))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        reportGroup= getReportGroup(mvcResult);
        return reportGroup;
    }

    private ReportGroup getReportGroupByCode(String code) throws Exception {
        ReportGroup reportGroup;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/reportgroup/" + code)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        reportGroup = getReportGroup(mvcResult);
        return reportGroup;
    }

    private Object[] getAllReportGroup() throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/reportgroup")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        Object[] datasourceResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
        return datasourceResult;
    }

    private Object[] updateReportGroupAPI(ReportGroup reportGroup) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(reportGroup);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/reportgroup/" + reportGroup.getCode())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        Object[] datasourceResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
        return datasourceResult;
    }

    @Test
    public void testSaveReportGroup() throws Exception {
        List<ReportGroup> reportGroups = new ArrayList<ReportGroup>();
        reportGroups.add(getReportGroup(1, "code1", "name1", 2, 1, "excel",
                                    "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        reportGroups = addReportGroupAPI(reportGroups);
        assertNotNull(reportGroups.get(0));
        assertEquals(1, reportGroups.get(0).getParentId());
        assertEquals("code1", reportGroups.get(0).getCode());
        assertEquals("name1", reportGroups.get(0).getName());
        assertEquals(2, reportGroups.get(0).getReportId());
        assertEquals(1, reportGroups.get(0).getSortOrder());
        assertEquals("excel", reportGroups.get(0).getExcelPassword());
        assertEquals("sheet", reportGroups.get(0).getExcelSheetPassword());
        assertEquals("PDF", reportGroups.get(0).getReportNameFormat());
        assertEquals(1, reportGroups.get(0).getEnableDataBackup());
        assertEquals(1, reportGroups.get(0).getIncludeBatch());
        assertEquals(1, reportGroups.get(0).getIncludeDataRange());
        assertEquals(2, reportGroups.get(0).getRecordStatusId());
    }

    @Test
    public void testGetReportGroupById() throws Exception {
        List<ReportGroup> reportGroups = new ArrayList<ReportGroup>();
        reportGroups.add(getReportGroup(1, "code2", "name2", 2, 1, "excel",
                "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        reportGroups = addReportGroupAPI(reportGroups);
        long id = reportGroups.get(0).getId();
        ReportGroup reportGroup = getReportGroupById(id);
        assertEquals(1, reportGroups.get(0).getParentId());
        assertEquals("code2", reportGroups.get(0).getCode());
        assertEquals("name2", reportGroups.get(0).getName());
        assertEquals(2, reportGroups.get(0).getReportId());
        assertEquals(1, reportGroups.get(0).getSortOrder());
        assertEquals("excel", reportGroups.get(0).getExcelPassword());
        assertEquals("sheet", reportGroups.get(0).getExcelSheetPassword());
        assertEquals("PDF", reportGroups.get(0).getReportNameFormat());
        assertEquals(1, reportGroups.get(0).getEnableDataBackup());
        assertEquals(1, reportGroups.get(0).getIncludeBatch());
        assertEquals(1, reportGroups.get(0).getIncludeDataRange());
        assertEquals(2, reportGroups.get(0).getRecordStatusId());
    }

    @Test
    public void testGetReportGroupByCode() throws Exception {
        List<ReportGroup> reportGroups = new ArrayList<ReportGroup>();
        reportGroups.add(getReportGroup(1, "code3", "name3", 2, 1, "excel",
                "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        reportGroups = addReportGroupAPI(reportGroups);
        String code = reportGroups.get(0).getCode();
        ReportGroup reportGroup = getReportGroupByCode(code);
        assertNotNull(reportGroup);
        assertEquals(1, reportGroups.get(0).getParentId());
        assertEquals("code3", reportGroups.get(0).getCode());
        assertEquals("name3", reportGroups.get(0).getName());
        assertEquals(2, reportGroups.get(0).getReportId());
        assertEquals(1, reportGroups.get(0).getSortOrder());
        assertEquals("excel", reportGroups.get(0).getExcelPassword());
        assertEquals("sheet", reportGroups.get(0).getExcelSheetPassword());
        assertEquals("PDF", reportGroups.get(0).getReportNameFormat());
        assertEquals(1, reportGroups.get(0).getEnableDataBackup());
        assertEquals(1, reportGroups.get(0).getIncludeBatch());
        assertEquals(1, reportGroups.get(0).getIncludeDataRange());
        assertEquals(2, reportGroups.get(0).getRecordStatusId());
    }

    @Test
    public void testGetAllReportGroup() throws Exception {
        List<ReportGroup> reportGroups = new ArrayList<ReportGroup>();
        reportGroups.add(getReportGroup(1, "code4", "name4", 2, 2, "excel",
                "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        reportGroups = addReportGroupAPI(reportGroups);
        assertEquals(1, reportGroups.get(0).getParentId());
        assertEquals("code4", reportGroups.get(0).getCode());
        assertEquals("name4", reportGroups.get(0).getName());
        assertEquals(2, reportGroups.get(0).getReportId());
        assertEquals(2, reportGroups.get(0).getSortOrder());
        assertEquals("excel", reportGroups.get(0).getExcelPassword());
        assertEquals("sheet", reportGroups.get(0).getExcelSheetPassword());
        assertEquals("PDF", reportGroups.get(0).getReportNameFormat());
        assertEquals(1, reportGroups.get(0).getEnableDataBackup());
        assertEquals(1, reportGroups.get(0).getIncludeBatch());
        assertEquals(1, reportGroups.get(0).getIncludeDataRange());
        assertEquals(2, reportGroups.get(0).getRecordStatusId());
        reportGroups.add(getReportGroup(1, "code5", "name5", 2, 1, "excel",
                "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        addReportGroupAPI(reportGroups);
        Object[] result = getAllReportGroup();
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testUpdateReportGroup() throws Exception {
        List<ReportGroup> reportGroups = new ArrayList<ReportGroup>();
        reportGroups.add(getReportGroup(1, "code6", "name6", 2, 1, "excel",
                "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        reportGroups = addReportGroupAPI(reportGroups);
        reportGroups.get(0).setName("name7");
        Object reportGroup = updateReportGroupAPI(reportGroups.get(0));
        assertNotNull(reportGroup);
        assertEquals(1, reportGroups.get(0).getParentId());
        assertEquals("code6", reportGroups.get(0).getCode());
        assertEquals("name7", reportGroups.get(0).getName());
        assertEquals(2, reportGroups.get(0).getReportId());
        assertEquals(1, reportGroups.get(0).getSortOrder());
        assertEquals("excel", reportGroups.get(0).getExcelPassword());
        assertEquals("sheet", reportGroups.get(0).getExcelSheetPassword());
        assertEquals("PDF", reportGroups.get(0).getReportNameFormat());
        assertEquals(1, reportGroups.get(0).getEnableDataBackup());
        assertEquals(1, reportGroups.get(0).getIncludeBatch());
        assertEquals(1, reportGroups.get(0).getIncludeDataRange());
        assertEquals(2, reportGroups.get(0).getRecordStatusId());
    }

    @Test
    public void testDeleteReportGroupById() throws Exception {
        List<ReportGroup> reportGroups = new ArrayList<ReportGroup>();
        reportGroups.add(getReportGroup(1, "code8", "name8", 2, 1, "excel",
                "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        reportGroups = addReportGroupAPI(reportGroups);
        long id= reportGroups.get(0).getId();
        try {
            assertEquals("Report Group '"+ id +"' deleted", delete(id));
        } catch(final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    @Test
    public void testDeleteReportGroupByCode() throws Exception {
        List<ReportGroup> reportGroups = new ArrayList<ReportGroup>();
        reportGroups.add(getReportGroup(1, "code9", "name9", 2, 1, "excel",
                "sheet", "PDF", (byte)1, (byte)1, (byte)1, 2));
        reportGroups = addReportGroupAPI(reportGroups);
        String code = reportGroups.get(0).getCode();
        try {
            assertEquals("Report Group '"+ reportGroups.get(0).getCode() +"' deleted", markForDelete(code));
        } catch(final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private String markForDelete(String code) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/reportgroup/" + code)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk()).andReturn();
        return mvcResult.getResponse().getContentAsString();
    }

    private String delete(long id) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/reportgroup/")
                        .param("id", String.valueOf(id))
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk()).andReturn();
        return mvcResult.getResponse().getContentAsString();
    }
}
