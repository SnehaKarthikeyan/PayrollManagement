package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.BulkHelper.BulkHelperUserRole;
import com.ascent_project.RBAC.exception.UserRoleNotFoundException;
import com.ascent_project.RBAC.model.UserRole;
import com.ascent_project.RBAC.service.UserRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@RestController
@RequestMapping("/managedEntity")

public class UserRoleController {
    @Autowired
    private UserRoleService userRoleService;

    @PostMapping("/{managedEntity_id}/role/{role_id}/user/{user_id}")
    public ResponseEntity<String> saveIndividualUserRole(@PathVariable (name="managedEntity_id") Long managedEntity_id ,@PathVariable (name="role_id") Long role_id,@PathVariable (name="user_id") Long user_id,@RequestBody UserRole userRole){
        ResponseEntity<String> responseEntity = null;
        try{
            Long id = userRoleService.saveIndividualUserRole(managedEntity_id, role_id,user_id,userRole);

            responseEntity= new ResponseEntity<String>(
                    "UserRole '"+id+"' created",HttpStatus.CREATED); //201-created}

        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Individual UserRole",
                    HttpStatus.INTERNAL_SERVER_ERROR); //500-Internal Server Error
        }
        return responseEntity;
    }

    @GetMapping("/{managedEntity_id}/role/{role_id}/user")
    public ResponseEntity<?> getAllUserRoles(@PathVariable("managedEntity_id") Long managedEntity_id, @PathVariable("role_id") Long role_id) {
        ResponseEntity<?> responseEntity=null;
        try {
            List<UserRole> userRoleList= userRoleService.getAllUserRoles(managedEntity_id, role_id);
            responseEntity= new ResponseEntity<List<UserRole>>(userRoleList,HttpStatus.OK);
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get Users",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    @GetMapping("/{managedEntity_id}/role/{role_id}/user/{user_id}")
    public ResponseEntity<?> getOneUserRole(@PathVariable("managedEntity_id") Long managedEntity_id, @PathVariable("role_id") Long role_id, @PathVariable("user_id") Long user_id) {
        ResponseEntity<?> responseEntity=null;
        try {
            UserRole userRole= userRoleService.getOneUserRole(managedEntity_id, role_id, user_id);
            responseEntity= new ResponseEntity<UserRole>
                    (userRole,HttpStatus.OK);
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get User Role",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
    @DeleteMapping("/{managedEntity_id}/role/{role_id}/user/{user_id}")
    public ResponseEntity<String> deleteOneUserRole(@PathVariable (name="managedEntity_id") Long managedEntity_id, @PathVariable (name="role_id") Long role_id,@PathVariable (name="user_id")Long user_id){

        ResponseEntity<String> responseEntity= null;
        try {
            userRoleService.deleteOneUserRole(managedEntity_id,role_id,user_id);
            responseEntity= new ResponseEntity<String> (
                    "User Role having user_id '"+user_id+"' deleted",HttpStatus.OK);

        }
        catch (UserRoleNotFoundException exception) {
         throw exception;
         }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete User Role", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }


    @PostMapping("/role/user")
    public ResponseEntity<String> BulkUploadFile(@RequestParam("file") MultipartFile file) {
        String message = "";

        if (BulkHelperUserRole.hasCSVFormat(file)) {
            try {
                userRoleService.saveBulkUpload(file);
                message = "Uploaded the file successfully: " + file.getOriginalFilename();
                return ResponseEntity.status(HttpStatus.OK).body(message);
            } catch (Exception exception) {
                exception.printStackTrace();
                message = "Could not upload the file: " + file.getOriginalFilename() + "!";
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
            }
        }

        message = "Please upload a csv file!";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

}
