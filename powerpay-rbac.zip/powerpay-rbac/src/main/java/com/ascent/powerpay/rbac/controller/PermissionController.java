package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.BulkHelper.BulkHelperUserRole;
import com.ascent.powerpay.rbac.domain.Permission;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.PermissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/permission", "/manage/permission"})
public class PermissionController {

    @Autowired
    private PermissionService permissionService;

    @PostMapping("/managedentity/{managedEntityCode}")
    public ResponseEntity<List<Permission>> saveIndividualPermission(@PathVariable(name="managedEntityCode") String managedEntityCode,
            @RequestBody Permission permission) throws NotFoundException {
        ResponseEntity<List<Permission>> responseEntity = null;
        List<Permission> permission1 = null;
        try {
            permission1 = (List<Permission>)permissionService.savePermission(managedEntityCode, permission);
            if(permission1 == null) {
                responseEntity= new ResponseEntity<List<Permission>>((List<Permission>)permission, HttpStatus.BAD_REQUEST);
            }
            responseEntity= new ResponseEntity<List<Permission>>(permission1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.debug("Unable to save Permission");
            responseEntity = new ResponseEntity<List<Permission>>(permission1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PostMapping("/managedentity/permission")
    public ResponseEntity<String> BulkUploadFile(@RequestParam("file") MultipartFile file) throws NotFoundException {
        String message = "";
        if (BulkHelperUserRole.hasCSVFormat(file)) {
            try {
                permissionService.saveBulkUpload(file);
                message = "Uploaded the file successfully: " + file.getOriginalFilename();
                return ResponseEntity.status(HttpStatus.OK).body(message);
            } catch (Exception exception) {
                log.debug("Unable to upload the file");
                message = "Could not upload the file: " + file.getOriginalFilename() + "!";
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
            }
        }
        message = "Please upload a csv file!";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

    @GetMapping("/managedentity/{managedEntityCode}/{permissionId}")
    public ResponseEntity<?> getPermissionById(@PathVariable("permissionId") String permissionId) throws NotFoundException {
        ResponseEntity<?> responseEntity=null;
        try {
            Permission permission= permissionService.getPermissionById(permissionId);
            responseEntity= new ResponseEntity<Permission>(permission,HttpStatus.OK);
        }catch (Exception exception) {
            log.debug("Unable to get Permission");
            responseEntity = new ResponseEntity<String>("Unable to get Permission", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/{permissionCode}")
    public ResponseEntity<?> getPermissionByCode(@RequestParam("permissionCode") String permissionCode) throws NotFoundException {
        if(permissionCode == null)
            return getAllPermission();
        ResponseEntity<?> responseEntity=null;
        try {
            List<Permission> permission= (List<Permission>)permissionService.getPermissionByCode(permissionCode);
            responseEntity= new ResponseEntity<List<Permission>>(permission,HttpStatus.OK);
        }catch (Exception exception) {
            log.debug("Unable to get Permission");
            responseEntity = new ResponseEntity<String>("Unable to get Permission", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    public ResponseEntity<?> getAllPermission() throws NotFoundException {
        ResponseEntity<?> responseEntity=null;
        try {
            List<Permission> permissionList= permissionService.getAllPermission();
            responseEntity= new ResponseEntity<List<Permission>>(permissionList, HttpStatus.OK);
        }catch (Exception exception) {
            log.debug("Unable to get All Permission");
            responseEntity = new ResponseEntity<String>("Unable to get All Permission", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/managedentity/{managedEntityCode}/permission/{permissionCode}")
    public ResponseEntity<?> updatePermission(@PathVariable("managedEntityCode") String managedEntityCode,
            @PathVariable("permissionCode") String permissionCode,
            @RequestBody Permission permission) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        List<Permission> permission1 = null;
        try {
            permission1 = (List<Permission>)permissionService.updatePermission(managedEntityCode, permissionCode, permission);
            responseEntity = new ResponseEntity<List<Permission>>(permission1, HttpStatus.OK);
        }catch(Exception e) {
            log.debug("Unable to find Permission");
            responseEntity = new ResponseEntity<String>("Unable to find Permission", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{permissionId}")
    public ResponseEntity<String> deletePermissionById(@PathVariable(name="permissionId") String permissionId) throws NotFoundException {
        ResponseEntity<String> responseEntity= null;
        try {
            permissionService.deletePermissionById(permissionId);
            responseEntity= new ResponseEntity<String> ("Permission '"+permissionId+"' deleted", HttpStatus.OK);
        }catch (Exception exception) {
            log.debug("Unable to delete Permission");
            responseEntity= new ResponseEntity<String>("Unable to delete Permission", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    @DeleteMapping("/{permissionCode}")
    public ResponseEntity<String> deletePermissionByCode(@RequestParam(name="permissionCode") String permissionCode) throws NotFoundException {
        ResponseEntity<String> responseEntity= null;
        try {
            permissionService.deletePermissionByCode(permissionCode);
            responseEntity= new ResponseEntity<String> ("Permission '"+permissionCode+"' deleted", HttpStatus.OK);
        }catch (Exception exception) {
            log.debug("Unable to delete Permission");
            responseEntity= new ResponseEntity<String>("Unable to delete Permission", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

}
