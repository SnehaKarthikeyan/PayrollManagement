package com.upload.UploadFolder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sun.istack.NotNull;
import com.upload.UploadFolder.Domain.UploadFolder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.HttpClientErrorException;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@Transactional
class UploadFolderApplicationTests {
	@Autowired
	private MockMvc mockMvc;

	@NotNull
	protected UploadFolder getUploadFolder(int clientId, String folderName, int maximumCountPerMonth,
										   int messageId, int recordStatusId, int refId)  {
		UploadFolder uploadFolder = new UploadFolder();
		uploadFolder.setClientId(clientId);
		uploadFolder.setFolderName(folderName);
		uploadFolder.setMaximumCountPerMonth(maximumCountPerMonth);
		uploadFolder.setMessageId(messageId);
		uploadFolder.setRecordStatusId(recordStatusId);
		uploadFolder.setRefId(refId);
		return uploadFolder;
	}

	private UploadFolder getUploadFolder(MvcResult mvcResult) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), UploadFolder.class);
	}

	protected List<UploadFolder> addUploadFolderAPI(List<UploadFolder> uploadFolders) throws Exception {
		Gson gson = new Gson();
		String jsonStr = gson.toJson(uploadFolders);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.post("/manage/uploadfolder")
						.contentType(MediaType.APPLICATION_JSON)
						.content(jsonStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();
		ObjectMapper mapper = new ObjectMapper();
		List<UploadFolder> uploadFolderList = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<UploadFolder>>(){});
		return uploadFolderList;
	}

	private UploadFolder getUploadFolderById(int id) throws Exception {
		UploadFolder uploadFolder;
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.get("/manage/uploadfolder/search")
						.contentType(MediaType.APPLICATION_JSON)
						.param("id", String.valueOf(id))
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		uploadFolder = getUploadFolder(mvcResult);
		return uploadFolder;
	}

	private Object[] getUploadFolderByClientId(int clientId) throws Exception {
		List<UploadFolder> uploadFolder;
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.get("/manage/uploadfolder/" + clientId)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		/*uploadFolder = (List<UploadFolder>) getUploadFolder(mvcResult);
		return uploadFolder;*/
		ObjectMapper mapper = new ObjectMapper();
		Object[] uploadFolderResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
		return uploadFolderResult;
	}

	private Object[] getAllUploadFolder() throws Exception {
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.get("/manage/uploadfolder/")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		ObjectMapper mapper = new ObjectMapper();
		Object[] uploadFolderResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
		return uploadFolderResult;
	}

	private Object[] updateUploadFolderAPI(UploadFolder uploadFolder) throws Exception {
		Gson gson = new Gson();
		String jsonStr = gson.toJson(uploadFolder);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.put("/manage/uploadfolder/" + uploadFolder.getId())
						.contentType(MediaType.APPLICATION_JSON)
						.content(jsonStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		ObjectMapper mapper = new ObjectMapper();
		Object[] uploadFolderResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
		return uploadFolderResult;
	}

	@Test
	public void testSaveUploadFolder() throws Exception {
		List<UploadFolder> uploadFolders = new ArrayList<UploadFolder>();
		uploadFolders.add(getUploadFolder(12, "folder1", 5,
				1, 2, 3));
		uploadFolders = addUploadFolderAPI(uploadFolders);
		assertNotNull(uploadFolders.get(0));
		assertEquals(12, uploadFolders.get(0).getClientId());
		assertEquals("folder1", uploadFolders.get(0).getFolderName());
		assertEquals(5, uploadFolders.get(0).getMaximumCountPerMonth());
		assertEquals(1, uploadFolders.get(0).getMessageId());
		assertEquals(2, uploadFolders.get(0).getRecordStatusId());
		assertEquals(3, uploadFolders.get(0).getRefId());
	}

	@Test
	public void testGetUploadFolderById() throws Exception {
		List<UploadFolder> uploadFolders = new ArrayList<UploadFolder>();
		uploadFolders.add(getUploadFolder(12, "folder1", 5,
				1, 2, 3));
		uploadFolders = addUploadFolderAPI(uploadFolders);
		int id = uploadFolders.get(0).getId();
		UploadFolder uploadFolder = getUploadFolderById(id);
		assertNotNull(uploadFolder);
		assertEquals(12, uploadFolder.getClientId());
		assertEquals("folder1", uploadFolder.getFolderName());
		assertEquals(5, uploadFolder.getMaximumCountPerMonth());
		assertEquals(1, uploadFolder.getMessageId());
		assertEquals(2, uploadFolder.getRecordStatusId());
		assertEquals(3, uploadFolder.getRefId());
	}

	@Test
	public void testGetUploadFolderByClientId() throws Exception {
		List<UploadFolder> uploadFolders = new ArrayList<UploadFolder>();
		uploadFolders.add(getUploadFolder(13, "folder1", 5,
				1, 2, 3));
		uploadFolders = addUploadFolderAPI(uploadFolders);
		int id = uploadFolders.get(0).getClientId();
		assertEquals(13, uploadFolders.get(0).getClientId());
		assertEquals("folder1", uploadFolders.get(0).getFolderName());
		assertEquals(5, uploadFolders.get(0).getMaximumCountPerMonth());
		assertEquals(1, uploadFolders.get(0).getMessageId());
		assertEquals(2, uploadFolders.get(0).getRecordStatusId());
		assertEquals(3, uploadFolders.get(0).getRefId());
		Object[] uploadFolder = getUploadFolderByClientId(id);
		assertNotNull(uploadFolder);
		assertTrue(uploadFolder.length > 0);
	}

	@Test
	public void testGetAllUploadFolder() throws Exception {
		List<UploadFolder> uploadFolders = new ArrayList<UploadFolder>();
		uploadFolders.add(getUploadFolder(12, "folder1", 5,
				1, 2, 3));
		uploadFolders = addUploadFolderAPI(uploadFolders);
		assertEquals(12, uploadFolders.get(0).getClientId());
		assertEquals("folder1", uploadFolders.get(0).getFolderName());
		assertEquals(5, uploadFolders.get(0).getMaximumCountPerMonth());
		assertEquals(1, uploadFolders.get(0).getMessageId());
		assertEquals(2, uploadFolders.get(0).getRecordStatusId());
		assertEquals(3, uploadFolders.get(0).getRefId());

		uploadFolders.add(getUploadFolder(12, "folder1", 5,
				1, 2, 3));
		addUploadFolderAPI(uploadFolders);
		Object[] result = getAllUploadFolder();
		assertNotNull(result);
		assertTrue(result.length > 0);
	}

	@Test
	public void testUpdateUploadFolder() throws Exception {
		List<UploadFolder> uploadFolders = new ArrayList<UploadFolder>();
		uploadFolders.add(getUploadFolder(12, "folder1", 5,
				1, 2, 3));
		uploadFolders = addUploadFolderAPI(uploadFolders);
		uploadFolders.get(0).setFolderName("folder2");
		Object uploadFolder = updateUploadFolderAPI(uploadFolders.get(0));
		assertNotNull(uploadFolder);
		assertEquals(12, uploadFolders.get(0).getClientId());
		assertEquals("folder2", uploadFolders.get(0).getFolderName());
		assertEquals(5, uploadFolders.get(0).getMaximumCountPerMonth());
		assertEquals(1, uploadFolders.get(0).getMessageId());
		assertEquals(2, uploadFolders.get(0).getRecordStatusId());
		assertEquals(3, uploadFolders.get(0).getRefId());
		assertEquals(2, uploadFolders.get(0).getRecordStatusId());
	}

	@Test
	public void testDeleteUploadFolderById() throws Exception {
		List<UploadFolder> uploadFolders = new ArrayList<UploadFolder>();
		uploadFolders.add(getUploadFolder(12, "folder1", 5,
				1, 2, 3));
		uploadFolders = addUploadFolderAPI(uploadFolders);
		int id= uploadFolders.get(0).getId();
		try {
			assertEquals("Upload Folder '"+ id +"' deleted", delete(id));
		} catch(final HttpClientErrorException e) {
			fail("object status should have been saved.");
		}
	}

	private String delete(int id) throws Exception {
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.delete("/manage/uploadfolder")
						.param("id", String.valueOf(id))
						.accept(MediaType.TEXT_PLAIN))
				.andExpect(status().isOk()).andReturn();
		return mvcResult.getResponse().getContentAsString();
	}
}
