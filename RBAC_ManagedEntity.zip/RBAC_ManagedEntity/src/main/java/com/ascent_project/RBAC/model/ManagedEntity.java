package com.ascent_project.RBAC.model;
import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ManagedEntity")

public class ManagedEntity{

        @Id

        private Long id;

        private String code;

        private String entityType;

        private String entityName;

    }



