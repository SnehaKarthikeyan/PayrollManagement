package com.ascent_project.RBAC.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="ASSET_INVOLVEMENT_ROLE")
public class AssetInvolvementRole {
    @Id
    @Column(name = "ID")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "MANAGED_ENTITY_ID")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private ManagedEntity managedEntity;

    @ManyToOne
    @JoinColumn(name = "PERMISSION_ID")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private Permission permission;

    @ManyToOne
    @JoinColumn(name = "PRIVILEGE_ID")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private Privilege privilege;

    @ManyToOne
    @JoinColumn(name = "USER_ROLE_ID")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private UserRole userRole;
}
