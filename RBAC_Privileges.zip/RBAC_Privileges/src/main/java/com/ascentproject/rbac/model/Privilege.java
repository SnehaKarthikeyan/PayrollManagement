package com.ascentproject.rbac.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Privileges")
public class Privilege {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "Function")
    private String function;

    @Column(name = "Action")
    private String action;

    @ManyToOne
    @JoinColumn(name = "managedEntity_id")
    @OnDelete( action = OnDeleteAction.CASCADE)
    @JsonIdentityInfo( generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @JsonIdentityReference(alwaysAsId = true)
    @JsonProperty("managedEntity_id")
    private ManagedEntity managedEntity;

}
