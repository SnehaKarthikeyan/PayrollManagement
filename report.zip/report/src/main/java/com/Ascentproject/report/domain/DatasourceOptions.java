package com.Ascentproject.report.domain;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Table(name = "DATASOURCE_OPTIONS")
@Entity
@Data
// @EqualsAndHashCode( callSuper = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class DatasourceOptions {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "DATASOURCE_ID")
    private long datasourceId;

    @Column(name= "CONTROL_COLUMN")
    private String controlColumn;

    @Column(name= "CONTROL_LABEL")
    private String controlLabel;

    @Column(name= "CONTROLTYPE_ID")
    private String controlTypeId;

    @Column(name= "CONTROL_VALUE")
    private String controlValue;

    @Column(name= "CONTROL_TEXT")
    private String controlText;

    @Column(name= "CONTROL_DATASOURCE_ID")
    private long controlDatasourceId;

    @Column(name= "RECORD_STATUS_ID")
    private long recordStatusId;

    @Column(name= "ISACTIVE")
    private boolean isActive;

    @Column(name = "CREATED_BY_ID")
    private String createdById;

    @Column(name = "CREATED_BY_IP")
    private String createdByIp;

    @Column(name = "LAST_MODIFIED_BY_ID")
    private String lastModifiedById;

    @Column(name = "LAST_MODIFIED_BY_IP")
    private String lastModifiedByIp;
}
