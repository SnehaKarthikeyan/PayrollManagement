/*package com.example.privilege;


import com.example.privilege.model.MenuPrivilege;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
@AutoConfigureMockMvc
class PrivilegeTests {
	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private ObjectMapper mapper;

	@LocalServerPort
	private int port;
	private String getRootUrl()
	{
		return "http://localhost:" + port;
	}

	@NotNull
	private MenuPrivilege getPrivilege(String managedEntityId,String name,boolean active,Long menuOrder,String code)
	{
		MenuPrivilege menuPrivilege = new MenuPrivilege();
		menuPrivilege.setManagedEntityId(managedEntityId);
		menuPrivilege.setName(name);
		menuPrivilege.setActive(active);
		menuPrivilege.setMenuOrder(menuOrder);
		menuPrivilege.setCode(code);
		return menuPrivilege;
	}

	private List<MenuPrivilege> addAllPrivilegeAPI(List<MenuPrivilege> me) throws Exception {
		Gson gson = new Gson();
		String meStr = gson.toJson(me);
		System.out.println(meStr);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.post("/manage/privilege")
						.contentType(MediaType.APPLICATION_JSON)
						.content(meStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();

		ObjectMapper mapper = new ObjectMapper();
		List<MenuPrivilege> menuPrivilegeList = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<MenuPrivilege>>(){});
		return menuPrivilegeList;
	}



	private MenuPrivilege updatePrivilegeByCodeAPI(MenuPrivilege me) throws Exception {
		Gson gson = new Gson();
		String meStr = gson.toJson(me);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.put("/manage/privilege/" + me.getCode())
						.contentType(MediaType.APPLICATION_JSON)
						.content(meStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		MenuPrivilege menuPrivilegeResult = getPrivilege(mvcResult);
		return menuPrivilegeResult;
	}

	private MenuPrivilege updatePrivilegeByIdAPI(MenuPrivilege me) throws Exception {
		Gson gson = new Gson();
		String meStr = gson.toJson(me);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.post("/manage/privilege/" + me.getId())
						.contentType(MediaType.APPLICATION_JSON)
						.content(meStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isAccepted())
				.andReturn();
		MenuPrivilege menuPrivilegeResult = getPrivilege(mvcResult);
		return menuPrivilegeResult;
	}
	private void updatePrivilegeByParentChildCode(String parent,String child) throws Exception {

		 this.mockMvc.perform(RestDocumentationRequestBuilders
						.put("/manage/privilege/" + parent+"/"+child)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isAccepted())
				.andReturn();
	}

	private MenuPrivilege getPrivilege(MvcResult mvcResult) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), MenuPrivilege.class);
	}
	private MenuPrivilege[] getPrivilegeArray(MvcResult mvcResult) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), MenuPrivilege[].class);
	}

	@Test
	public void testSavePrivilege() throws Exception
	{

		InputStream inputStream= MenuPrivilege.class.getResourceAsStream("/data/source.json");
		CollectionType collectionType = mapper.getTypeFactory().constructCollectionType(List.class, MenuPrivilege.class);
		List<MenuPrivilege> menuPrivilegeList = mapper.readValue(inputStream, collectionType);
		List<MenuPrivilege> menuPrivilegeList1=addAllPrivilegeAPI(menuPrivilegeList);
		MenuPrivilege menuPrivilege=menuPrivilegeList1.get(0);
		assertEquals("fff", menuPrivilege.getCode());
		assertEquals("file", menuPrivilege.getName());
		assertNotNull(menuPrivilege.getId());

	}

	private MenuPrivilege getPrivilegeById(String id) throws Exception {
		MenuPrivilege menuPrivilege;
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.get("/manage/privilege/" + id)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		menuPrivilege = getPrivilege(mvcResult);
		return menuPrivilege;
	}

	private MenuPrivilege getPrivilegeByCode(String code) throws Exception {

		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.get("/manage/privilege/code/"+code)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		MenuPrivilege  menuPrivilegeArray = getPrivilege(mvcResult);
		return menuPrivilegeArray;
	}
	@Test
	public void testGetAllPrivilege() throws Exception {
		List<MenuPrivilege> menuPrivilegeList= new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,2L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		MenuPrivilege menuPrivilege1=getPrivilege("abcdh","file1",true,1L,"ff2");
		menuPrivilegeList.add(menuPrivilege1);
		menuPrivilegeList =addAllPrivilegeAPI(menuPrivilegeList);
		assertEquals(2,menuPrivilegeList.size());
		menuPrivilege=menuPrivilegeList.get(0);
		assertEquals("ff1", menuPrivilege.getCode());
		assertEquals("file", menuPrivilege.getName());
		assertNotNull(menuPrivilege.getId());
	}
	@Test
	public void testGetPrivilegeById() throws Exception {
		List<MenuPrivilege> menuPrivilegeList= new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,1L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		menuPrivilegeList =addAllPrivilegeAPI(menuPrivilegeList);
		menuPrivilege=menuPrivilegeList.get(0);
		String id=menuPrivilege.getId();
		menuPrivilege=getPrivilegeById(id);
		assertNotNull(id);

	}
	@Test
	public void testGetPrivilegeByCode() throws Exception {
		List<MenuPrivilege> menuPrivilegeList= new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,1L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		menuPrivilegeList =addAllPrivilegeAPI(menuPrivilegeList);
		menuPrivilege=menuPrivilegeList.get(0);
		String code=menuPrivilege.getCode();
		menuPrivilege=getPrivilegeByCode(code);
		assertEquals("ff1",code);

	}
	@Test
	public void testUpdatePrivilegeById() throws Exception
	{
		List<MenuPrivilege> menuPrivilegeList=new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,1L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		menuPrivilegeList=addAllPrivilegeAPI(menuPrivilegeList);
		menuPrivilege=menuPrivilegeList.get(0);
		menuPrivilege.setName("file1");
		menuPrivilege.setActive(true);
		menuPrivilege.setMenuOrder(1l);
		menuPrivilege.setCode("ff2");
		menuPrivilege.setParent(null);
		String id=menuPrivilege.getId();
		updatePrivilegeByIdAPI(menuPrivilege);
		menuPrivilege = getPrivilegeById(id);
		assertNotNull(menuPrivilege);
		assertEquals("ff2", menuPrivilege.getCode());
		assertEquals("file1", menuPrivilege.getName());
	}

	@Test
	public void testUpdatePrivilegeByCode() throws Exception
	{
		List<MenuPrivilege> menuPrivilegeList=new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,1L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		menuPrivilegeList=addAllPrivilegeAPI(menuPrivilegeList);
		menuPrivilege=menuPrivilegeList.get(0);
		menuPrivilege.setName("file1");
		menuPrivilege.setActive(true);
		menuPrivilege.setMenuOrder(1l);
		menuPrivilege.setParent(null);
		String code=menuPrivilege.getCode();
		System.out.println(code);
		updatePrivilegeByCodeAPI(menuPrivilege);
		menuPrivilege = getPrivilegeByCode(code);
		assertNotNull(menuPrivilege);
		assertEquals("ff1", menuPrivilege.getCode());
		assertEquals("file1", menuPrivilege.getName());
	}

	@Test
	public void testUpdatePrivilegeByParentAndChildCode() throws Exception
	{
		List<MenuPrivilege> menuPrivilegeList=new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,1L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		MenuPrivilege menuPrivilege1=getPrivilege("abcdh","fileNew",true,2L,"ffn1");
		menuPrivilegeList.add(menuPrivilege1);
		menuPrivilegeList=addAllPrivilegeAPI(menuPrivilegeList);
		menuPrivilege=menuPrivilegeList.get(0);
		String child=menuPrivilege.getCode();
		menuPrivilege1=menuPrivilegeList.get(1);
		String parent=menuPrivilege1.getCode();
		updatePrivilegeByParentChildCode(parent,child);
	}

	@Test
	public void testDeletePrivilegeById() throws Exception {
		List<MenuPrivilege> menuPrivilegeList= new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,1L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		menuPrivilegeList=addAllPrivilegeAPI(menuPrivilegeList);
		menuPrivilege=menuPrivilegeList.get(0);
		String id = menuPrivilege.getId();
		delete(id);
		try {
			this.mockMvc.perform(RestDocumentationRequestBuilders
							.get("/manage/privilege/"+ id)
							.accept(MediaType.APPLICATION_JSON))
					.andExpect(status().isBadRequest());
		} catch (final Exception e) {
			fail("object status should have been saved.");
		}
	}
	@Test
	public void testDeleteManagedEntityByCode() throws Exception {
		List<MenuPrivilege> menuPrivilegeList=new ArrayList<>();
		MenuPrivilege menuPrivilege = getPrivilege("abcdh","file",true,1L,"ff1");
		menuPrivilegeList.add(menuPrivilege);
		menuPrivilegeList = addAllPrivilegeAPI(menuPrivilegeList);
		menuPrivilege=menuPrivilegeList.get(0);
		String code = menuPrivilege.getCode();
		markForDelete(code);
		try
		{
			this.mockMvc.perform(RestDocumentationRequestBuilders
							.get("/manage/privilege/code"+ code)
							.accept(MediaType.APPLICATION_JSON))
					.andExpect(status().isBadRequest());
		}
		catch (final HttpClientErrorException e) {
			fail("object status should have been saved.");
		}
	}

	private void markForDelete(String code) throws Exception {
		this.mockMvc.perform(RestDocumentationRequestBuilders
						.delete("/manage/privilege/"+code))
				.andExpect(status().isOk());
	}

	private void delete(String id) throws Exception {
		this.mockMvc.perform(RestDocumentationRequestBuilders
						.delete("/manage/privilege/privilegeId/" + id)
						.accept(MediaType.TEXT_PLAIN))
				.andExpect(status().isOk());
	}
}*/