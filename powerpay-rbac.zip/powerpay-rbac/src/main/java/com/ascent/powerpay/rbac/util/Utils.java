package com.ascent.powerpay.rbac.util;

import com.ascent.powerpay.dse.util.StorageUtils;
import com.ascent.powerpay.kernel.PowerPayConfiguration;
import com.ascent.powerpay.kernel.resource.ConfigResourceLoader;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static com.ascent.powerpay.dse.util.StorageUtils.instantiate;

@Slf4j
public final class Utils {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(
            "yyyy-MM-dd");

    private static final Map<Class, Method> pptStmtTypeMethodMap
            = StorageUtils.typeMethodMapForPreparedStmt();

    public static Date toDate(String dateString) {
        if (StringUtils.isBlank(dateString)) {
            throw new IllegalArgumentException("Date string is blank");
        }
        return Date.valueOf(LocalDate.parse(dateString, DATE_TIME_FORMATTER));
    }

    public static String toString(Exception ex) {
        StringWriter out = new StringWriter();
        PrintWriter printWriter = new PrintWriter(out);
        ex.printStackTrace(printWriter);
        printWriter.close();
        return out.toString();
    }

    public static PreparedStatement prepareStatement(Connection c,
                                                     String query,
                                                     List<Pair<Class, String>> params) throws SQLException {
        PreparedStatement statement = c.prepareStatement(query,
                ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);
        int index = 1;
        for (var entry : params) {
            Class type = entry.getKey();
            Method method = pptStmtTypeMethodMap.get(type);
            if (method == null) {
                throw new IllegalStateException("Could not find setter for type: " + type);
            }
            try {
                method.invoke(statement, index++, instantiate(type, entry.getValue()));
            } catch (Exception e) {
                log.debug("Failed to set value of some param Method: " + method.getName(), e);
            }
        }
        return statement;
    }

    public static Properties loadFile(String fileProperty, PowerPayConfiguration configuration, ConfigResourceLoader loader) {
        Properties properties = new Properties();
        String columnsFile = configuration.getProperty(fileProperty);
        if (StringUtils.isBlank(columnsFile)) {
            return properties;
        }

        log.info("Columns File: {}", columnsFile);

        Resource resource = loader.getResource(columnsFile);

        if (resource == null) {
            log.warn("Could not find Columns file: {}", columnsFile);
            return properties;
        }

        try (InputStream inputStream = resource.getInputStream()) {
            properties.load(inputStream);
        } catch (IOException e) {
            log.warn("Failed to load columns file: {}", columnsFile, e);
        }

        return properties;
    }

    public static void dynamicConditionBuilder(Map<String, String> conditionalMap, LinkedList<Pair<Class, String>> params, StringBuilder condition) {
        var reduceCount = new Object(){ int count=conditionalMap.size(); };
        conditionalMap.forEach((key,value) -> {
            if(value.contains("-"))
                params.add(Pair.of(Date.class, value));
            else
                params.add(Pair.of(String.class, value));

            condition.append(" ").append(key).append(reduceCount.count == 1 ? " = ? " :" = ?  and ");
            reduceCount.count --;
        });
    }
}
