package com.ascent.powerpay.rbac;

import com.ascent.powerpay.kernel.init.RequestIdFilter;
import com.ascent.powerpay.kernel.security.TenantContextFilter;
import com.ascent.powerpay.kernel.tenant.TenantInfo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.headers.RequestHeadersSnippet;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;


import static org.springframework.restdocs.headers.HeaderDocumentation.headerWithName;
import static org.springframework.restdocs.headers.HeaderDocumentation.requestHeaders;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;

@ExtendWith({RestDocumentationExtension.class, SpringExtension.class})
@Slf4j
public abstract class AbstractRestDocumentationTestCase extends AbstractRbacIntegrationTestcase {

    protected static final String ROOT_DIR = System.getProperty("user.dir");
    @Autowired
    protected WebApplicationContext context;
    protected MockMvc mockMvc;

    @BeforeEach
    void setUp(RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context)
                .addFilter(new RequestIdFilter())
                .addFilter(new TenantContextFilter())
                .apply(documentationConfiguration(restDocumentation))
                .build();
    }

    protected RequestHeadersSnippet tenantHeader() {
        return requestHeaders(headerWithName(TenantInfo.TENANT_ID_KEY)
                .description("Tenant Id for whom this operation must be performed"));
    }

}
