package com.Ascentproject.report.service;


import com.Ascentproject.report.domain.ReportFilterField;
import java.util.List;

public interface ReportFilterFieldService {
    List<ReportFilterField> saveReportFilterField(int reportId, List<ReportFilterField> reportDataSourceList);
    int findByReportId(int reportId);
    List<ReportFilterField> updateFilterField(int reportId, List<ReportFilterField> reportFilterFieldList);
    List<ReportFilterField> getReportFilterField(int reportId);
}
