package com.ascent.powerpay.rbac.integrationTest;

import com.ascent.powerpay.kernel.tenant.TenantInfo;
import com.ascent.powerpay.rbac.AbstractRestDocumentationTestCase;
import com.ascent.powerpay.rbac.TestUtil;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Privilege;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import javax.validation.constraints.NotNull;

import java.io.IOException;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
class PrivilegeTests extends AbstractRestDocumentationTestCase {

    @Autowired
    TestUtil testUtil;

    @BeforeEach
    public void createManagedEntity() throws Exception
    {
        ManagedEntity managedEntity = testUtil.getManagedEntity("entityCode1",
                "entityType1", "entityName1");
        managedEntity = testUtil.addManagedEntityAPI(this.mockMvc, managedEntity);
        assertNotNull(managedEntity);
        assertEquals("entityCode1", managedEntity.getCode());
        assertEquals("entityType1", managedEntity.getType());
        assertEquals("entityName1", managedEntity.getName());
    }

    @NotNull
    private Privilege getPrivilege(String code, String function, String action)  {
        Privilege privilege = new Privilege();
        privilege.setCode(code);
        privilege.setFunction(function);
        privilege.setAction(action);
        return privilege;
    }

    private Privilege addPrivilegeAPI(Privilege me) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/privilege/managedentity/entityCode1")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        Privilege privilegeResult = getPrivilege(mvcResult);
        return privilegeResult;
    }

    private Privilege getPrivilege(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Privilege.class);
    }

    @Test
    public void testSavePrivilege() throws Exception
    {
        Privilege privilege = getPrivilege("code1", "report1", "read");
        privilege = addPrivilegeAPI(privilege);
        assertNotNull(privilege);
        assertEquals("code1", privilege.getCode());
        assertEquals("report1", privilege.getFunction());
        assertEquals("read", privilege.getAction());
    }

    @Test
    public void testGetPrivilegeById() throws Exception {
        Privilege privilege = getPrivilege("code2","report2", "update");
        privilege = addPrivilegeAPI(privilege);
        String id = privilege.getId();

        privilege = getPrivilegeById(id);
        assertNotNull(privilege);
        assertEquals("code2", privilege.getCode());
        assertEquals("report2", privilege.getFunction());
        assertEquals("update", privilege.getAction());
    }

    private Privilege getPrivilegeById(String id) throws Exception {
        Privilege privilege;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/privilege/managedentity/entityCode1/privilege/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        privilege = getPrivilege(mvcResult);
        return privilege;
    }

    @Test
    public void testGetPrivilegeByCode() throws Exception {
        Privilege privilege = getPrivilege("code3", "report3", "modify");
        privilege = addPrivilegeAPI(privilege);
        String code = privilege.getCode();

        privilege = getPrivilegeByCode(code);
        assertNotNull(privilege);
        assertEquals("code3", privilege.getCode());
        assertEquals("report3", privilege.getFunction());
        assertEquals("modify", privilege.getAction());
    }

    private Privilege getPrivilegeByCode(String code) throws Exception {
        Privilege privilege;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/privilege/managedentity/entityCode1/privilege/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("privilegeCode", code)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        Privilege[] privilegeArray = getPrivilegeArray(mvcResult);
        assertEquals(1, privilegeArray.length);
        return privilegeArray[0];
    }

    private Privilege[] getPrivilegeArray(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Privilege[].class);
    }

    @Test
    public void testGetAllPrivilege() throws Exception {
        Privilege privilege = getPrivilege("code4", "report4", "read");
        privilege = addPrivilegeAPI(privilege);

        assertEquals("code4", privilege.getCode());
        assertEquals("report4", privilege.getFunction());
        assertEquals("read", privilege.getAction());

        privilege = getPrivilege("code5", "report5",
                "read");
        privilege = addPrivilegeAPI(privilege);

        Privilege[] result = getAllPrivilege();
        assertNotNull(result);
        assertTrue(result.length == 2);
    }

    private Privilege[] getAllPrivilege() throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/privilege/managedentity/entityCode1/privilege/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        Privilege[] privilegeResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Privilege[].class);
        return privilegeResult;
    }

    @Test
    public void testUpdatePrivilege() throws Exception
    {
        Privilege privilege = getPrivilege("code6", "report6", "read and write");
        privilege = addPrivilegeAPI(privilege);
        privilege.setFunction("updatedPrivilegeFunction");
        privilege.setAction("updatedPrivilegeAction");
        String code = privilege.getCode();
        updatePrivilegeAPI(privilege);
        privilege = getPrivilegeByCode(code);


        assertNotNull(privilege);
        assertEquals("code6", privilege.getCode());
        assertEquals("updatedPrivilegeFunction", privilege.getFunction());
        assertEquals("updatedPrivilegeAction", privilege.getAction());
    }

    private Privilege updatePrivilegeAPI(Privilege me) throws Exception {

        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/privilege/managedentity/entityCode1/privilege/" + me.getCode())
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        Privilege privilegeResult = getPrivilege(mvcResult);
        return privilegeResult;

    }

    @Test
    public void testDeletePrivilegeById() throws Exception {
        Privilege privilege = getPrivilege("code7", "report7", "read and write");
        privilege = addPrivilegeAPI(privilege);
        String id = privilege.getId();

        delete(id);
        try {
            this.mockMvc.perform(RestDocumentationRequestBuilders
                            .get("/manage/privilege/managedentity/entityCode1/privilege/" + id)
                            .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                            .accept(MediaType.APPLICATION_JSON))
                    .andExpect(status().isBadRequest());

        } catch (final Exception e) {
            fail("object status should have been saved.");
        }
    }

    @Test
    public void testDeletePrivilegeByCode() throws Exception {
        Privilege privilege = getPrivilege("code8", "report8", "read and write");
        privilege = addPrivilegeAPI(privilege);
        String code = privilege.getCode();

        markForDelete(code);
        try
        {
            Privilege Privilege1 = getPrivilegeByCode(code);
            assertFalse(Privilege1.isActive());
        }
        catch (final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private void markForDelete(String code) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/privilege/managedentity/entityCode1/privilege/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("privilegecode", code)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

    private void delete(String id) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/privilege/managedentity/entityCode1/privilege/internal/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

}
