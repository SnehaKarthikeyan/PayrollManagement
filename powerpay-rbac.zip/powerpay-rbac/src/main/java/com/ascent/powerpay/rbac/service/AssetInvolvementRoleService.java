package com.ascent.powerpay.rbac.service;


import com.ascent.powerpay.rbac.domain.AssetInvolvementRole;
import com.ascent.powerpay.rbac.exception.NotFoundException;

import java.util.List;

public interface AssetInvolvementRoleService
{

    AssetInvolvementRole saveAssetInvolvementRole(String managedEntity_Id, String privilege_Id,
                                                  String permission_Id, String userRole_Id,
                                                  AssetInvolvementRole assetInvolvementRole) throws NotFoundException;

    AssetInvolvementRole getAssetInvolvementRoleById(String assetInvolvementRole_id)
            throws NotFoundException;

    AssetInvolvementRole getAssetInvolvementRoleByCode(String assetInvolvementRole_Code)
            throws NotFoundException;

    List<AssetInvolvementRole> getAllAssetInvolvementRole() throws NotFoundException;

    AssetInvolvementRole updateAssetInvolvementRole(String managedEntity_Id, String privilege_Id,
                                                  String permission_Id, String userRole_Id,
                                                  String assetInvolvement_Id,
                                                  AssetInvolvementRole assetInvolvementRole) throws NotFoundException;

    void deleteAssetInvolvementRoleById(String individualParty_Code) throws NotFoundException;

    void deleteAssetInvolvementRoleByCode(String individualParty_Code) throws NotFoundException;

}
