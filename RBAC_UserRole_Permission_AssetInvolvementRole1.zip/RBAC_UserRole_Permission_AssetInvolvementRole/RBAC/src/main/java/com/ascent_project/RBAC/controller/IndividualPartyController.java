package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.exception.NotFoundException;
import com.ascent_project.RBAC.model.IndividualParty;
import com.ascent_project.RBAC.service.IndividualPartyServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class IndividualPartyController {
    @Autowired
    private IndividualPartyServiceImpl individualPartyService;

    @GetMapping
    public ResponseEntity<?> getAllIndividualParty() {
        ResponseEntity<?> responseEntity=null;
        try {
            List<IndividualParty> list= individualPartyService.getAllIndividualParty();
            responseEntity= new ResponseEntity<List<IndividualParty>>(list,HttpStatus.OK);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get All Individual Party",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
    @GetMapping("/{id}")
    public ResponseEntity<?> getOneIndividualParty(@PathVariable Long id){
        ResponseEntity<?> responseEntity = null;
        try {
            IndividualParty individualParty= individualPartyService.getOneIndividualParty(id);
            responseEntity = new ResponseEntity<IndividualParty>(individualParty,HttpStatus.OK);
        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception e) {
            e.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to find Individual Party ID",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteIndividualParty(@PathVariable Long id){

        ResponseEntity<String> responseEntity= null;
        try {
            individualPartyService.deleteIndividualParty(id);
            responseEntity= new ResponseEntity<String> (
                    "Individual Party '"+id+"' deleted",HttpStatus.OK);

        }
        catch (NotFoundException nfe) {
            throw nfe;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Individual Party", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }

    @PostMapping
    public ResponseEntity<String> saveIndividualParty(@RequestBody IndividualParty individualParty){
        ResponseEntity<String> responseEntity = null;
        try{
            Long id = individualPartyService.saveIndividualParty(individualParty);
            responseEntity= new ResponseEntity<String>(
                    "Individual Party'"+id+"' created",HttpStatus.CREATED); //201-created
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Individual Party",
                    HttpStatus.INTERNAL_SERVER_ERROR); //500-Internal Server Error
        }
        return responseEntity;
    }


}
