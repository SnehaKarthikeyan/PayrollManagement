package com.report.ReportGroup.Service.Impl;

import com.report.ReportGroup.Domain.ReportGroup;
import com.report.ReportGroup.Repository.ReportGroupRepository;
import com.report.ReportGroup.Service.ReportGroupService;
import com.report.ReportGroup.exception.NotFoundException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportGroupServiceImpl implements ReportGroupService {
    @Autowired
    private ReportGroupRepository reportGroupRepository;

    @Override
    public ReportGroup saveReportGroup(ReportGroup reportGroup) {
        boolean exists = false;
        if(reportGroup.getId() != 0) {
            exists = reportGroupRepository.existsById(reportGroup.getId());
        }
        if(exists) {
            return null;
        }
        reportGroup.setActive(true);
        ReportGroup reportGroup1 = reportGroupRepository.save(reportGroup);
        return reportGroup1;
    }

    @Override
    public ReportGroup getReportGroupById(int reportGroupId) {
        ReportGroup reportGroup1 = null;
        ReportGroup reportGroup = reportGroupRepository.findById(reportGroupId)
                .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Report Group  '")
                                .append(reportGroupId)
                                .append("' not exist")
                                .toString()));
        if(reportGroup.isActive()){ reportGroup1 = reportGroup; }
        return reportGroup1;
    }

    @Override
    public ReportGroup getReportGroupByCode(String reportGroupCode) {
        ReportGroup reportGroup;
        ReportGroup reportGroup1 = null;
        reportGroup = reportGroupRepository.findByCode(reportGroupCode);
        if(reportGroup.isActive()) { reportGroup1 = reportGroup; }
        return reportGroup1;
    }

    @Override
    public List<ReportGroup> getAllReportGroup() {
        List<ReportGroup> list = reportGroupRepository.findAll();
        List<ReportGroup> result = new ArrayList<ReportGroup>();
        for(ReportGroup reportGroup : list) {
            if(reportGroup.isActive()) { result.add(reportGroup); }
        }
        List<ReportGroup> sortedList = result.stream()
                .sorted(Comparator.comparing(ReportGroup::getSortOrder))
                .collect(Collectors.toList());
        return sortedList;
    }

    @Override
    public List<ReportGroup> updateReportGroup(String reportGroupCode, ReportGroup reportGroup) {
        ReportGroup reportGroup1 = reportGroupRepository.findByCode(reportGroupCode);
        reportGroup1.setActive(true);
        BeanUtils.copyProperties(reportGroup1, reportGroup);
        reportGroupRepository.save(reportGroup1);
        List<ReportGroup> result = getAllReportGroup();
        return result;
    }

    @Override
    public void deleteReportGroupById(int reportGroupId) {
        ReportGroup reportGroup = getReportGroupById(reportGroupId);
        reportGroup.setActive(false);
        reportGroupRepository.save(reportGroup);
    }

    @Override
    public void deleteReportGroupByCode(String reportGroupCode) {
        ReportGroup reportGroup = getReportGroupByCode(reportGroupCode);
        reportGroup.setActive(false);
        reportGroupRepository.save(reportGroup);
    }
}
