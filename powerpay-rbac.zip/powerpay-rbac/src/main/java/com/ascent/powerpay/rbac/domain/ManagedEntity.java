package com.ascent.powerpay.rbac.domain;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Table(name = "managed_entity")
@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class ManagedEntity
{

        @Id
        @GeneratedValue(generator = "system-uuid")
        @GenericGenerator(name = "system-uuid", strategy = "uuid")
        @Column(name = "ID")
        private String id;

        @Column(name = "CODE")
        private String code;

        @Column(name = "ENTITY_TYPE")
        private String type;

        @Column(name = "ACTIVE")
        private boolean active;

        @Column(name = "ENTITY_NAME")
        private String name;

}



