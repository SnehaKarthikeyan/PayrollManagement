package com.ascent_project.RBAC.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="USER_ROLE")
public class UserRole {
    
    @Id
    @Column(name = "ID")
    private Long id;

   @ManyToOne
   @JoinColumn(name = "ROLE_ID")
   @OnDelete(action=OnDeleteAction.CASCADE)
    private Role role;

    @ManyToOne
    @JoinColumn(name = "USER_ID")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private IndividualParty individual_Party;

    @ManyToOne
    @JoinColumn(name = "MANAGED_ENTITY_ID")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private ManagedEntity managedEntity;

    @Column(name = "VALID_FOR")
    private String valid_for;

    public UserRole(long id, ManagedEntity managedEntity,Role role, IndividualParty user, String valid_for) {
        this.id=id;
        this.managedEntity=managedEntity;
        this.role=role;
        this.individual_Party=user;
        this.valid_for=valid_for;
    }
    public String toString()
    {
     return valid_for;
    }
}
