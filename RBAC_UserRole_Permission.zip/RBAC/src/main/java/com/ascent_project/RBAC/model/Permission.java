package com.ascent_project.RBAC.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Permission")
public class Permission {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "Name")
    private String name;

    @Column(name = "Description")
    private String description;

    @Column(name = "ValidFor")
    private String validFor;

    @ManyToOne
    @JoinColumn(name = "managedEntity_id")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private ManagedEntity managedEntity;

    public Permission(long id, ManagedEntity managedEntity,String name, String description, String valid_for) {
        this.id=id;
        this.managedEntity=managedEntity;
        this.name=name;
        this.description=description;
        this.validFor=valid_for;
    }
}
