package com.example.privilege.service.impl;

import com.example.privilege.exception.NotFoundException;
import com.example.privilege.model.ManagedEntity;
import com.example.privilege.model.MenuPrivilege;
import com.example.privilege.repository.ManagedEntityRepository;
import com.example.privilege.repository.MenuPrivilegeRepository;
import com.example.privilege.service.PrivilegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
@Service
public class PrivilegeServiceImpl implements PrivilegeService {

    @Autowired
    private MenuPrivilegeRepository menuPrivilegeRepository;
    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public List<MenuPrivilege> getPrivileges(String managedEntityCode) {
        String managedEntityId=getManagedEntity(managedEntityCode);

        List<MenuPrivilege> privilege= menuPrivilegeRepository.sortMenuOrder().stream().filter(menu->menu.getManagedEntityId()==managedEntityId)
                .filter(menu-> Objects.isNull(menu.getParent()))
                .collect(Collectors.toList());

        privilege.stream().forEach(p -> p.getChildren().sort(Comparator.comparing(MenuPrivilege::getMenuOrder)));

        return privilege;

    }


    public List<MenuPrivilege> savePrivilege(String managedEntityCode,List<MenuPrivilege> menuPrivilegeList) {
          String managedEntityId=getManagedEntity(managedEntityCode);
          for(MenuPrivilege menuPrivilege:menuPrivilegeList)
              menuPrivilege.setManagedEntityId(managedEntityId);
          return  menuPrivilegeRepository.saveAll(menuPrivilegeList);

        }

    public MenuPrivilege findPrivilegeByCode(String managedEntityCode,String privilegeCode) {
        String managedEntityId=getManagedEntity(managedEntityCode);
        MenuPrivilege menuPrivilege= menuPrivilegeRepository.findByManagedEntityIdAndCode(managedEntityId,privilegeCode);
        return menuPrivilege;
    }
    public MenuPrivilege findPrivilegeById(String managedEntityCode,String privilegeId) {

        String managedEntityId=getManagedEntity(managedEntityCode);
        MenuPrivilege menuPrivilege= menuPrivilegeRepository.findByManagedEntityIdAndId(managedEntityId,privilegeId);
        return menuPrivilege;
    }

    public MenuPrivilege mapPrivilegeItem(String managedEntityCode,String parentCode, String childCode) {
        String managedEntityId=getManagedEntity(managedEntityCode);
        MenuPrivilege parent= menuPrivilegeRepository.findByCode(parentCode);
        MenuPrivilege child= menuPrivilegeRepository.findByCode(childCode);
        child.setParent(parent);
       return menuPrivilegeRepository.save(child);
    }
    public String getManagedEntity(String managedEntityCode) throws NotFoundException {
        String managedEntityId = managedEntityRepository.findByCode(managedEntityCode);
        if(managedEntityId== null) throw new NotFoundException(managedEntityCode + " Managed Entity Not Found");
        return managedEntityId;
    }


    public MenuPrivilege updatePrivilege(MenuPrivilege menuPrivilege) {
        return menuPrivilegeRepository.save(menuPrivilege);
    }

    public  void deleteOnePrivilegeByCode(String managedEntityCode,String  privilegeCode)
    {
        String managedEntityId = managedEntityRepository.findByCode(managedEntityCode);
        MenuPrivilege menuPrivilege= menuPrivilegeRepository.findByCode(privilegeCode);
        menuPrivilegeRepository.delete(menuPrivilege);
    }

    public void deleteOnePrivilegeById(String managedEntityCode,String privilegeId) {
        String managedEntityId = managedEntityRepository.findByCode(managedEntityCode);
        MenuPrivilege menuPrivilege= menuPrivilegeRepository.findByManagedEntityIdAndCode(managedEntityId,privilegeId);
        menuPrivilegeRepository.delete(menuPrivilege);
    }
}

