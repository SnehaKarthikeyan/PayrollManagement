package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.kernel.PowerPayService;
import com.ascent.powerpay.kernel.cache.PowerPayCache;
import com.ascent.powerpay.kernel.tenant.TenantUtil;
import com.ascent.powerpay.rbac.domain.Employee;
import com.ascent.powerpay.rbac.domain.EmployeeHistory;
import com.ascent.powerpay.rbac.repository.EmployeeCrudRepository;
import com.ascent.powerpay.rbac.repository.EmployeeHistoryRepository;
import com.ascent.powerpay.rbac.service.EmployeeService;
import io.prometheus.client.Counter;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
@Transactional
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

    private final Counter counter =
            Counter.build().name("employee_count").labelNames("tenantId").help("Employee Count.")
                    .register();
    private EmployeeCrudRepository repository;
    private EmployeeHistoryRepository historyRepository;
    private EntityManager entityManager;
    private PowerPayCache cache;
    private Logger attributeChangeLogger = LoggerFactory.getLogger("attributeChange");
    private Logger employeeJoinedLogger = LoggerFactory.getLogger("employeeJoined");

    @Autowired
    public EmployeeServiceImpl(EmployeeCrudRepository repository,
                               EmployeeHistoryRepository historyRepository,
                               EntityManager entityManager,
                               PowerPayCache cache) {
        this.repository = repository;
        this.historyRepository = historyRepository;
        this.entityManager = entityManager;
        this.cache = cache;
    }

    public void save(String employeeId, Map<String, Object> properties, String effectiveDate) {
        save(new Employee(employeeId, properties, effectiveDate));
    }

    public void cleanUp() {
        repository.deleteAll();
    }

//    @Override
//    public void save(Employee employee) {
//
//    }

    @PowerPayService(value = "employee", internal = true)
    public void save(Employee employee) {
        counter.labels(TenantUtil.getTenantId()).inc();
        EmployeeHistory history = new EmployeeHistory(employee);
        try {

            Employee existingEmployee = repository.findByEmployeeId(employee.getEmployeeId());

            if (existingEmployee == null) {
                //log.debug("No existing employee found...saving new one: {}", employee);
                history = new EmployeeHistory(repository.save(employee));
                employeeJoinedLogger.info("New Employee Joined with Employee id {} Employee Code {} : {} ", employee.getId(), employee.getCode(), employee.getProperties());
                return;
            }

            if (employee.earlierThan(existingEmployee)) {
                //log.debug("New employee version is older, ignoring event. " +
                        //"New: {}, Old:{}", employee, existingEmployee);
                return;
            }
           // log.debug("Computing variancefor employee : {}", employee);
           // log.debug("Replacing existing employee with new one: {}", employee);
            repository.delete(existingEmployee);
            entityManager.flush();

            history = new EmployeeHistory(repository.save(employee));
            attributeChangeLogger.info("Updated Employee with employee code {} \nfrom {} \nto {}", employee.getCode(), existingEmployee.getProperties(), employee.getProperties());

        } catch (Exception e) {
           // log.error("Employee save failed", e);
            history.addException(e);
        } finally {
            historyRepository.save(history);

        }
    }

    public Employee employeeFor(String employeeId) {
        return cache.get(employeeId, () -> repository.findByEmployeeId(employeeId));
    }

    @Override
    public List<String> getChanges(Date rangeStart, Date rangeEnd) {
        List<String> idList = new ArrayList<>();
        List<Employee> EmployeeList = repository.findBymodifiedOnBetween(rangeStart, rangeEnd);
        for (Employee employee : EmployeeList) {
            idList.add(employee.getId());
        }
        return idList;
    }
}
