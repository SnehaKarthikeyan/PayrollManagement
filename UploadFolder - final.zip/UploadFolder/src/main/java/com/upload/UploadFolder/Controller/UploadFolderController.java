package com.upload.UploadFolder.Controller;

import com.upload.UploadFolder.Domain.UploadFolder;
import com.upload.UploadFolder.Service.UploadFolderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/uploadfolder","/manage/uploadfolder"})
public class UploadFolderController {
    @Autowired
    private UploadFolderService uploadFolderService;

    @PostMapping
    public ResponseEntity<?> saveUploadFolder(@RequestBody List<UploadFolder> uploadFolders) {
        ResponseEntity<List<UploadFolder>> responseEntity = null;
        try {
            for(UploadFolder uploadFolder1: uploadFolders) {
                uploadFolderService.saveUploadFolder(uploadFolder1);
            }
            responseEntity = new ResponseEntity<List<UploadFolder>>(uploadFolders, HttpStatus.CREATED);
        } catch(Exception e) {
            log.debug("Unable to save Upload Folder");
            responseEntity = new ResponseEntity<List<UploadFolder>>(uploadFolders, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/search")
    public ResponseEntity<?> getUploadFolderById(@RequestParam("id") int uploadFolderId) {
        ResponseEntity<?> responseEntity= null;
        UploadFolder uploadFolder = null;
        try {
            uploadFolder = uploadFolderService.getUploadFolderById(uploadFolderId);
            responseEntity= new ResponseEntity<UploadFolder>(uploadFolder,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Upload Folder");
            responseEntity = new ResponseEntity<String>("Unable to get Upload Folder", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping
    public ResponseEntity<?> getAllUploadFolder() {
        ResponseEntity<?> responseEntity= null;
        try {
            List<UploadFolder> uploadFolders= uploadFolderService.getAllUploadFolder();
            responseEntity= new ResponseEntity<List<UploadFolder>>(uploadFolders,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Upload Folder");
            responseEntity = new ResponseEntity<String>("Unable to get Upload Folder", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{clientId}")
    public ResponseEntity<?> getUploadFolderByClientId(@PathVariable("clientId") int clientId) {
        ResponseEntity<?> responseEntity= null;
        List<UploadFolder> uploadFolders = null;
        try {
            uploadFolders = uploadFolderService.getUploadFolderByClientId(clientId);
            responseEntity= new ResponseEntity<List<UploadFolder>>(uploadFolders,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Upload Folder");
            responseEntity = new ResponseEntity<String>("Unable to get Upload Folder", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }


    @PutMapping("/{uploadFolderId}")
    public ResponseEntity<?> updateUploadFolder(@PathVariable("uploadFolderId") int uploadFolderId,
                                                @RequestBody UploadFolder uploadFolder) {
        ResponseEntity<?> responseEntity = null;
        List<UploadFolder> uploadFolder1 = null;
        try {
            uploadFolder1 = uploadFolderService.updateUploadFolder(uploadFolderId, uploadFolder);
            responseEntity = new ResponseEntity<List<UploadFolder>>(uploadFolder1, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to update Upload Folder");
            responseEntity = new ResponseEntity<String>("Unable to update Upload Folder", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping
    public ResponseEntity<?> deleteUploadFolderById(@RequestParam("id") int uploadFolderId) {
        ResponseEntity<?> responseEntity= null;
        try {
            uploadFolderService.deleteUploadFolderById(uploadFolderId);
            responseEntity = new ResponseEntity<String> ("Upload Folder '"+uploadFolderId+"' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Upload Folder");
            responseEntity = new ResponseEntity<String>("Unable to delete Upload Folder", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}

