package com.example.privilege.service;

import com.example.privilege.model.MenuPrivilege;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public interface PrivilegeService {
    public List<MenuPrivilege> getPrivileges(String managedEntityCode);
    public List<MenuPrivilege> savePrivilege(String managedEntityCode,List<MenuPrivilege> menuPrivilegeList);
    public MenuPrivilege findPrivilegeByCode(String managedEntityCode,String privilegeCode);
    public MenuPrivilege mapPrivilegeItem(String managedEntityCode,String parentCode, String childrenCode);
    public MenuPrivilege updatePrivilege(MenuPrivilege privilegeDB);
    public  void deleteOnePrivilegeByCode(String managedEntityCode,String privilegeCode);
    public void deleteOnePrivilegeById(String managedEntityCode,String privilegeId);
    public MenuPrivilege findPrivilegeById(String managedEntityCode,String privilegeId);
    public String getManagedEntity(String managedEntityCode);
}


