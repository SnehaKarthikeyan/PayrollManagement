package com.ascent.powerpay.rbac.integrationTest;

import com.ascent.powerpay.kernel.tenant.TenantInfo;
import com.ascent.powerpay.rbac.AbstractRestDocumentationTestCase;
import com.ascent.powerpay.rbac.TestUtil;
import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import javax.validation.constraints.NotNull;

import java.io.IOException;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
class IndividualPartyTests extends AbstractRestDocumentationTestCase {

    @Autowired
    TestUtil testUtil;

    @Test
    public void testSaveIndividualParty() throws Exception
    {
        IndividualParty individualParty = testUtil.getIndividualParty("code1","name1");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);
        assertNotNull(individualParty);
        assertEquals("code1", individualParty.getCode());
        assertEquals("name1", individualParty.getName());
    }

    @Test
    public void testGetIndividualPartyById() throws Exception {
        IndividualParty individualParty = testUtil.getIndividualParty("code2","name2");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);
        String id = individualParty.getId();

        individualParty = getIndividualPartyById(id);
        assertNotNull(individualParty);
        assertEquals("code2", individualParty.getCode());
        assertEquals("name2", individualParty.getName());
    }

    private IndividualParty getIndividualPartyById(String id) throws Exception {
        IndividualParty individualParty;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/user/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        individualParty = testUtil.getIndividualParty(mvcResult);
        return individualParty;
    }

    @Test
    public void testGetIndividualPartyByCode() throws Exception {
        IndividualParty individualParty = testUtil.getIndividualParty("code3", "name3");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);
        String code = individualParty.getCode();

        individualParty = getIndividualPartyByCode(code);
        assertNotNull(individualParty);
        assertEquals("code3", individualParty.getCode());
        assertEquals("name3", individualParty.getName());
    }

    private IndividualParty getIndividualPartyByCode(String code) throws Exception {
        IndividualParty individualParty;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/user")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("userCode", code)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        IndividualParty[]  individualPartyArray = getIndividualPartyArray(mvcResult);
        assertEquals(1, individualPartyArray.length);
        return individualPartyArray[0];
    }

    private IndividualParty[] getIndividualPartyArray(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), IndividualParty[].class);
    }

    @Test
    public void testGetAllIndividualParty() throws Exception {
        IndividualParty individualParty = testUtil.getIndividualParty("code4", "name4");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);

        assertEquals("code4", individualParty.getCode());
        assertEquals("name4", individualParty.getName());

        individualParty = testUtil.getIndividualParty("code5",
                "name5");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);

        ManagedEntity[] result = getAllIndividualParty();
        assertNotNull(result);
        assertTrue(result.length == 2);
    }

    private ManagedEntity[] getAllIndividualParty() throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/user")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        ManagedEntity[] managedEntityResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), ManagedEntity[].class);
        return managedEntityResult;
    }

    @Test
    public void testUpdateIndividualParty() throws Exception
    {
        IndividualParty individualParty = testUtil.getIndividualParty("code6", "name6");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);
        individualParty.setName("updatedIndividualPartyName");
        String code = individualParty.getCode();

        updateIndividualPartyAPI(individualParty);
        individualParty = getIndividualPartyByCode(code);


        assertNotNull(individualParty);
        assertEquals("code6", individualParty.getCode());
        assertEquals("updatedIndividualPartyName", individualParty.getName());
    }

    private IndividualParty updateIndividualPartyAPI(IndividualParty me) throws Exception {

        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/user/" + me.getCode())
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        IndividualParty individualPartyResult = testUtil.getIndividualParty(mvcResult);
        return individualPartyResult;

    }

    @Test
    public void testDeleteIndividualPartyById() throws Exception {
        IndividualParty individualParty = testUtil.getIndividualParty("code7", "name7");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);
        String id = individualParty.getId();
        delete(id);
        try {
            this.mockMvc.perform(RestDocumentationRequestBuilders
                            .get("/manage/user/" + id)
                            .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                            .accept(MediaType.APPLICATION_JSON))
                    .andExpect(status().isBadRequest());

        } catch (final Exception e) {
            fail("object status should have been saved.");
        }
    }

    @Test
    public void testDeleteIndividualPartyByCode() throws Exception {
        IndividualParty individualParty = testUtil.getIndividualParty("code8", "name8");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);
        String code = individualParty.getCode();
        markForDelete(code);
        try
        {
            IndividualParty individualParty1 = getIndividualPartyByCode(code);
            assertFalse(individualParty1.isActive());
        }
        catch (final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private void markForDelete(String code) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/user/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("userCode", code)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

    private void delete(String id) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/user/internal/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

}
