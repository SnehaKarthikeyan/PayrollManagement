package com.ascent.powerpay.rbac;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import java.io.File;
import java.io.IOException;

public abstract class AbstractRbacTestcase {
    protected static final String TEST_TENANT = "user_permission_test";

    private static final String TEMP_TEST_DIR;

    private static final File projectRootDirectory = projectRootDirectory();

    protected static File tempDir;


    static {
        TEMP_TEST_DIR = projectRootDirectory + "/tmp";
    }

    private static File projectRootDirectory() {
        String testClassesRoot = AbstractRbacTestcase.class.getProtectionDomain().getCodeSource().getLocation().getFile();
        File rootDir = new File(testClassesRoot + "../..");
        try {
            return rootDir.getCanonicalFile();
        } catch (IOException e) {
            throw new RuntimeException("Failed to find project root directory", e);
        }
    }

    @BeforeClass
    public static void initTestTempDirectory() throws Exception {
        tempDir = new File(TEMP_TEST_DIR);
        if (tempDir.exists()) {
            FileUtils.forceDelete(tempDir);
        }
        tempDir.mkdirs();
    }

    @AfterClass
    public static void removeTempDirectory() throws Exception {
        FileUtils.forceDelete(tempDir);
    }

}
