package com.ascentProject.rbac.domain;


import lombok.*;


import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorColumn(name = "Dtype", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("MENU")

public class MenuPrivilege extends Privilege {

    @Column(name = "menu_order")
    private String order;

}

