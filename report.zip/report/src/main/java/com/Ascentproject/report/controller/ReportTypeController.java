package com.Ascentproject.report.controller;


import com.Ascentproject.report.domain.ReportType;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.ReportTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/reporttype", "/manage/reporttype"})

public class ReportTypeController {
    @Autowired
    private ReportTypeService reportTypeService;

    @CrossOrigin
    @PostMapping
    public ResponseEntity<?> saveReportType(@RequestBody List<ReportType> reportTypeList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<ReportType> reportTypeList1= reportTypeService.saveReportType(reportTypeList);
            if(reportTypeList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save ReportType ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<ReportType>>(
                    reportTypeList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save ReportType ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @GetMapping
    public ResponseEntity<?> getAllReportType() throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<ReportType> reportTypeList = reportTypeService.getReportType();
            resp= new ResponseEntity<List<ReportType>>(
                    reportTypeList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("ReportType doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}