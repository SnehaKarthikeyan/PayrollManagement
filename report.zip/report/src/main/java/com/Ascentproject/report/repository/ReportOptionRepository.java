package com.Ascentproject.report.repository;

public interface ReportOptionRepository {
}
