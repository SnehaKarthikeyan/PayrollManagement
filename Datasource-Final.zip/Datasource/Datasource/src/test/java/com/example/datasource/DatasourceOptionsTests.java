package com.example.datasource;

import com.example.datasource.domain.Datasource;
import com.example.datasource.domain.DatasourceOptions;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@Transactional
class DatasourceOptionsTests extends DatasourceTests{
    @Autowired
    private MockMvc mockMvc;

    @NotNull
    private DatasourceOptions getDatasourceOptions(long datasourceId, String controlColumn, String controlLabel, String controlTypeId,
                                    String controlValue, String controlText, long controlDatasourceId, long recordStatusId) {
        DatasourceOptions datasourceOptions = new DatasourceOptions();
        datasourceOptions.setDatasourceId(datasourceId);
        datasourceOptions.setControlColumn(controlColumn);
        datasourceOptions.setControlLabel(controlLabel);
        datasourceOptions.setControlTypeId(controlTypeId);
        datasourceOptions.setControlValue(controlValue);
        datasourceOptions.setControlText(controlText);
        datasourceOptions.setControlDatasourceId(controlDatasourceId);
        datasourceOptions.setRecordStatusId(recordStatusId);
        return datasourceOptions;
    }

    private DatasourceOptions getDatasourceOptions(MvcResult mvcResult) throws IOException{
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), DatasourceOptions.class);
    }

    private List<DatasourceOptions> addDatasourceOptionsAPI(String datasourceCode, List<DatasourceOptions> datasourceOptions) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(datasourceOptions);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/datasourceoptions/" + datasourceCode)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        List<DatasourceOptions> datasourceOptionsResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<DatasourceOptions>>(){});
        return datasourceOptionsResult;
    }

    private DatasourceOptions getDatasourceOptionsById(String datasourceCode, long id) throws Exception {
        DatasourceOptions datasourceOptions;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datasourceoptions/" + datasourceCode + "/search")
                        .param("id", String.valueOf(id))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        datasourceOptions = getDatasourceOptions(mvcResult);
        return datasourceOptions;
    }

    private DatasourceOptions[] getAllDatasourceOptions(String datasourceCode) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datasourceoptions/" + datasourceCode)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        DatasourceOptions[] datasourceOptionsResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), DatasourceOptions[].class);
        return datasourceOptionsResult;
    }

    private DatasourceOptions updateDatasourceOptionsAPI(String datasourceCode, DatasourceOptions datasourceOptions) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(datasourceOptions);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/datasourceoptions/" + datasourceCode + "/" +datasourceOptions.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        DatasourceOptions datasourceOptionsResult = getDatasourceOptions(mvcResult);
        return datasourceOptionsResult;
    }

    @Test
    public void testSaveDatasourceOptions() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceOptions> datasourceOptions = new ArrayList<DatasourceOptions>();
        datasourceOptions.add(getDatasourceOptions(datasource.get(0).getId(), "col1", "label1", "type1",
                "value1", "text1", 12L,  1L));
        datasourceOptions = addDatasourceOptionsAPI(datasource.get(0).getCode(), datasourceOptions);
        for(DatasourceOptions datasourceOptions1 : datasourceOptions) {
            assertNotNull(datasourceOptions1);
            assertEquals("col1", datasourceOptions1.getControlColumn());
            assertEquals("label1", datasourceOptions1.getControlLabel());
            assertEquals("type1", datasourceOptions1.getControlTypeId());
            assertEquals("value1", datasourceOptions1.getControlValue());
            assertEquals("text1", datasourceOptions1.getControlText());
            assertEquals(12L, datasourceOptions1.getControlDatasourceId());
            assertEquals(1L, datasourceOptions1.getRecordStatusId());
        }
    }

    @Test
    public void testGetDatasourceOptionsById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceOptions> datasourceOptions = new ArrayList<DatasourceOptions>();
        datasourceOptions.add(getDatasourceOptions(datasource.get(0).getId(), "col2", "label2", "type2",
                "value2", "text2", 12L,  1L));
        datasourceOptions = addDatasourceOptionsAPI(datasource.get(0).getCode(), datasourceOptions);
        long id = datasourceOptions.get(0).getId();
        DatasourceOptions datasourceOptions1 = getDatasourceOptionsById(datasource.get(0).getCode(), id);
        assertEquals("col2", datasourceOptions1.getControlColumn());
        assertEquals("label2", datasourceOptions1.getControlLabel());
        assertEquals("type2", datasourceOptions1.getControlTypeId());
        assertEquals("value2", datasourceOptions1.getControlValue());
        assertEquals("text2", datasourceOptions1.getControlText());
        assertEquals(12L, datasourceOptions1.getControlDatasourceId());
        assertEquals(1L, datasourceOptions1.getRecordStatusId());
    }

    @Test
    public void testGetAllDatasourceOptions() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceOptions> datasourceOptions = new ArrayList<DatasourceOptions>();
        datasourceOptions.add(getDatasourceOptions(datasource.get(0).getId(), "col3", "label3", "type3",
                "value3", "text3", 12L,  1L));
        datasourceOptions = addDatasourceOptionsAPI(datasource.get(0).getCode(), datasourceOptions);
        assertEquals("col3", datasourceOptions.get(0).getControlColumn());
        assertEquals("label3", datasourceOptions.get(0).getControlLabel());
        assertEquals("type3", datasourceOptions.get(0).getControlTypeId());
        assertEquals("value3", datasourceOptions.get(0).getControlValue());
        assertEquals("text3", datasourceOptions.get(0).getControlText());
        assertEquals(12L, datasourceOptions.get(0).getControlDatasourceId());
        assertEquals(1L, datasourceOptions.get(0).getRecordStatusId());

        datasourceOptions.add(getDatasourceOptions(datasource.get(0).getId(), "col4", "label4", "type4",
                "value4", "text4", 12L,  1L));
        addDatasourceOptionsAPI(datasource.get(0).getCode(), datasourceOptions);
        DatasourceOptions[] result = getAllDatasourceOptions(datasource.get(0).getCode());
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testUpdateDatasourceOptions() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceOptions> datasourceOptions = new ArrayList<DatasourceOptions>();
        datasourceOptions.add(getDatasourceOptions(datasource.get(0).getId(), "col5", "label5", "type5",
                "value5", "text5", 12L,  1L));
        datasourceOptions = addDatasourceOptionsAPI(datasource.get(0).getCode(), datasourceOptions);
        datasourceOptions.get(0).setControlColumn("col6");
        datasourceOptions.get(0).setControlLabel("label6");
        DatasourceOptions datasourceOptions1 = updateDatasourceOptionsAPI(datasource.get(0).getCode(), datasourceOptions.get(0));
        assertNotNull(datasourceOptions1);
        assertEquals("col6", datasourceOptions1.getControlColumn());
        assertEquals("label6", datasourceOptions1.getControlLabel());
        assertEquals("type5", datasourceOptions1.getControlTypeId());
        assertEquals("value5", datasourceOptions1.getControlValue());
        assertEquals("text5", datasourceOptions1.getControlText());
        assertEquals(12L, datasourceOptions1.getControlDatasourceId());
        assertEquals(1L, datasourceOptions1.getRecordStatusId());
    }

    @Test
    public void testDeleteDatasourceOptionsById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceOptions> datasourceOptions = new ArrayList<DatasourceOptions>();
        datasourceOptions.add(getDatasourceOptions(datasource.get(0).getId(), "col7", "label7", "type7",
                "value7", "text7", 12L,  1L));
        datasourceOptions = addDatasourceOptionsAPI(datasource.get(0).getCode(), datasourceOptions);
        long id= datasourceOptions.get(0).getId();
        try {
            assertEquals("Datasource Options '"+ id + "' deleted",delete(datasource.get(0).getCode(), id));
        } catch(final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private String delete(String datasourceCode, long id) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/datasourceoptions/" + datasourceCode)
                        .param("id", String.valueOf(id))
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk()).andReturn();
        return mvcResult.getResponse().getContentAsString();
    }
}
