package com.ascent_project.RBAC.repository;


import com.ascent_project.RBAC.model.AssetInvolvementRole;
import com.ascent_project.RBAC.model.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRoleRepository extends JpaRepository<UserRole, Long>{


    @Query("SELECT u from UserRole u WHERE role_id=:role_id and user_id=:user_id")
    UserRole findByRoleIdAndUserId(Long role_id, Long user_id);

    @Query("SELECT u from UserRole u WHERE role_id=:role_id")
    List<UserRole> findByRoleId(Long role_id);

    @Query("SELECT u from UserRole u WHERE user_id=:user_id")
    List<UserRole> findByUserId(Long user_id);

    @Query("SELECT u from UserRole u WHERE managed_entity_id=:managedEntity_id and role_id=:role_id")
    List<UserRole> findByManagedEntityIdAndRoleId(Long managedEntity_id, Long role_id);

    @Query("SELECT u from UserRole u WHERE managed_entity_id=:managedEntity_id and role_id=:role_id and user_id=:user_id")
    UserRole findByManagedEntityIdRoleIdAndUserId(Long managedEntity_id, Long role_id, Long user_id);
}
