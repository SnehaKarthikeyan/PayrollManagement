package com.report.ReportGroup.Repository;

import com.report.ReportGroup.Domain.ReportGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportGroupRepository extends JpaRepository<ReportGroup, Integer> {
    ReportGroup findByCode(String reportGroupCode);
}
