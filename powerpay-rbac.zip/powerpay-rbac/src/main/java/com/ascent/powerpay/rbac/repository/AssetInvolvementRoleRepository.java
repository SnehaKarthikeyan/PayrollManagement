package com.ascent.powerpay.rbac.repository;


import com.ascent.powerpay.rbac.domain.AssetInvolvementRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AssetInvolvementRoleRepository extends JpaRepository<AssetInvolvementRole, String>
{

    @Query("SELECT u from AssetInvolvementRole u WHERE managed_entity_id=:managedEntity_id")
    List<AssetInvolvementRole> findByManagedEntityId(Long managedEntity_id);

    AssetInvolvementRole findByCode(String assetInvolvementRole_code);
}
