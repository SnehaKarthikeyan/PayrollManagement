package com.ascent.powerpay.rbac.util;

import com.jayway.jsonpath.*;

public class JsonPathHelper {

    private static final ParseContext parseContext = JsonPath.using(getConfiguration(true));

    public static Object fetchValueFromJsonPath(String jsonDataString, String attributePath, boolean asList) {
        return getAttributeValue(jsonDataString, attributePath, asList);
    }

    public static ParseContext jsonPath() {
        return parseContext;
    }

    public static DocumentContext contextFor(String jsonDataString) {
        return parseContext.parse(jsonDataString);
    }

    public static DocumentContext contextFor(String jsonDataString, boolean asList) {
        return JsonPath.using(getConfiguration(asList)).parse(jsonDataString);
    }

    public static Object fetchValueFromJsonPath(DocumentContext context, String attributePath) {
        return context.read(attributePath);
    }

    public static String fetchValueFromJsonPathAsString(DocumentContext context, String attributePath) {
        Object value = context.read(attributePath);
        return (value == null ? null : value.toString());
    }

    public static String fetchValueFromJsonPathAsString(String jsonDataString, String attributePath, boolean asList) {
        Object value = getAttributeValue(jsonDataString, attributePath, asList);
        return (value == null ? null : value.toString());
    }

    private static Object getAttributeValue(String jsonDataString, String attributePath, boolean asList) {
        return JsonPath.using(getConfiguration(asList)).parse(jsonDataString).read(attributePath);
    }

    private static Configuration getConfiguration(boolean asList) {
        Configuration conf = Configuration.defaultConfiguration();
        conf = conf.addOptions(Option.DEFAULT_PATH_LEAF_TO_NULL, Option.SUPPRESS_EXCEPTIONS);
        if (asList) {
            return conf.addOptions(Option.ALWAYS_RETURN_LIST);
        }
        return conf;
    }
}
