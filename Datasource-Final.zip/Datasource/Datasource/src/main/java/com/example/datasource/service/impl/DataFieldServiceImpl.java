package com.example.datasource.service.impl;

import com.example.datasource.domain.DataField;
import com.example.datasource.domain.Datasource;
import com.example.datasource.exception.NotFoundException;
import com.example.datasource.repository.DataFieldRepository;
import com.example.datasource.repository.DatasourceRepository;
import com.example.datasource.service.DataFieldService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DataFieldServiceImpl implements DataFieldService {
    @Autowired
    private DataFieldRepository dataFieldRepository;

    @Autowired
    private DatasourceRepository datasourceRepository;

    @Override
    public DataField saveDataField(String datasourceCode, DataField dataField) {
        boolean exists = false;
        if(dataField.getId() != 0) {
            exists = dataFieldRepository.existsById(dataField.getId());
        }
        if(exists) {
            return null;
        }
        long datasourceId;
        DataField dataField1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            dataField.setActive(true);
            dataField.setDatasourceId(datasourceId);
            dataField1 = dataFieldRepository.save(dataField);
        }
        return dataField1;
    }

    @Override
    public DataField getDataFieldById(String datasourceCode, long dataFieldId) {
        long datasourceId;
        DataField dataField = null;
        DataField dataField1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            dataField = dataFieldRepository.findByDatasourceIdAndId(datasourceId, dataFieldId);
            if(dataField.isActive()) { dataField1=dataField; }
        } else {
            log.info("DataField object not found for {} & {}", datasourceCode, dataFieldId);
        }
        return dataField1;
    }

    @Override
    public List<DataField> getAllDataField(String datasourceCode) {
        long datasourceId;
        List<DataField> list = new ArrayList<DataField>();
        List<DataField> result = new ArrayList<DataField>();
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            list = dataFieldRepository.findByDatasourceId(datasourceId);
            for(DataField dataField: list) {
                if(dataField.isActive()) { result.add(dataField); }
            }
        } else {
            log.info("DataField object not found for {}", datasourceCode);
        }
        return result;
    }

    @Override
    public List<Object> getJoinFields(String datasourceCode) {
        List<Object> result = new ArrayList<Object>();
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            result.add(datasource);
            long datasourceId = datasource.getId();
            List<DataField> dataFields = dataFieldRepository.getByDatasourceId(datasourceId).stream()
                    .filter(dataField -> dataField.isJoinField() && dataField.isActive())
                    .collect(Collectors.toList());
            if (!dataFields.isEmpty()) {
                result.add(dataFields);
            }
        }
        return result;
    }

    @Override
    public List<Object> getFilterFields(String datasourceCode) {
        List<Object> result = new ArrayList<Object>();
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            result.add(datasource);
            long datasourceId = datasource.getId();
            List<DataField> dataFields = dataFieldRepository.getByDatasourceId(datasourceId).stream()
                    .filter(dataField -> dataField.isFilterField() && dataField.isActive())
                    .collect(Collectors.toList());
            if (!dataFields.isEmpty()) {
                result.add(dataFields);
            }
        }
        return result;
    }

    @Override
    public DataField updateDataField(String datasourceCode, long dataFieldId, DataField dataField) {
        DataField dataField1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            dataField1 = getDataFieldById(datasourceCode, dataFieldId);
            dataField1.setActive(true);
            BeanUtils.copyProperties(dataField, dataField1);
            dataField1 = dataFieldRepository.save(dataField1);
        } else {
            log.info("DataField object not found for {}", datasourceCode);
        }
        return dataField1;
    }

    @Override
    public void deleteDataFieldById(String datasourceCode, long dataFieldId) {
        DataField dataField = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            dataField = getDataFieldById(datasourceCode, dataFieldId);
            dataField.setActive(false);
            dataFieldRepository.save(dataField);
        } else {
            log.info("DataField object not found for {}", datasourceCode);
        }
    }
}
