package com.Ascentproject.report.repository;


import com.Ascentproject.report.domain.Datasource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DatasourceRepository extends JpaRepository<Datasource, Integer> {
    int findById(int dataSourceId);
    Datasource findByCode(String datasourceCode);
}
