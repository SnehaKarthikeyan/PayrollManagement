package com.ascent_project.RBAC.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Role")
public class Role {

    @Id
    private long id;
    private String name;
    private String role_code;

    @ManyToOne
    @JoinColumn(name = "managedEntity_id")
    @OnDelete( action = OnDeleteAction.CASCADE)
    private ManagedEntity managedEntity;

}
