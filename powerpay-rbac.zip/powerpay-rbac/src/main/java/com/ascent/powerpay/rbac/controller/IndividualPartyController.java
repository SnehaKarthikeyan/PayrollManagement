package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.IndividualPartyService;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/user", "/manage/user"})
public class IndividualPartyController {

    @Autowired
    private IndividualPartyService individualPartyService;

    @PostMapping
    public ResponseEntity<IndividualParty> saveIndividualParty(@RequestBody IndividualParty individualParty) throws NotFoundException {
        ResponseEntity<IndividualParty> responseEntity = null;
        IndividualParty individualParty1 = null;
        try {
            individualParty1 = individualPartyService.saveIndividualParty(individualParty);
            if(individualParty1 == null) {
                responseEntity= new ResponseEntity<>(individualParty, HttpStatus.BAD_REQUEST);
            } else {
                responseEntity = new ResponseEntity<>(individualParty1, HttpStatus.CREATED);
            }
        } catch(Exception exception) {
            log.debug("Unable to save Individual Party");
            responseEntity = new ResponseEntity<>(individualParty1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{userId}")
    public ResponseEntity<?> getIndividualPartyById(@PathVariable("userId") String userId) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            IndividualParty individualParty= individualPartyService.getIndividualPartyById(userId);
            responseEntity = new ResponseEntity<IndividualParty>(individualParty,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to find Individual Party");
            responseEntity = new ResponseEntity<String>("Unable to find Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping
    public ResponseEntity<?> getAllIndividualParty(@RequestParam(required = false) String code) throws NotFoundException {
        ResponseEntity<?> responseEntity=null;
        if(code == null || code.length() == 0)
            responseEntity = getAllIndividualPartys();
        else
            responseEntity = getIndividualPartyByCode(code);

        return responseEntity;
    }

    @NotNull
    private ResponseEntity<?> getAllIndividualPartys() {
        ResponseEntity<?> responseEntity;
        try {
            List<IndividualParty> list= individualPartyService.getAllIndividualParty();
            responseEntity= new ResponseEntity<List<IndividualParty>>(list,HttpStatus.OK);
        } catch(Exception exception) {
            log.debug("Unable to get All Individual Party");
            responseEntity = new ResponseEntity<String>("Unable to get All Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @NotNull
    public ResponseEntity<?> getIndividualPartyByCode(@RequestParam("userCode")
                                                              String userCode) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            IndividualParty individualParty= individualPartyService.getIndividualPartyByCode(userCode);
            List<IndividualParty> individualPartys= new ArrayList<>();
            if(individualParty != null)
                individualPartys.add(individualParty);
            responseEntity = new ResponseEntity<>(individualPartys,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to find Individual Party");
            responseEntity = new ResponseEntity<String>("Unable to find Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }


    @PutMapping("/{userCode}")
    public ResponseEntity<?> updateIndividualParty(@PathVariable("userCode") String userCode,
                                                   @RequestBody IndividualParty individualParty) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            IndividualParty individual = individualPartyService.updateIndividualParty(userCode, individualParty);
            responseEntity = new ResponseEntity<IndividualParty>(individual, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to find Individual Party");
            responseEntity = new ResponseEntity<String>("Unable to find Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/internal/{userId}")
    public ResponseEntity<String> deleteIndividualPartyById(@PathVariable("userId") String userId) throws NotFoundException {
        ResponseEntity<String> responseEntity= null;
        try {
            individualPartyService.deleteIndividualPartyById(userId);
            responseEntity= new ResponseEntity<String> ("Individual Party '"+userId+"' deleted",HttpStatus.OK);
        } catch(Exception exception) {
            log.debug("Unable to delete Individual Party");
            responseEntity= new ResponseEntity<String>("Unable to delete Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping
    public ResponseEntity<String> deleteIndividualPartyByCode(@RequestParam("userCode")
                                                                      String userCode) throws NotFoundException {
        ResponseEntity<String> responseEntity = null;
        try {
            individualPartyService.deleteIndividualPartyByCode(userCode);
            responseEntity = new ResponseEntity<String>("Individual Party '" + userCode + "' deleted", HttpStatus.OK);
        }catch (Exception exception) {
            log.debug("Unable to delete Individual Party");
            responseEntity = new ResponseEntity<String>("Unable to delete Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

}
