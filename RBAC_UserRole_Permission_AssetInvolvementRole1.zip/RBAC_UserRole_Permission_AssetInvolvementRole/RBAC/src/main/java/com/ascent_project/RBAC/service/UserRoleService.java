package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.BulkHelper.BulkHelperUserRole;
import com.ascent_project.RBAC.model.IndividualParty;
import com.ascent_project.RBAC.model.ManagedEntity;
import com.ascent_project.RBAC.model.Role;
import com.ascent_project.RBAC.model.UserRole;
import com.ascent_project.RBAC.repository.IndividualPartyRepository;
import com.ascent_project.RBAC.repository.ManagedEntityRepository;
import com.ascent_project.RBAC.repository.RoleRepository;
import com.ascent_project.RBAC.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;


@Service
public class UserRoleService {

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private IndividualPartyRepository individualPartyRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public UserRole getOneUserRole(Long managedEntity_id, Long role_id, Long user_id) {
        UserRole userRole;
        userRole = userRoleRepository.findByManagedEntityIdRoleIdAndUserId(managedEntity_id, role_id, user_id);
        return userRole;
    }

    public Long saveIndividualUserRole(Long managedEntity_id, Long role_id, Long user_id, UserRole userRole) {
        ManagedEntity managedEntity=managedEntityRepository.findById(managedEntity_id).get();
        Role role=roleRepository.findById(role_id).get();
        IndividualParty individualParty=individualPartyRepository.findById(user_id).get();
        userRole.setManagedEntity(managedEntity);
        userRole.setRole(role);
        userRole.setIndividual_Party(individualParty);
        userRoleRepository.save(userRole);
        return userRole.getId();
    }

    public List<UserRole> getAllUserRoles(Long managedEntity_id, Long role_id) {
        List<UserRole> userRoles = userRoleRepository.findByManagedEntityIdAndRoleId(managedEntity_id,role_id);
        return userRoles;
    }


    public void saveBulkUpload(MultipartFile file) {
        try {
            List<UserRole> userRoles = BulkHelperUserRole.csvToJson(file.getInputStream(),managedEntityRepository,roleRepository,individualPartyRepository);

          /* for(UserRole user : userRoles)
            {
                System.out.println(user);
                userRoleRepository.save(user);
                userRoleRepository.flush();
            }*/
            userRoleRepository.saveAll(userRoles);
        }
        catch (IOException e) {
            throw new RuntimeException("fail to store csv user roles data " + e.getMessage());
        }
    }

    public void deleteOneUserRole(Long managedEntity_id, Long role_id, Long user_id) {
        UserRole userRole = getOneUserRole(managedEntity_id, role_id, user_id);
        userRoleRepository.delete(userRole);
    }
}
