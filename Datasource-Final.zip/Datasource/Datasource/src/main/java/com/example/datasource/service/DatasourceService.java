package com.example.datasource.service;

import com.example.datasource.domain.Datasource;
import com.example.datasource.exception.NotFoundException;

import java.util.List;

public interface DatasourceService {
    Datasource saveDatasource(Datasource datasource);

    Datasource getDatasourceById(long datasourceId) throws NotFoundException;

    Datasource getDatasourceByCode(String datasourceCode);

    List<Datasource> getAllDatasource();

    Datasource updateDatasource(String datasourceCode, Datasource datasource);

    void deleteDatasourceById(long datasourceId);

    void deleteDatasourceByCode(String datasourceCode);
}
