package com.ascent.powerpay.rbac.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.MapType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class ObjectMapperUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final MapType type = TypeFactory.defaultInstance().constructMapType(Map.class, String.class, Object.class);
    private static final CollectionType listType = TypeFactory.defaultInstance().constructCollectionType(List.class, Object.class);

    public static List<Object> convertToList(Object data) {
        return objectMapper.convertValue(data, listType);
    }

    public static Map convertToMap(Object data) {
        return objectMapper.convertValue(data, type);
    }

    public static List<Object> readValueAsList(String data) {
        try {
            return objectMapper.readValue(data, List.class);
        } catch (IOException e) {
            log.error("Failed to read values as list: " + data, e);
        }
        return null;
    }

    public static Map convertToMap(String data) {
        try {
            return objectMapper.readValue(data, HashMap.class);
        } catch (IOException e) {
            log.error("Failed to read values as Map: " + data, e);
        }
        return null;
    }
}
