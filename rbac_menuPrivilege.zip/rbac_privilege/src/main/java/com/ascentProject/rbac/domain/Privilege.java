package com.ascentProject.rbac.domain;


import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="Dtype",discriminatorType=DiscriminatorType.STRING)
@DiscriminatorValue(value="PRI")
@Entity
@Table(name = "privilege1")
public class Privilege {


    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    @Column(name = "ID")
    private String id;
    @Column(name = "MANAGEDENTITY_ID")
    private String managedEntityId;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "NAME")
    private String name;
    @Column(name = "ACTIVE")
    private Boolean active;
    @Column(name = "PARENT_ID")
    private String parentId;
    @Column(name = "CODE")
    private String code;

}

