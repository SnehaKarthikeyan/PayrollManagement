package com.ascent.powerpay.rbac;

import com.ascent.powerpay.kernel.tenant.TenantInfo;
import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Role;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.springframework.http.MediaType;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.stereotype.Component;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import javax.validation.constraints.NotNull;

import java.io.IOException;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Component
public class TestUtil {

    @NotNull
    public ManagedEntity getManagedEntity(String code, String entityType, String entityName)
    {
        ManagedEntity managedEntity = new ManagedEntity();
        managedEntity.setCode(code);
        managedEntity.setType(entityType);
        managedEntity.setName(entityName);
        return managedEntity;
    }

    @NotNull
    public ManagedEntity addManagedEntityAPI(MockMvc mockMvc, ManagedEntity me) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = mockMvc.perform(RestDocumentationRequestBuilders
                .post("/manage/managedentity")
                .header(TenantInfo.TENANT_ID_KEY, AbstractRbacTestcase.TEST_TENANT)
                .contentType(MediaType.APPLICATION_JSON)
                .content(meStr)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        ManagedEntity managedEntityResult = getManagedEntity(mvcResult);
        return managedEntityResult;

    }

    public ManagedEntity getManagedEntity(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), ManagedEntity.class);
    }

    @NotNull
    public IndividualParty getIndividualParty(String code, String name)
    {
        IndividualParty individualParty = new IndividualParty();
        individualParty.setCode(code);
        individualParty.setName(name);
        return individualParty;
    }

    @NotNull
    public IndividualParty addIndividualPartyAPI(MockMvc mockMvc,IndividualParty me) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(me);
        System.out.println(meStr);

        MvcResult mvcResult = mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/user")
                        .header(TenantInfo.TENANT_ID_KEY, AbstractRbacTestcase.TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        IndividualParty individualPartyResult = getIndividualParty(mvcResult);
        return individualPartyResult;
    }

    public IndividualParty getIndividualParty(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), IndividualParty.class);
    }

    @NotNull
    public Role getRole(String code, String name) {
        Role role = new Role();
        role.setCode(code);
        role.setName(name);
        return role;
    }

    public Role addRoleAPI(MockMvc mockMvc,Role role) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(role);

        MvcResult mvcResult = mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/role/managedentity/entityCode1")
                        .header(TenantInfo.TENANT_ID_KEY, AbstractRbacTestcase.TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        Role roleResult = getRole(mvcResult);
        return roleResult;
    }

    public Role getRole(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Role.class);
    }

}
