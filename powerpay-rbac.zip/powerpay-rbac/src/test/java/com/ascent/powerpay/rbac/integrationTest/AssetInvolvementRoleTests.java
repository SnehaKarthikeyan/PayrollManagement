package com.ascent.powerpay.rbac.integrationTest;

import com.ascent.powerpay.rbac.domain.AssetInvolvementRole;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import javax.validation.constraints.NotNull;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class AssetInvolvementRoleTests
{

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port = 4000;

    private String getRootUrl()
    {
        return "http://localhost:" + port;
    }

    @AfterEach
    public void removeRecords() {
        AssetInvolvementRole[] assetInvolvementRoles = getAssetInvolvementRoles
                (getStringHttpAssetInvolvementRole());
        for (AssetInvolvementRole assetInvolvementRole : assetInvolvementRoles) {
            delete(assetInvolvementRole.getId());
        }
    }

    @NotNull
    private AssetInvolvementRole getAssetInvolvementRole(String code)
    {
        AssetInvolvementRole assetInvolvementRole = new AssetInvolvementRole();
        assetInvolvementRole.setCode(code);
        return assetInvolvementRole;
    }

    private AssetInvolvementRole addAssetInvolvementRoleAPI(AssetInvolvementRole assetInvolvementRole)
    {
        HttpEntity<AssetInvolvementRole> entity = getAssetInvolvementRoleHttpEntity(assetInvolvementRole);
        ResponseEntity<AssetInvolvementRole> result = this.restTemplate.postForEntity(getRootUrl() +
                        "/manage/assetInvolvementRole/managedEntityCode/entityCode1/privilegeCode/code1/" +
                        "permissionCode/code1/userRoleCode/code1",
                entity, AssetInvolvementRole.class);
        Assert.assertEquals(201,result.getStatusCodeValue());
        AssetInvolvementRole assetInvolvementRole1 = result.getBody();
        return assetInvolvementRole1;
    }

    private AssetInvolvementRole[] getAssetInvolvementRoles(HttpEntity<String> entity)
    {
        ResponseEntity<AssetInvolvementRole[]> response = restTemplate.exchange(getRootUrl() +
                        "/manage/assetInvolvementRole",
                HttpMethod.GET, entity, AssetInvolvementRole[].class);
        return response.getBody();
    }

    @NotNull
    private HttpEntity<String> getStringHttpAssetInvolvementRole()
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add("powerpayTenantId", "role_test");
        return new HttpEntity<String>(null, headers);
    }

    @NotNull
    private HttpEntity<AssetInvolvementRole> getAssetInvolvementRoleHttpEntity(
            AssetInvolvementRole assetInvolvementRole)
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add("powerpayTenantId", "role_test");
        return new HttpEntity<>(assetInvolvementRole, headers);
    }

    @Test
    public void testSaveAssetInvolvementRole() throws RestClientException
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRole("code1");
        addAssetInvolvementRoleAPI(assetInvolvementRole);
    }

    @Test
    public void testGetAssetInvolvementRoleById()
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRole("code2");
        assetInvolvementRole = addAssetInvolvementRoleAPI(assetInvolvementRole);
        String id = assetInvolvementRole.getId();
        assetInvolvementRole = restTemplate.getForObject(getRootUrl() +
                "/manage/assetInvolvementRole/assetInvolvementRoleId/" + id, AssetInvolvementRole.class);
        assertEquals("code2", assetInvolvementRole.getCode());
        Assert.assertNotNull(assetInvolvementRole);
    }

    @Test
    public void testGetAssetInvolvementRoleByCode()
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRole("code3");
        assetInvolvementRole = addAssetInvolvementRoleAPI(assetInvolvementRole);
        String code = assetInvolvementRole.getCode();
        assetInvolvementRole = restTemplate.getForObject(getRootUrl() +
                "/manage/assetInvolvementRole/assetInvolvementRoleCode/" + code, AssetInvolvementRole.class);
        assertEquals("code3", assetInvolvementRole.getCode());
        Assert.assertNotNull(assetInvolvementRole);
    }

    @Test
    public void testGetAllAssetInvolvementRole()
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRole("code4");
        assetInvolvementRole = addAssetInvolvementRoleAPI(assetInvolvementRole);

        assertEquals("code4", assetInvolvementRole.getCode());

        assetInvolvementRole = getAssetInvolvementRole("code5");
        assetInvolvementRole = addAssetInvolvementRoleAPI(assetInvolvementRole);

        HttpEntity<String> entity = getStringHttpAssetInvolvementRole();
        AssetInvolvementRole[] result = getAssetInvolvementRoles(entity);
        Assert.assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testErrorOnDuplicateAssetInvolvementRole()
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRole("code6");
        assetInvolvementRole = addAssetInvolvementRoleAPI(assetInvolvementRole);

        assertEquals("code6", assetInvolvementRole.getCode());

        AssetInvolvementRole assetInvolvementRole1 = getAssetInvolvementRole("code6");

        HttpEntity<AssetInvolvementRole> entity = getAssetInvolvementRoleHttpEntity(assetInvolvementRole1);
        ResponseEntity<AssetInvolvementRole> result = this.restTemplate.postForEntity
                (getRootUrl() + "/manage/assetInvolvementRole/managedEntityCode/entityCode1/privilegeCode/code1/" +
                        "permissionCode/code1/userRoleCode/code1", entity, AssetInvolvementRole.class);
        Assert.assertEquals(400,result.getStatusCodeValue());
    }

    @Test
    public void testUpdateAssetInvolvementRole() throws RestClientException
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRole("code6");
        assetInvolvementRole = addAssetInvolvementRoleAPI(assetInvolvementRole);
        String code = assetInvolvementRole.getCode();
        assetInvolvementRole.setCode("code7");
        String code1 = assetInvolvementRole.getCode();
        HttpEntity<AssetInvolvementRole> entity = getAssetInvolvementRoleHttpEntity(assetInvolvementRole);
        ResponseEntity<AssetInvolvementRole> response = restTemplate.exchange(getRootUrl() +
                        "/manage/assetInvolvementRole/managedEntityCode/entityCode1/privilegeCode/code1" +
                        "/permissionCode/code1/userRoleCode/code1/assetInvolvementRoleCode/" + code,
                HttpMethod.PUT, entity, AssetInvolvementRole.class);
        AssetInvolvementRole assetInvolvementRole1 = restTemplate.getForObject(getRootUrl() +
                "/manage/assetInvolvementRole/assetInvolvementRoleCode/" + code1, AssetInvolvementRole.class);
        assertNotNull(assetInvolvementRole1);
        assertEquals("code7", assetInvolvementRole1.getCode());
    }

    @Test
    public void testDeleteAssetInvolvementRoleByCode()
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRole("code9");
        assetInvolvementRole = addAssetInvolvementRoleAPI(assetInvolvementRole);
        String code = assetInvolvementRole.getCode();
        markForDelete(code);
        try
        {
            AssetInvolvementRole assetInvolvementRole1 = restTemplate.getForObject(getRootUrl() +
                            "/manage/assetInvolvementRole/assetInvolvementRoleCode/" + code,
                    AssetInvolvementRole.class);
            assertFalse(assetInvolvementRole1.isActive());
        }
        catch(final HttpClientErrorException e)
        {
            fail("object status should have been saved.");
        }
    }

    private void markForDelete(String code)
    {
        restTemplate.delete(getRootUrl() +
                "/manage/assetInvolvementRole/assetInvolvementRoleCode/" + code);
    }

    private void delete(String id)
    {
        restTemplate.delete(getRootUrl() +
                "/manage/assetInvolvementRole/assetInvolvementRoleId/" + id);
    }

}
