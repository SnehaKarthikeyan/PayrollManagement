package com.ascent.powerpay.rbac.service;

import com.ascent.powerpay.rbac.domain.Employee;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface EmployeeService {

    void save(String employeeId, Map<String, Object> properties, String effectiveDate);

    void cleanUp();

    void save(Employee employee);

    Employee employeeFor(String employeeId);

    default boolean hasEmployee(String employeeId) {
        return employeeFor(employeeId) != null;
    }

    List<String> getChanges(Date rangeStart, Date rangeStop);
}
