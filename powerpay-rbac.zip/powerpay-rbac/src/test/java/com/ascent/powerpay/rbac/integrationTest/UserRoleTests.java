package com.ascent.powerpay.rbac.integrationTest;

import com.ascent.powerpay.kernel.tenant.TenantInfo;
import com.ascent.powerpay.rbac.AbstractRestDocumentationTestCase;
import com.ascent.powerpay.rbac.TestUtil;
import com.ascent.powerpay.rbac.controller.UserRoleController;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Role;
import com.ascent.powerpay.rbac.domain.UserRole;
import com.ascent.powerpay.rbac.service.UserRoleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.Assert;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.context.WebApplicationContext;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.io.InputStream;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
class UserRoleTests extends AbstractRestDocumentationTestCase {

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    @Autowired
    private WebApplicationContext webApplicationContext;

    private InputStream is;
    private MockMvc mockMvc;
    @Mock
    private UserRoleService userRoleService;

    @Spy
    @InjectMocks
    private UserRoleController userRoleController = new UserRoleController();


    @Autowired
    TestUtil testUtil;

    @BeforeAll
    public void init()
    {
        mockMvc = MockMvcBuilders.standaloneSetup(userRoleController).build();
        is = userRoleController.getClass().getClassLoader().getResourceAsStream("sample.csv");
    }

    private String getRootUrl()
    {
        return "http://localhost:" + port;
    }

    @BeforeEach
    public void createManagedEntity() throws Exception
    {
        ManagedEntity managedEntity = testUtil.getManagedEntity("entityCode1",
                "entityType1", "entityName1");
        managedEntity = testUtil.addManagedEntityAPI(this.mockMvc, managedEntity);
        assertNotNull(managedEntity);
        assertEquals("entityCode1", managedEntity.getCode());
        assertEquals("entityType1", managedEntity.getType());
        assertEquals("entityName1", managedEntity.getName());
    }

    @BeforeEach
    public void createRole() throws Exception
    {
        Role role = testUtil.getRole("roleCode1", "roleName1");
        role = testUtil.addRoleAPI(this.mockMvc,role);
        assertNotNull(role);
        assertEquals("roleCode1", role.getCode());
        assertEquals("roleName1", role.getName());
    }

    @NotNull
    private UserRole getUserRole(String code, String validUntil)
    {
        UserRole userRole = new UserRole();
        userRole.setCode(code);
        userRole.setValidUntil(validUntil);
        return userRole;
    }

    private UserRole addUserRoleAPI(UserRole me) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/userrole/managedentity/entityCode1/role/roleCode1/user/userCode1")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        UserRole userRoleResult = getUserRole(mvcResult);
        return userRoleResult;
    }

    private UserRole getUserRole(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), UserRole.class);
    }

    private UserRole[] getUserRoles(HttpEntity<String> entity)
    {
        ResponseEntity<UserRole[]> response = restTemplate.exchange(getRootUrl() +
                "/manage/userRole", HttpMethod.GET, entity, UserRole[].class);
        return response.getBody();
    }

    @NotNull
    private HttpEntity<String> getStringHttpUserRole()
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add("powerpayTenantId", "userRole_test");
        return new HttpEntity<String>(null, headers);
    }

    @NotNull
    private HttpEntity<UserRole> getUserRoleHttpEntity(UserRole userRole)
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add("powerpayTenantId", "userRole_test");
        return new HttpEntity<>(userRole, headers);
    }

    @Test
    public void testSaveUserRole() throws Exception
    {
        UserRole userRole = getUserRole("code1","24-05-2021");
        userRole = addUserRoleAPI(userRole);
        assertNotNull(userRole);
        assertEquals("code1", userRole.getCode());
        assertEquals("24-05-2021", userRole.getValidUntil());
    }

    @Test
    public void testBulkUpload_TxtFile() throws Exception
    {
        MockMultipartFile file
                = new MockMultipartFile(
                "file", "Sample.txt", MediaType.TEXT_PLAIN_VALUE, "Testing".getBytes());
        MockMvc mockMvc
                = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockMvc.perform(multipart("/manage/userRole/user/role").file(file))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testUploadFile() throws Exception
    {
        MockMultipartFile mockMultipartFile = new MockMultipartFile("file", "sample.csv",
                "multipart/form-data", is);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.multipart(getRootUrl() + "/manage/userRole/role/user").
                file(mockMultipartFile).contentType(MediaType.MULTIPART_FORM_DATA)).andExpect(MockMvcResultMatchers.status().is(200)).andReturn();
        Assert.assertEquals(200, ((MvcResult) result).getResponse().getStatus());
        Assert.assertNotNull(result.getResponse().getContentAsString());
        Assert.assertEquals("sample.csv", result.getResponse().getContentAsString());
    }

    @Test
    public void testGetUserRoleById() throws Exception {
        UserRole userRole = getUserRole("code2","24-05-2021");
        userRole = addUserRoleAPI(userRole);
        String id = userRole.getId();
        userRole = restTemplate.getForObject(getRootUrl() +
                "/manage/userRole/userRoleId/" + id, UserRole.class);
        Assert.assertNotNull(userRole);
        Assert.assertEquals("code2", userRole.getCode());
        Assert.assertEquals("24-05-2021", userRole.getValid_Until());
    }

    @Test
    public void testGetUserRoleByCode() throws Exception {
        UserRole userRole = getUserRole("code3", "24-05-2026");
        userRole = addUserRoleAPI(userRole);
        String code = userRole.getCode();
        userRole = restTemplate.getForObject(getRootUrl() +
                "/manage/userRole/userRoleCode/" + code, UserRole.class);
        Assert.assertNotNull(userRole);
        Assert.assertEquals("code3", userRole.getCode());
        Assert.assertEquals("24-05-2026", userRole.getValid_Until());
    }

    @Test
    public void testGetAllUserRole() throws Exception {
        UserRole role = getUserRole("code4", "23-03-2021");
        role = addUserRoleAPI(role);

        Assert.assertEquals("code4", role.getCode());
        Assert.assertEquals("23-03-2021", role.getValid_Until());

        role = getUserRole("code5", "23-05-2021");
        role = addUserRoleAPI(role);

        HttpEntity<String> entity = getStringHttpUserRole();
        UserRole[] result = getUserRoles(entity);
        Assert.assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testUpdateUserRole() throws Exception
    {
        UserRole userRole = getUserRole("code6", "29-05-2026");
        userRole = addUserRoleAPI(userRole);
        userRole.setValid_Until("31-05-2025");
        String code = userRole.getCode();
        HttpEntity<UserRole> entity = getUserRoleHttpEntity(userRole);
        ResponseEntity<UserRole> response = restTemplate.exchange(getRootUrl() +
                "/manage/userRole/managedEntityCode/entityCode1/roleCode/code1/userCode/code1/" +
                "userRoleCode/" + code, HttpMethod.PUT, entity, UserRole.class);
        UserRole userRole1 = restTemplate.getForObject(getRootUrl() +
                "/manage/userRole/userRoleCode/" + code, UserRole.class);
        assertNotNull(userRole1);
        assertEquals("code6", userRole1.getCode());
        assertEquals("31-05-2025", userRole1.getValid_Until());
    }

    @Test
    public void testDeleteRoleById() throws Exception {
        UserRole userRole = getUserRole("code7", "29-05-2028");
        userRole = addUserRoleAPI(userRole);
        String id = userRole.getId();
        delete(id);
        try
        {
            UserRole userRole1 = restTemplate.getForObject(getRootUrl() +
                    "/manage/userRole/userRoleId/" + id, UserRole.class);
            assertFalse(userRole1.isActive());
        }
        catch(final HttpClientErrorException e)
        {
            fail("object status should have been saved.");
        }
    }

    @Test
    public void testDeleteRoleByCode() throws Exception {
        UserRole userRole = getUserRole("code8", "29-05-2026");
        userRole = addUserRoleAPI(userRole);
        String code = userRole.getCode();
        markForDelete(code);
        try
        {
            UserRole userRole1 = restTemplate.getForObject(getRootUrl() +
                    "/manage/userRole/userRoleCode/" + code, UserRole.class);
            assertFalse(userRole1.isActive());
        }
        catch(final HttpClientErrorException e)
        {
            fail("object status should have been saved.");
        }
    }

    private void markForDelete(String code)
    {
        restTemplate.delete(getRootUrl() + "/manage/userRole/userRoleCode/" + code);
    }

    private void delete(String id)
    {
        restTemplate.delete(getRootUrl() + "/manage/userRole/userRoleId/" + id);
    }

}
