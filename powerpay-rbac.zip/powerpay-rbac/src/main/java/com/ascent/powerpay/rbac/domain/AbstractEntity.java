package com.ascent.powerpay.rbac.domain;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@MappedSuperclass
public abstract class AbstractEntity implements Serializable {
    @CreatedDate
    @Column(name = "CREATED_ON")
    @Temporal(TemporalType.TIMESTAMP)
    @Getter(AccessLevel.PROTECTED)
    @Setter(AccessLevel.PROTECTED)
    private Date createdOn;

    @LastModifiedDate
    @Column(name = "MODIFIED_ON")
    @Temporal(TemporalType.TIMESTAMP)
    @Getter(AccessLevel.PROTECTED)
    @Setter(AccessLevel.PROTECTED)
    private Date modifiedOn;

    @Column(name = "VERSION")
    @Version
    @Getter(AccessLevel.PROTECTED)
    @Setter(AccessLevel.PROTECTED)
    private int version;

}
