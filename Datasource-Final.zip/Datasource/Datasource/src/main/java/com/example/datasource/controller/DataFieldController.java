package com.example.datasource.controller;

import com.example.datasource.domain.DataField;
import com.example.datasource.service.DataFieldService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/datafield","/manage/datafield"})
public class DataFieldController {
    @Autowired
    private DataFieldService dataFieldService;

    @PostMapping("/{datasourceCode}")
    public ResponseEntity<?> saveDataField(@PathVariable("datasourceCode") String datasourceCode, @RequestBody List<DataField> dataField) {
        ResponseEntity<?> responseEntity;
        try {
            for(DataField dataField1: dataField) {
                dataFieldService.saveDataField(datasourceCode, dataField1);
            }
            responseEntity = new ResponseEntity<List<DataField>>(dataField, HttpStatus.CREATED);
        } catch(Exception e) {
            log.debug("Unable to save Data Field");
            responseEntity = new ResponseEntity<List<DataField>>(dataField, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{datasourceCode}/search")
    public ResponseEntity<?> getDataFieldById(@PathVariable("datasourceCode") String datasourceCode, @RequestParam("id") long dataFieldId) {
        ResponseEntity<?> responseEntity= null;
        try {
            DataField dataField= dataFieldService.getDataFieldById(datasourceCode, dataFieldId);
            responseEntity = new ResponseEntity<DataField>(dataField, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Data Field");
            responseEntity = new ResponseEntity<String>("Unable to get Data Field", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{datasourceCode}")
    public ResponseEntity<?> getAllDataField(@PathVariable("datasourceCode") String datasourceCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            List<DataField> dataField= dataFieldService.getAllDataField(datasourceCode);
            responseEntity= new ResponseEntity<List<DataField>>(dataField, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Data Field");
            responseEntity = new ResponseEntity<String>("Unable to get DataField", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/joinfield/{datasourceCode}")
    public ResponseEntity<?> getJoinFields(@PathVariable("datasourceCode") String datasourceCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            List<Object> dataField = dataFieldService.getJoinFields(datasourceCode);
            responseEntity= new ResponseEntity<List<Object>>(dataField,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Data Field");
            responseEntity = new ResponseEntity<String>("Unable to get DataField", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/filterfield/{datasourceCode}")
    public ResponseEntity<?> getFilterFields(@PathVariable("datasourceCode") String datasourceCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            List<Object> dataField = dataFieldService.getFilterFields(datasourceCode);
            responseEntity= new ResponseEntity<List<Object>>(dataField,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Data Field");
            responseEntity = new ResponseEntity<String>("Unable to get DataField", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/{datasourceCode}/{dataFieldId}")
    public ResponseEntity<?> updateDataField(@PathVariable("datasourceCode") String datasourceCode, @PathVariable("dataFieldId") long dataFieldId, @RequestBody DataField dataField) {
        ResponseEntity<?> responseEntity = null;
        try {
            DataField dataField1 = dataFieldService.updateDataField(datasourceCode, dataFieldId, dataField);
            responseEntity = new ResponseEntity<DataField>(dataField1, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to update Data Field");
            responseEntity = new ResponseEntity<String>("Unable to update Data Field", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{datasourceCode}")
    public ResponseEntity<?> deleteDataFieldById(@PathVariable("datasourceCode") String datasourceCode, @RequestParam("id") long dataFieldId) {
        ResponseEntity<?> responseEntity= null;
        try {
            dataFieldService.deleteDataFieldById(datasourceCode, dataFieldId);
            responseEntity = new ResponseEntity<String> ("Data Field '" + dataFieldId + "' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Data Field");
            responseEntity = new ResponseEntity<String>("Unable to delete Data Field", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
