package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.Category;
import com.Ascentproject.report.repository.CategoryRepository;
import com.Ascentproject.report.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    CategoryRepository categoryRepository;
    public List<Category> saveCategory(List<Category> categoryList)
    {
            return categoryRepository.saveAll(categoryList);
    }
    public List<Category> getCategory()
    {
        List<Category> categoryList= categoryRepository.findAll().stream()
                .collect(Collectors.toList());
        return categoryList;
    }
}
