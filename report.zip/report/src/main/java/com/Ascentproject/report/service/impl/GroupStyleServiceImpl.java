package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.GroupStyle;
import com.Ascentproject.report.repository.GroupStyleRepository;
import com.Ascentproject.report.service.GroupStyleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GroupStyleServiceImpl implements GroupStyleService {

    @Autowired
    public GroupStyleRepository groupStyleRepository;

    public List<GroupStyle> saveGroupStyle(List<GroupStyle> groupStyleList)
    {
        return groupStyleRepository.saveAll(groupStyleList);
    }
    public List<GroupStyle> getGroupStyle()
    {
        List<GroupStyle> groupStyleList= groupStyleRepository.findAll().stream().collect(Collectors.toList());
        return groupStyleList;
    }
}
