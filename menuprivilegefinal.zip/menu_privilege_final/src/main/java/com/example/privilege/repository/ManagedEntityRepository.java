package com.example.privilege.repository;
import com.example.privilege.model.MenuPrivilege;
import com.example.privilege.model.MenuPrivilege;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ManagedEntityRepository extends JpaRepository<MenuPrivilege,String> {

    @Query("Select  id from ManagedEntity p where code=:code")
    String findByCode (String code);

}


