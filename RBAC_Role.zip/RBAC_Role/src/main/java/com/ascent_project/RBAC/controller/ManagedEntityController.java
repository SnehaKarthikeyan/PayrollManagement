package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.model.ManagedEntity;
import com.ascent_project.RBAC.repository.ManagedEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/managedEntity/api/v1")
public class ManagedEntityController {

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    @PostMapping("/post")
    public ManagedEntity createStudent(@RequestBody ManagedEntity managedEntity)
    {
        return managedEntityRepository.save(managedEntity);
    }

    @GetMapping("/get")
    public Page<ManagedEntity> getAllStudents(Pageable pageable)
    {
        return managedEntityRepository.findAll(pageable);
    }
}
