package com.example.datasource.service;

import com.example.datasource.domain.DataField;
import com.example.datasource.exception.NotFoundException;

import java.util.List;

public interface DataFieldService {
    DataField saveDataField(String datasourceCode, DataField dataField);

    DataField getDataFieldById(String datasourceCode, long dataFieldId) throws NotFoundException;

    List<DataField> getAllDataField(String datasourceCode);

    DataField updateDataField(String datasourceCode, long dataFieldId, DataField dataField);

    void deleteDataFieldById(String datasourceCode, long dataFieldId);

    List<Object> getJoinFields(String datasourceCode);

    List<Object> getFilterFields(String datasourceCode);
}
