package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.rbac.BulkHelper.BulkHelperPermission;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Permission;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.repository.ManagedEntityRepository;
import com.ascent.powerpay.rbac.repository.PermissionRepository;
import com.ascent.powerpay.rbac.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class PermissionServiceImpl implements PermissionService
{

    @Autowired
    ManagedEntityRepository managedEntityRepository;

    @Autowired
    PermissionRepository permissionRepository;

    @Override
    public Permission savePermission(String managedEntity_Code, Permission permission)
    {
        boolean exists = false;
        if(permission.getId() != null)
        {
            exists = permissionRepository.existsById(permission.getId());
        }
        if(exists)
        {
            return null;
        }
        ManagedEntity managedEntity = managedEntityRepository.findByCode(managedEntity_Code);
        permission.setManagedEntity(managedEntity);
        permission.setActive(true);
        Permission permission1 = permissionRepository.save(permission);
        return permission1;
    }

    @Override
    public void saveBulkUpload(MultipartFile file)
    {
        try
        {
            List<Permission> permissions = BulkHelperPermission.csvToJson(file.getInputStream(),managedEntityRepository);
            permissionRepository.saveAll(permissions);
        }
        catch (IOException e) {
            throw new RuntimeException("fail to store csv user roles data " + e.getMessage());
        }
    }

    @Override
    public Permission getPermissionById(String permission_Id) throws NotFoundException
    {
       Permission permission = permissionRepository.findById(permission_Id)
                .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Permission '")
                                .append(permission_Id)
                                .append("' not exist")
                                .toString())
                );
        return permission;
    }

    @Override
    public Permission getPermissionByCode(String permission_Code) throws NotFoundException
    {
        Permission permission;
        permission = permissionRepository.findByCode(permission_Code);
        return permission;
    }

    @Override
    public List<Permission> getAllPermission()
    {
        List<Permission> permissions;
        permissions = permissionRepository.findAll();
        return permissions;
    }

    public Permission updatePermission(String managedEntity_Code, String permission_Code,
                                       Permission permission)
    {
        Permission permission1 = permissionRepository.findByCode(permission_Code);
        ManagedEntity managedEntity = managedEntityRepository.findByCode(managedEntity_Code);
        permission1.setManagedEntity(managedEntity);
        if(permission.getCode()!=null)
        {
            permission1.setCode(permission.getCode());
        }
        if(permission.getName()!=null)
        {
            permission1.setName(permission.getName());
        }
        if(permission.getDescription()!=null)
        {
            permission1.setDescription(permission.getDescription());
        }
        if(permission.getValid_Until()!=null)
        {
            permission1.setValid_Until(permission.getValid_Until());
        }
        permission1.setActive(true);
        permissionRepository.save(permission1);
        return permission1;
    }

    @Override
    public void deletePermissionById(String permission_Id) throws NotFoundException
    {
        Permission permission = getPermissionById(permission_Id);
        permissionRepository.delete(permission);
    }

    @Override
    public void deletePermissionByCode(String permission_Code) throws NotFoundException
    {
        Permission permission = getPermissionByCode(permission_Code);
        permission.setActive(false);
        permissionRepository.save(permission);
    }

}
