package com.ascent_project.RBAC.repository;


import com.ascent_project.RBAC.model.AssetInvolvementRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AssetInvolvementRoleRepository extends JpaRepository<AssetInvolvementRole, Long>{

    @Query("SELECT u from AssetInvolvementRole u WHERE managed_entity_id=:managedEntity_id")
    List<AssetInvolvementRole> findByManagedEntityId(Long managedEntity_id);
}
