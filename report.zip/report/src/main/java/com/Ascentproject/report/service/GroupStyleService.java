package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.GroupStyle;

import java.util.List;

public interface GroupStyleService {
    List<GroupStyle> saveGroupStyle(List<GroupStyle> groupStyleList);

    List<GroupStyle> getGroupStyle();
}
