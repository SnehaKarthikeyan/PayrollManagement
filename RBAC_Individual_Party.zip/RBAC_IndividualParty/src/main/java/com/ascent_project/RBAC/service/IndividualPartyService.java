package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.exception.NotFoundException;
import com.ascent_project.RBAC.model.IndividualParty;

import java.util.List;

public interface IndividualPartyService {

    String saveIndividualParty(IndividualParty individualParty);

    void deleteIndividualPartyById(String individualParty_Code) throws NotFoundException;

    void deleteIndividualPartyByCode(String individualParty_Code) throws NotFoundException;

    IndividualParty getIndividualPartyById(String individualParty_Id) throws NotFoundException;

    List<IndividualParty> getAllIndividualParty();

    IndividualParty getIndividualPartyByCode(String individualParty_Code) throws NotFoundException;

    IndividualParty updateIndividualPartyByCode(IndividualParty individualParty);
}
