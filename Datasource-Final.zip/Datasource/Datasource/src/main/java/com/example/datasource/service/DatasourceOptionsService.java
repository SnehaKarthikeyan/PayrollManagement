package com.example.datasource.service;

import com.example.datasource.domain.DatasourceOptions;
import com.example.datasource.exception.NotFoundException;

import java.util.List;

public interface DatasourceOptionsService {
    DatasourceOptions saveDatasourceOptions(String datasourceCode, DatasourceOptions datasourceOptions);

    DatasourceOptions getDatasourceOptionsById(String datasourceCode, long datasourceOptionsId) throws NotFoundException;

    List<Object> getAllDatasourceOptions(String datasourceCode);

    DatasourceOptions updateDatasourceOptions(String datasourceCode, long datasourceOptionsId, DatasourceOptions datasourceOptions);

    void deleteDatasourceOptionsById(String datasourceCode, long datasourceOptionsId);
}
