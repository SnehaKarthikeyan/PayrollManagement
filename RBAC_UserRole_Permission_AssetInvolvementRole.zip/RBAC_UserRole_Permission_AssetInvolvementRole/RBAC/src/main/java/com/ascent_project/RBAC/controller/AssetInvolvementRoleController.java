package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.model.AssetInvolvementRole;
import com.ascent_project.RBAC.service.AssetInvolvementRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/managedEntity")

public class AssetInvolvementRoleController {
    @Autowired
    private AssetInvolvementRoleService assetInvolvementRoleService;

    @PostMapping("/{managedEntity_id}/privilege/{privilege_id}/permission/{permission_id}/userRole/{userRole_id}")
    public ResponseEntity<String> saveAssetInvolvementRole( @PathVariable (name="managedEntity_id") Long managedEntity_id ,
                                                            @PathVariable (name="privilege_id") Long privilege_id,
                                                            @PathVariable (name="permission_id") Long permission_id,
                                                            @PathVariable (name="userRole_id") Long userRole_id,
                                                            @RequestBody AssetInvolvementRole assetInvolvementRole ){
        ResponseEntity<String> responseEntity = null;
        try{
            Long id = assetInvolvementRoleService.saveAssetInvolvementRole(managedEntity_id, privilege_id, permission_id, userRole_id, assetInvolvementRole);
            responseEntity= new ResponseEntity<String>(
                    "AssetInvolvementRole '"+id+"' created",HttpStatus.CREATED); //201-created}

        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to save AssetInvolvementRole",
                    HttpStatus.INTERNAL_SERVER_ERROR); //500-Internal Server Error
        }
        return responseEntity;
    }

    @GetMapping("/{managedEntity_id}")
    public ResponseEntity<?> getAllAssetInvolvementRole(@PathVariable("managedEntity_id") Long managedEntity_id) {
        ResponseEntity<?> responseEntity=null;
        try {
            List<AssetInvolvementRole> assetInvolvementRoleList= assetInvolvementRoleService.
                    getAllAssetInvolvementRoles(managedEntity_id);
            responseEntity= new ResponseEntity<List<AssetInvolvementRole>>(assetInvolvementRoleList,HttpStatus.OK);
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get AssetInvolvementRoles",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }

    @GetMapping("/assetInvolvementRole/{assetInvolvementRole_id}")
    public ResponseEntity<?> getOneAssetInvolvementRole(@PathVariable("assetInvolvementRole_id")
                                                                    Long assetInvolvementRole_id){
        ResponseEntity<?> responseEntity=null;
        try {
            AssetInvolvementRole assetInvolvementRole= assetInvolvementRoleService.getOneAssetInvolvementRole(assetInvolvementRole_id);
            responseEntity= new ResponseEntity<AssetInvolvementRole>
                    (assetInvolvementRole,HttpStatus.OK);
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get AssetInvolvementRole",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
}
