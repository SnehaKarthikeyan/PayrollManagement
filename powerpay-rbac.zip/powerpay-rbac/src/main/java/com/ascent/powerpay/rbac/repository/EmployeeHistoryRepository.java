package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.domain.EmployeeHistory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface EmployeeHistoryRepository extends CrudRepository<EmployeeHistory, String> {
    List<EmployeeHistory> findByEmployeeId(String code);
}
