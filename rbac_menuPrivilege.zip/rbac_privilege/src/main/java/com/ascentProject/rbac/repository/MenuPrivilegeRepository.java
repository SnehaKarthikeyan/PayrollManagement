package com.ascentProject.rbac.repository;


import com.ascentProject.rbac.domain.MenuPrivilege;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository

public interface MenuPrivilegeRepository extends JpaRepository<MenuPrivilege, String> {

    @Query("Select  p from MenuPrivilege p where code=:code")
    MenuPrivilege findByCode (String code);
    @Query("Select p from MenuPrivilege p where id=:privilege_id")
    MenuPrivilege findByPrivilegeId (String privilege_id);
    @Query("Select p from MenuPrivilege p where parentId=:parent_id")
    MenuPrivilege findByPrivilegeParentById(String parent_id);
}
