package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.model.Role;
import com.ascent_project.RBAC.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/role")
public class RoleController {
    @Autowired
    private RoleService roleService;
    @GetMapping("/{id}")
    public ResponseEntity<?> getOneRole(@PathVariable Long id){
        ResponseEntity<?> responseEntity= null;
        try {
            Role role= roleService.getOneRole(id);
            responseEntity= new ResponseEntity<Role>(role,HttpStatus.OK);
        }

        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to find Role",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
    @PostMapping
    public ResponseEntity<String> saveRole(@RequestBody Role role){
        ResponseEntity<String> responseEntity = null;
        try{
            Long id = roleService.saveRole(role);
            responseEntity= new ResponseEntity<String>(
                    "Role'"+id+"' created",HttpStatus.CREATED); //201-created
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Role",
                    HttpStatus.INTERNAL_SERVER_ERROR); //500-Internal Server Error
        }
        return responseEntity;
    }


}
