package com.ascent_project.RBAC.exception;

public class IndividualPartyNotFoundException  extends RuntimeException
    {

        private static final long serialVersionUID = 1L;

        public IndividualPartyNotFoundException() {
            super();
        }

        public IndividualPartyNotFoundException(String message) {
            super(message);
        }
}
