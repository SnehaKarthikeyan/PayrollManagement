package com.Ascentproject.report.controller;

import com.Ascentproject.report.domain.Category;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.CategoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/category", "/manage/category"})

public class CategoryController {
    @Autowired
    private  CategoryService categoryService;

    @CrossOrigin
    @PostMapping
    public ResponseEntity<?> saveCategory(@RequestBody List<Category> categoryList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<Category> categoryList1= categoryService.saveCategory(categoryList);
            if(categoryList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save Category ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<Category>>(
                    categoryList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Category ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @GetMapping
    public ResponseEntity<?> getAllCategory() throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<Category> categoryList = categoryService.getCategory();
            resp= new ResponseEntity<List<Category>>(
                    categoryList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Category doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}

