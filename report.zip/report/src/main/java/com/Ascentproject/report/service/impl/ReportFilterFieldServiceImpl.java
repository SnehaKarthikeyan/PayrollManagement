package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.ReportFilterField;
import com.Ascentproject.report.repository.ReportFilterFieldRepository;
import com.Ascentproject.report.repository.ReportRepository;
import com.Ascentproject.report.service.ReportFilterFieldService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

public class ReportFilterFieldServiceImpl implements ReportFilterFieldService {


    @Autowired
    private ReportFilterFieldRepository reportFilterFieldRepository;


    @Autowired
    private ReportRepository reportRepository;



    public List<ReportFilterField> saveReportFilterField (int reportId, List<ReportFilterField> reportFilterFieldList) {

        reportFilterFieldList.stream().forEach(reportFilterField -> reportFilterField.setReportId(reportId));
        return reportFilterFieldRepository.saveAll(reportFilterFieldList);
    }


    public  List<ReportFilterField> getReportFilterField(int reportId) {
        List<ReportFilterField> reportFilterFieldList= reportFilterFieldRepository.findById(reportId).stream()
                .collect(Collectors.toList());
        return reportFilterFieldList;
    }
    public List<ReportFilterField> updateFilterField(int reportId, List<ReportFilterField> reportFilterFieldList)
    {
        List<ReportFilterField>reportFilterFieldList1= reportFilterFieldRepository.findByReportId(reportId);
        reportFilterFieldList1.stream().forEach(reportFilterField -> reportFilterFieldRepository.delete(reportFilterField));
        return saveReportFilterField(reportId,reportFilterFieldList1);
    }
    public int findByReportId(int reportId) {

        int reportId1 =reportRepository.findById(reportId);
        return reportId1;

    }
}


