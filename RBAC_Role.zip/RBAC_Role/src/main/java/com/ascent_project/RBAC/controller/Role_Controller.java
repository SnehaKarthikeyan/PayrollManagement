package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.model.Role;
import com.ascent_project.RBAC.service.Role_Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user_roles/rest")
public class Role_Controller {

    @Autowired
    private Role_Service service;

    @PostMapping("/role")
    public ResponseEntity<?> Role(@RequestBody Role role){
        ResponseEntity<?> response = null;
        try{
            Long id = service.saveRole(role);
            if(id == null) {
                response = new ResponseEntity<String>("Role " +role.getId()+ " exists", HttpStatus.CREATED);
            }
            else{
                response = new ResponseEntity<String>("Role '" + id +"' created", HttpStatus.CREATED);
            }
            System.out.println("OK");
        } catch(Exception e){
            e.printStackTrace();
        }
        return response;
    }

    @GetMapping("/role")
    public ResponseEntity<?> Role(){
        ResponseEntity<?> response = null;
        try {
            List<Role> list = service.getAllRoles();
            response = new ResponseEntity<>(list, HttpStatus.OK);
        } catch(Exception e){
            e.printStackTrace();
            response = new ResponseEntity<String>(
                    "Unable to get Role",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @DeleteMapping("/role/{id}")
    public ResponseEntity<?> Role(@PathVariable Long id){
        ResponseEntity<?> response = null;
        try {
            service.deleteRole(id);
            response= new ResponseEntity<String> (
                    "Role '"+id+"' deleted", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            response= new ResponseEntity<String>(
                    "Unable to delete Role", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @GetMapping("/role/{id}")
    public ResponseEntity<?> getRole(@PathVariable Long id) {
        ResponseEntity<?> response = null;
        try{
            Role role = service.getOneRole(id);
            response = new ResponseEntity<>(role,HttpStatus.OK);
        } catch(Exception e){
            e.printStackTrace();
            response= new ResponseEntity<String>(
                    "Unable to get Role", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

}
