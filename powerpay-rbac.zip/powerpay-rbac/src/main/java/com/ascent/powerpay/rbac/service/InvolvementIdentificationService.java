package com.ascent.powerpay.rbac.service;


import com.ascent.powerpay.rbac.domain.InvolvementIdentification;
import com.ascent.powerpay.rbac.exception.NotFoundException;

import java.util.List;

public interface InvolvementIdentificationService
{

    InvolvementIdentification saveInvolvementIdentification(String manageEntity_Code, String user_Code,
                                                            InvolvementIdentification involvementIdentification) throws NotFoundException;

    InvolvementIdentification getInvolvementIdentificationById(String managedEntityCode,String userCode, String involvementIdentificationId)
            throws NotFoundException;

    InvolvementIdentification getInvolvementIdentificationByCode(String managedEntityCode, String userCode, String involvementIdentificationCode)
            throws NotFoundException;

    List<InvolvementIdentification> getAllInvolvementIdentification(String managedEntityCode,String userCode) throws NotFoundException;

    InvolvementIdentification updateInvolvementIdentification(String managedEntity_Code, String user_Code,
                                                              String involvementIdentification_Code,
                                                              InvolvementIdentification involvementIdentification) throws NotFoundException;

    void deleteInvolvementIdentificationById(String managedEntityCode, String userCode, String involvementIdentificationId) throws NotFoundException;

    void deleteInvolvementIdentificationByCode(String managedEntityCode, String userCode, String involvementIdentificationCode) throws NotFoundException;
}
