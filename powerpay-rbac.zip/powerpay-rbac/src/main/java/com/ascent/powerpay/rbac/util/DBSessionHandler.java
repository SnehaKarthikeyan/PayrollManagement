package com.ascent.powerpay.rbac.util;

import com.ascent.powerpay.rbac.util.Utils;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.sql.*;
import java.util.*;

@Component
@Transactional
public class DBSessionHandler {
    private EntityManager entityManager = null;


    @Autowired
    public DBSessionHandler(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public List<Map<String, Object>> getEntity(String query, LinkedList<Pair<Class, String>> params) {
        Session session = entityManager.unwrap(Session.class);
        return session.doReturningWork(connection -> runQuery(connection, query, params));
    }

    public List<Map<String, Object>> getEntity(Session session, String query, LinkedList<Pair<Class, String>> params) {
        return session.doReturningWork(connection -> runQuery(connection, query, params));
    }


    private List<Map<String, Object>> runQuery(Connection connection, String query, LinkedList<Pair<Class, String>> params) throws SQLException {
        PreparedStatement preparedStatement = Utils.prepareStatement(connection, query, params);
        ResultSet resultSet = preparedStatement.executeQuery();
        return resultSetToList(resultSet);
    }

    private void noReturnQuery(Connection connection, String query, LinkedList<Pair<Class, String>> params) throws SQLException {
        PreparedStatement preparedStatement = Utils.prepareStatement(connection, query, params);
        preparedStatement.execute();
    }

    public void deleteEntity(Session session, String query, LinkedList<Pair<Class, String>> params) {
        session.doWork(connection -> noReturnQuery(connection, query, params));
    }

    public void updateEntity(String query, LinkedList<Pair<Class, String>> params) {
        Session session = entityManager.unwrap(Session.class);
        session.doWork(connection -> noReturnQuery(connection, query, params));
    }

    public void dropTable(String tableName) {
        LinkedList<Pair<Class, String>> params = new LinkedList<>();
        String query = "DROP TABLE " + tableName;
        Session session = entityManager.unwrap(Session.class);
        session.doWork(connection -> {
            PreparedStatement preparedStatement = Utils.prepareStatement(connection, query, params);
            preparedStatement.execute();
        });
    }

    private List<Map<String, Object>> resultSetToList(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int columns = md.getColumnCount();
        List<Map<String, Object>> rows = new ArrayList<>();
        while (rs.next()) {
            Map<String, Object> row = new HashMap<>(columns);
            for (int i = 1; i <= columns; ++i) {
                row.put(md.getColumnName(i), rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

}
