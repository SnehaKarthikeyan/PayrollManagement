package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.exception.PrivilegeNotFoundException;
import com.ascent_project.RBAC.model.Privilege;
import com.ascent_project.RBAC.service.PrivilegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/managedEntity/api/v2")
public class PrivilegeController {

    @Autowired
    private PrivilegeService privilegeService;

    @PostMapping("/{managedEntity_id}/privilege")
    public ResponseEntity<String> savePrivilege(@PathVariable("managedEntity_id") Long managedEntityId,@RequestBody Privilege privilege){
        ResponseEntity<String> result = null;
        try{
            if(privilegeService.getPrivilegeById(managedEntityId, privilege.getId()) == null) {
                Long id = privilegeService.savePrivilege(managedEntityId, privilege);
                result = new ResponseEntity<String>(
                        "Privilege '" + id + "' created", HttpStatus.CREATED);
            }
            else
            {
                result = new ResponseEntity<String>(
                        "Privilege '" + privilege.getId() + "' Already Exists", HttpStatus.ALREADY_REPORTED);
            }
        } catch (Exception e) {
            e.printStackTrace();
            result = new ResponseEntity<String>(
                    "Unable to create Privilege",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return result;
    }

    @GetMapping("/{managedEntity_id}/privilege")
    public ResponseEntity<?> getAllPrivileges(@PathVariable("managedEntity_id") Long managedEntityId) {
        ResponseEntity<?> result =null;
        try {
            List<Privilege> list= privilegeService.getAllPrivilege(managedEntityId);
            result = new ResponseEntity<List<Privilege>>(list, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            result = new ResponseEntity<String>(
                    "Unable to get Privilege ",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return result;
    }

    @GetMapping("/{managedEntity_id}/privilege/{privilege_id}")
    public ResponseEntity<?> getPrivilegeById(@PathVariable("managedEntity_id") Long managedEntityId,@PathVariable("privilege_id") Long privilegeId){
        ResponseEntity<?> result= null;
        try {
            Privilege privilege= privilegeService.getPrivilegeById(managedEntityId,privilegeId);
            result= new ResponseEntity<Privilege>(privilege,HttpStatus.OK);
        }catch (PrivilegeNotFoundException exception) {
            throw exception;
        }catch (Exception e) {
            e.printStackTrace();
            result = new ResponseEntity<String>(
                    "Unable to find Privilege",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return result;
    }

    @PostMapping("/{managedEntity_id}/privilege/{privilege_id}")
    public ResponseEntity<?> updatePrivilege(@PathVariable(value = "managedEntity_id") Long managedEntityId, @PathVariable(value = "privilege_id") Long privilegeId, @RequestBody Privilege privilegeRequest)
    {
        ResponseEntity<?> result = null;
        try {
            Privilege privilege= privilegeService.updatePrivilegeById(managedEntityId,privilegeId,privilegeRequest);
            result= new ResponseEntity<Privilege>(privilege,HttpStatus.OK);
        }catch (PrivilegeNotFoundException exception) {
            throw exception;
        }catch (Exception e) {
            e.printStackTrace();
            result = new ResponseEntity<String>(
                    "Unable to find Privilege",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return result;
    }

    @DeleteMapping("/{managedEntity_id}/privilege/{privilege_id}")
    public ResponseEntity<String> deletePrivilege(@PathVariable("managedEntity_id") Long managedEntityId,@PathVariable("privilege_id") Long privilegeId){

        ResponseEntity<String> result = null;
        try {
            privilegeService.deletePrivilege(managedEntityId,privilegeId);
            result= new ResponseEntity<String> ("Privilege was deleted",HttpStatus.OK);
        } catch (PrivilegeNotFoundException exception) {
            throw exception;
        } catch (Exception e) {
            e.printStackTrace();
            result= new ResponseEntity<String>(
                    "Unable to delete Privilege", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return result;
    }

}
