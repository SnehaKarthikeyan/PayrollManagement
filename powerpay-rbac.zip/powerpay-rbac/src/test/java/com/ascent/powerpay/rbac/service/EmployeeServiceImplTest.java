package com.ascent.powerpay.rbac.service;

import com.ascent.powerpay.kernel.resource.ConfigResourceLoader;
import com.ascent.powerpay.rbac.AbstractRbacIntegrationTestcase;
import com.ascent.powerpay.rbac.domain.Employee;
import com.ascent.powerpay.rbac.repository.EmployeeCrudRepository;
import com.ascent.powerpay.rbac.service.serviceImpl.EmployeeServiceImpl;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static org.junit.Assert.assertEquals;

@Transactional
public class EmployeeServiceImplTest extends AbstractRbacIntegrationTestcase {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private ConfigResourceLoader resourceLoader;

    @Autowired
    private EmployeeServiceImpl service;

    @Autowired
    private EmployeeCrudRepository repository;

    public void addEmployee() throws IOException {
        String employeeOne = IOUtils.toString(resourceLoader.getResource("/data/employee-one.json").getInputStream(), StandardCharsets.UTF_8);
        Map<String, Object> employeeOneConfiguration = mapper.readValue(employeeOne, new TypeReference<Map<String, Object>>() {
        });
        service.save("100031", employeeOneConfiguration, "2018-04-01");
    }

    private Date getDate(int integer) {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, integer);
        return cal.getTime();
    }

    @Test
    public void checkWeatherCorrectChangesComesWithinGivenPeriod() throws IOException {

        addEmployee();
        Date startDate = (getDate(-1));
        Date endDate = (getDate(+1));
        List<String> employeeIds = service.getChanges(startDate, endDate);
        assertEquals(employeeIds.size(), 1);
        Optional<Employee> employee = repository.findById(employeeIds.get(0));
        assertEquals(employee.get().getEmployeeId(), "100031");

    }

    @Test
    public void checkWeatherNoChangesAreReturnedWhenThereAreNoChangesInGivenPeriod() throws IOException {

        addEmployee();
        Date startDate = (getDate(+2));
        Date endDate = (getDate(+3));
        List<String> employeeIds = service.getChanges(startDate, endDate);
        assertEquals(employeeIds.size(), 0);

    }


}