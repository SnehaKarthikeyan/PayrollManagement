package com.Ascentproject.report.controller;


import com.Ascentproject.report.domain.PageType;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.PageTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/pagetype", "/manage/pagetype"})

public class PageTypeController {
    @Autowired
    private PageTypeService pageTypeService;

    @CrossOrigin
    @PostMapping
    public ResponseEntity<?> savePageType(@RequestBody List<PageType> pageTypeList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<PageType> pageTypeList1= pageTypeService.savePageType(pageTypeList);
            if(pageTypeList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save PageType ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<PageType>>(
                    pageTypeList, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save PageType ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @GetMapping
    public ResponseEntity<?> getAllPageType() throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<PageType> graphTypeList = pageTypeService.getPageType();
            resp= new ResponseEntity<List<PageType>>(
                    graphTypeList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("PageType doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}