package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.PageType;

import java.util.List;

public interface PageTypeService {
    List<PageType> savePageType(List<PageType> pageTypeList);

    List<PageType> getPageType();
}
