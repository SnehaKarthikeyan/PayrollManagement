package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.domain.Role;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.RoleService;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/role", "/manage/role"})
public class RoleController {

    @Autowired
    private RoleService roleService;

    @PostMapping("/managedentity/{managedEntityCode}")
    public ResponseEntity<Role> saveRole(@PathVariable("managedEntityCode") String managedEntityCode,
                                         @RequestBody Role role) {
        ResponseEntity<Role> responseEntity = null;
        Role role1 = null;
        try {
            role1 = roleService.saveRole(managedEntityCode, role);
            if(role1 == null) {
                responseEntity = new ResponseEntity<>(role, HttpStatus.BAD_REQUEST);
            } else {
                responseEntity = new ResponseEntity<>(role1, HttpStatus.CREATED);
            }
        }catch(Exception exception) {
            log.error("Unable to save Role", exception);
            responseEntity = new ResponseEntity<Role>(role1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/role/{roleId}")
    public ResponseEntity<?> getRoleById(@PathVariable("managedEntityCode") String managedEntityCode,
                                         @PathVariable("roleId") String roleId) throws NotFoundException {
        ResponseEntity<?> responseEntity= null;
        try {
            Role role= roleService.getRoleById(managedEntityCode,roleId);
            if(role == null)
                responseEntity= new ResponseEntity(HttpStatus.BAD_REQUEST);
            else
                responseEntity= new ResponseEntity<Role>(role,HttpStatus.OK);
        }catch(Exception exception) {
            log.error("Unable to find Role", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/role")
    public ResponseEntity<?> getAllRole(@PathVariable("managedEntityCode") String managedEntityCode,
                                        @RequestParam(required = false) String roleCode) throws NotFoundException {
        ResponseEntity<?> response = null;
        if(roleCode == null || roleCode.length() == 0)
            response = getAllRoles(managedEntityCode);
        else
            response = getRoleByCode(managedEntityCode,roleCode);
        return response;
    }

    @NotNull
    private ResponseEntity<?> getAllRoles(String managedEntityCode) {
        ResponseEntity<?> response;
        try {
            List<Role> list = roleService.getAllRole(managedEntityCode);
            response = new ResponseEntity<>(list, HttpStatus.OK);
        }catch(Exception e) {
            log.error("Unable to get All Role", e);
            response = new ResponseEntity<String>("Unable to get All Role", HttpStatus.BAD_REQUEST);
        }
        return response;
    }

    @NotNull
    public ResponseEntity<?> getRoleByCode(String managedEntityCode,
                                           @RequestParam(required = false) String roleCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            Role role= roleService.getRoleByCode(managedEntityCode,roleCode);
            List<Role> roles= new ArrayList<>();
            if(role != null)
                roles.add(role);
            responseEntity= new ResponseEntity<>(roles,HttpStatus.OK);
        }catch(Exception exception) {
            log.error("Unable to find Role", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/managedentity/{managedEntityCode}/role/{roleCode}")
    public ResponseEntity<?> updatePrivilege(@PathVariable(value = "managedEntityCode") String managedEntityCode,
                                             @PathVariable(value = "roleCode") String roleCode,
                                             @RequestBody Role role) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            Role role1 = roleService.updateRole(managedEntityCode, roleCode, role);
            responseEntity= new ResponseEntity<Role>(role1,HttpStatus.OK);
        }catch (Exception e) {
            log.error("Unable to find Role", e);
            responseEntity = new ResponseEntity<String>("Unable to find Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/role/internal/{roleId}")
    public ResponseEntity<?> deleteRoleById(@PathVariable("managedEntityCode") String managedEntityCode,
                                            @PathVariable("roleId") String roleId) throws NotFoundException {
        ResponseEntity<?> response = null;
        try {
            roleService.deleteRoleById(managedEntityCode,roleId);
            response= new ResponseEntity<String> ("Role '"+roleId+"' deleted", HttpStatus.OK);
        }catch (Exception e) {
            log.error("Unable to delete Role", e);
            response= new ResponseEntity<String>("Unable to delete Role", HttpStatus.BAD_REQUEST);
        }
        return response;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/role")
    public ResponseEntity<?> deleteRoleByCode(@PathVariable("managedEntityCode") String managedEntityCode,
                                              @RequestParam("roleCode") String roleCode) throws NotFoundException {
        ResponseEntity<?> response = null;
        try {
            roleService.deleteRoleByCode(managedEntityCode,roleCode);
            response= new ResponseEntity<String> ("Role '"+roleCode+"' deleted", HttpStatus.OK);
        }catch (Exception e) {
            log.error("Unable to delete Role", e);
            response= new ResponseEntity<String>("Unable to delete Role", HttpStatus.BAD_REQUEST);
        }
        return response;
    }

}
