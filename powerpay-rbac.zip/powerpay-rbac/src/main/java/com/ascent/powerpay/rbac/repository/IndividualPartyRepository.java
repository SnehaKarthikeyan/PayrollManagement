package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.domain.IndividualParty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IndividualPartyRepository extends JpaRepository<IndividualParty, String>
{

    IndividualParty findByCode(String individualParty_Code);

    @Query("SELECT u from IndividualParty u WHERE id=:role_id")
    List<IndividualParty> findByUserId(String role_id);
}
