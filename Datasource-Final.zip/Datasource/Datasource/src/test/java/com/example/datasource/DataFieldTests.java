package com.example.datasource;

import com.example.datasource.domain.DataField;
import com.example.datasource.domain.Datasource;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@Transactional
class DataFieldTests extends DatasourceTests{
    @Autowired
    private MockMvc mockMvc;

    @NotNull
    private DataField getDataField(String name, long dataTypeId, long filterDatasourceId, long recordStatusId, boolean joinField,
                                   boolean groupField, boolean sortField, boolean dynamicField, boolean formulaField, boolean filterField) throws Exception {
        DataField dataField = new DataField();
        dataField.setName(name);
        dataField.setDataTypeId(dataTypeId);
        dataField.setFilterDatasourceId(filterDatasourceId);
        dataField.setRecordStatusId(recordStatusId);
        if(joinField) { dataField.setJoinField(true); }
        if(groupField) { dataField.setGroupField(true); }
        if(sortField) { dataField.setSortField(true); }
        if(dynamicField) { dataField.setDynamicField(true); }
        if(formulaField) { dataField.setFormulaField(true); }
        if(filterField) { dataField.setFilterField(true); }
        return dataField;
    }

    private DataField getDataField(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), DataField.class);
    }

    private List<DataField> addDataFieldAPI(String datasourceCode, List<DataField> dataField) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(dataField);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/datafield/" + datasourceCode)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        List<DataField> dataFields = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<DataField>>(){});
        return dataFields;
    }

    private DataField getDataFieldById(String datasourceCode, long id) throws Exception {
        DataField dataField;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datafield/" + datasourceCode + "/search")
                        .param("id", String.valueOf(id))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        dataField = getDataField(mvcResult);
        return dataField;
    }

    private DataField[] getAllDataField(String datasourceCode) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datafield/" + datasourceCode)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        DataField[] dataFieldResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), DataField[].class);
        return dataFieldResult;
    }

    private Object[] getJoinFields(String datasourceCode) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datafield/joinfield/" + datasourceCode)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        Object[] result = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
        return result;
    }

    private Object[] getFilterFields(String datasourceCode) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datafield/filterfield/" + datasourceCode)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        Object[] result = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
        return result;
    }

    private DataField updateDataFieldAPI(String datasourceCode, DataField dataField) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(dataField);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/datafield/" + datasourceCode + "/" + dataField.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        DataField dataFieldResult = getDataField(mvcResult);
        return dataFieldResult;
    }

    @Test
    public void testSaveDataField() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DataField> dataField = new ArrayList<DataField>();
        dataField.add(getDataField("name1", 123L, 1L, 2L, false, true, false, true, true, false));
        dataField = (List<DataField>) addDataFieldAPI(datasource.get(0).getCode(), dataField);
        for(DataField dataField1 : dataField) {
            assertNotNull(dataField1);
            assertEquals("name1", dataField1.getName());
            assertEquals(123L, dataField1.getDataTypeId());
            assertEquals(1L, dataField1.getFilterDatasourceId());
            assertEquals(2L, dataField1.getRecordStatusId());
            assertEquals(false, dataField1.isJoinField());
            assertEquals(true, dataField1.isGroupField());
            assertEquals(false, dataField1.isSortField());
            assertEquals(true, dataField1.isDynamicField());
            assertEquals(true, dataField1.isFormulaField());
            assertEquals(false, dataField1.isFilterField());
        }
    }

   @Test
    public void testGetDataFieldById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DataField> dataField = new ArrayList<DataField>();
        dataField.add(getDataField("name2", 123L, 1L,2L, false, true, false, true, true, false));
        dataField = (List<DataField>) addDataFieldAPI(datasource.get(0).getCode(), dataField);
        long id = dataField.get(0).getId();
        DataField dataField1 = getDataFieldById(datasource.get(0).getCode(), id);
        assertEquals("name2", dataField1.getName());
        assertEquals(123L, dataField1.getDataTypeId());
        assertEquals(1L, dataField1.getFilterDatasourceId());
        assertEquals(2L, dataField1.getRecordStatusId());
        assertEquals(false, dataField1.isJoinField());
        assertEquals(true, dataField1.isGroupField());
        assertEquals(false, dataField1.isSortField());
        assertEquals(true, dataField1.isDynamicField());
        assertEquals(true, dataField1.isFormulaField());
        assertEquals(false, dataField1.isFilterField());
    }

    @Test
    public void testGetAllDataField() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DataField> dataField = new ArrayList<DataField>();
        dataField.add(getDataField("name3", 123L, 1L,2L, false, true, false, true, true, false));
        dataField = (List<DataField>) addDataFieldAPI(datasource.get(0).getCode(), dataField);
        for(DataField dataField1 : dataField) {
            assertEquals("name3", dataField1.getName());
            assertEquals(123L, dataField1.getDataTypeId());
            assertEquals(1L, dataField1.getFilterDatasourceId());
            assertEquals(2L, dataField1.getRecordStatusId());
            assertEquals(false, dataField1.isJoinField());
            assertEquals(true, dataField1.isGroupField());
            assertEquals(false, dataField1.isSortField());
            assertEquals(true, dataField1.isDynamicField());
            assertEquals(true, dataField1.isFormulaField());
            assertEquals(false, dataField1.isFilterField());
        }
        dataField.add(getDataField("name4", 123L, 1L,2L,false, true, false, true, true, false));
        addDataFieldAPI(datasource.get(0).getCode(), dataField);
        DataField[] result = getAllDataField(datasource.get(0).getCode());
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testGetJoinFields() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DataField> dataField = new ArrayList<DataField>();
        dataField.add(getDataField("name5", 123L, 1L,2L, false, true, false, true, true, false));
        dataField = (List<DataField>) addDataFieldAPI(datasource.get(0).getCode(), dataField);

        dataField.add(getDataField("name6", 123L, 1L,2L, true, true, false, true, true, false));
        addDataFieldAPI(datasource.get(0).getCode(), dataField);
        Object[] result = getJoinFields(datasource.get(0).getCode());
        assertNotNull(result);
        assertTrue(result.length == 2);
    }

    @Test
    public void testGetFilterFields() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DataField> dataField = new ArrayList<DataField>();
        dataField.add(getDataField("name7", 123L, 1L,2L, false, true, false, true, true, false));
        dataField = (List<DataField>) addDataFieldAPI(datasource.get(0).getCode(), dataField);

        dataField.add(getDataField("name8", 123L, 1L,2L, false, true, false, true, true, true));
        addDataFieldAPI(datasource.get(0).getCode(), dataField);
        Object[] result = getFilterFields(datasource.get(0).getCode());
        assertNotNull(result);
        assertTrue(result.length == 2);
    }

    @Test
    public void testUpdateDataField() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DataField> dataField = new ArrayList<DataField>();
        dataField.add(getDataField("name9", 123L, 1L,2L, false, true, false, true, true, false));
        dataField = (List<DataField>) addDataFieldAPI(datasource.get(0).getCode(), dataField);
        dataField.get(0).setName("name10");
        DataField dataField1 = updateDataFieldAPI(datasource.get(0).getCode(), dataField.get(0));
        assertNotNull(dataField1);
        assertEquals("name10", dataField1.getName());
        assertEquals(123L, dataField1.getDataTypeId());
        assertEquals(1L, dataField1.getFilterDatasourceId());
        assertEquals(2L, dataField1.getRecordStatusId());
        assertEquals(false, dataField1.isJoinField());
        assertEquals(true, dataField1.isGroupField());
        assertEquals(false, dataField1.isSortField());
        assertEquals(true, dataField1.isDynamicField());
        assertEquals(true, dataField1.isFormulaField());
        assertEquals(false, dataField1.isFilterField());
    }

    @Test
    public void testDeleteDataFieldById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DataField> dataField = new ArrayList<DataField>();
        dataField.add(getDataField("name11", 123L, 1L,2L, false, true, false, true, true, false));
        dataField = (List<DataField>) addDataFieldAPI(datasource.get(0).getCode(), dataField);
        long id = dataField.get(0).getId();
        try {
            assertEquals("Data Field '"+ id + "' deleted", delete(datasource.get(0).getCode(), id));
        } catch(final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private String delete(String datasourceCode, long id) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/datafield/" + datasourceCode)
                        .param("id", String.valueOf(id))
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk()).andReturn();
        return mvcResult.getResponse().getContentAsString();
    }
}
