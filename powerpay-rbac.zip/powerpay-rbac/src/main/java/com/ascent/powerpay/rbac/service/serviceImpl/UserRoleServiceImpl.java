package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.rbac.BulkHelper.BulkHelperUserRole;
import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Role;
import com.ascent.powerpay.rbac.domain.UserRole;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.repository.IndividualPartyRepository;
import com.ascent.powerpay.rbac.repository.ManagedEntityRepository;
import com.ascent.powerpay.rbac.repository.RoleRepository;
import com.ascent.powerpay.rbac.repository.UserRoleRepository;
import com.ascent.powerpay.rbac.service.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
@Slf4j
public class UserRoleServiceImpl implements UserRoleService
{

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private IndividualPartyRepository individualPartyRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public UserRole saveUserRole(String managedEntityCode, String roleCode, String userCode,
                                 UserRole userRole) throws NotFoundException {
        boolean exists = false;
        if(userRole.getId() != null) {
            exists = userRoleRepository.existsById(userRole.getId());
        }if(exists) {
            return null;
        }
        ManagedEntity managedEntity = getManagedEntity(managedEntityCode);
        Role role = getRole(roleCode);
        IndividualParty individualParty=getIndividualParty(userCode);
        userRole.setManagedEntityId(managedEntity.getId());
        userRole.setRoleId(role.getId());
        userRole.setIndividualPartyId(individualParty.getId());
        userRole.setActive(true);
        userRoleRepository.save(userRole);
        return userRole;
    }

    private ManagedEntity getManagedEntity(String managedEntityCode) throws NotFoundException {
        ManagedEntity me = managedEntityRepository.findByCode(managedEntityCode);
        if(me == null) throw new NotFoundException(managedEntityCode + " Managed Entity Not Found");
        return me;
    }

    private Role getRole(String roleCode) throws NotFoundException {
        Role me = roleRepository.findByCode(roleCode);
        if(me == null) throw new NotFoundException(roleCode + " Role Not Found");
        return me;
    }

    private IndividualParty getIndividualParty(String userCode) throws NotFoundException {
        IndividualParty me = individualPartyRepository.findByCode(userCode);
        if(me == null) throw new NotFoundException(userCode + " Role Not Found");
        return me;
    }

    public void saveBulkUpload(MultipartFile file)
    {
        try
        {
            List<UserRole> userRoles = BulkHelperUserRole.csvToJson(file.getInputStream(),
                    managedEntityRepository,roleRepository,individualPartyRepository);
            userRoleRepository.saveAll(userRoles);
        }
        catch (IOException e)
        {
            throw new RuntimeException("fail to store csv user roles data " + e.getMessage());
        }
    }

    public UserRole getUserRoleById(String managedEntityCode, String roleCode, String userCode, String userRoleId) throws NotFoundException {
        String managedEntityId = null;
        String userId = null;
        String roleId = null;
        UserRole userRole = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        IndividualParty ip=getIndividualParty(userCode);
        Role role = getRole(roleCode);
        if(me != null && role != null && ip != null) {
            managedEntityId = me.getId();
            userId = ip.getId();
            roleId = role.getId();
        userRole = userRoleRepository.findByManagedEntityIdAndIndividualPartyIdAndRoleIdAndId(managedEntityId, userId, roleId, userRoleId);
        } else {
            log.info("User Role object not found for {},{},{} & {}", managedEntityCode, roleCode, userCode, userRoleId);
        }
        return userRole;
    }

    public UserRole getUserRoleByCode(String managedEntityCode, String roleCode, String userCode, String userRoleCode) throws NotFoundException {

        String managedEntityId = null;
        String userId = null;
        String roleId = null;
        UserRole userRole = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        IndividualParty ip=getIndividualParty(userCode);
        Role role = getRole(roleCode);
        if(me != null && role != null && ip != null) {
            managedEntityId = me.getId();
            userId = ip.getId();
            roleId = role.getId();
        userRole = userRoleRepository.findByManagedEntityIdAndIndividualPartyIdAndRoleIdAndCode(managedEntityId,userId,roleId,userRoleCode);
        } else {
            log.info("role object not found for {},{},{} & {}", managedEntityCode,roleCode,userCode,userRoleCode);
        }
        return userRole;
    }

    public List<UserRole> getAllUserRole(String managedEntityCode, String roleCode, String userCode) throws NotFoundException {
        String managedEntityId = null;
        String userId = null;
        String roleId = null;
        List<UserRole> list = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        IndividualParty ip = getIndividualParty(userCode);
        Role role = getRole(roleCode);
        if(me != null && role != null && ip != null) {
            managedEntityId = me.getId();
            userId = ip.getId();
            roleId = role.getId();
            list = userRoleRepository.findAllByManagedEntityIdAndIndividualPartyIdAndRoleId(managedEntityId,userId,roleId);
        } else {
            log.info("Managed Entity,Role and User object not found for {},{} & {}", managedEntityCode,roleCode,userCode);
        }
        return list;
    }

    public UserRole updateUserRole(String managedEntityCode, String roleCode,
                                   String userCode, String userRoleCode, UserRole userRole) throws NotFoundException {
        ManagedEntity managedEntity = getManagedEntity(managedEntityCode);
        Role role = getRole(roleCode);
        IndividualParty individualParty = getIndividualParty(userCode);
        UserRole userRole1 = userRoleRepository.findByManagedEntityIdAndIndividualPartyIdAndRoleIdAndCode
                (managedEntity.getId(),role.getId(),individualParty.getId(),userRoleCode);
        userRole1.setCode(userRole.getCode());
        userRole1.setValidUntil(userRole.getValidUntil());
        userRole1.setActive(true);
        return userRoleRepository.save(userRole1);
    }

    public void deleteUserRoleById(String managedEntityCode, String roleCode, String userCode, String userRoleId) throws NotFoundException
    {
        UserRole userRole = getUserRoleById(managedEntityCode, roleCode, userCode, userRoleId);
        userRoleRepository.delete(userRole);
    }

    public void deleteUserRoleByCode(String managedEntityCode, String roleCode, String userCode, String userRoleCode) throws NotFoundException
    {
        UserRole userRole = getUserRoleByCode(managedEntityCode, roleCode, userCode, userRoleCode);
        userRole.setActive(false);
        userRoleRepository.save(userRole);
    }

}
