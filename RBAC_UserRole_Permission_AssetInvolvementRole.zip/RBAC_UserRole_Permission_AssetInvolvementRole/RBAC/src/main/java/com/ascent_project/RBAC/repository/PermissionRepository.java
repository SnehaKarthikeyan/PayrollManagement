package com.ascent_project.RBAC.repository;

import com.ascent_project.RBAC.model.Permission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PermissionRepository extends JpaRepository<Permission, Long> {

    @Query("SELECT u from Permission u WHERE managed_entity_id=:managedEntity_id")
    List<Permission> findByManagedEntityId(Long managedEntity_id);

    @Query("SELECT u from Permission u WHERE managed_entity_id=:managedEntity_id AND id=:permission_id")
    Permission findByManagedEntityAndPermissionId(Long managedEntity_id, Long permission_id);

    @Query("SELECT u from Permission u WHERE id=:permission_id")
    List<Permission> findByPermissionId(Long permission_id);
}
