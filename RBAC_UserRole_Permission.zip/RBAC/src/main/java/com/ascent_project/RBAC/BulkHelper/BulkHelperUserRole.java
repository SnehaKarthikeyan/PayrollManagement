package com.ascent_project.RBAC.BulkHelper;

import com.ascent_project.RBAC.model.IndividualParty;
import com.ascent_project.RBAC.model.ManagedEntity;
import com.ascent_project.RBAC.model.Role;
import com.ascent_project.RBAC.model.UserRole;
import com.ascent_project.RBAC.repository.IndividualPartyRepository;
import com.ascent_project.RBAC.repository.ManagedEntityRepository;
import com.ascent_project.RBAC.repository.RoleRepository;
import com.ascent_project.RBAC.service.UserRoleService;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
@Component
public class BulkHelperUserRole {
    public static String TYPE = "text/csv";
    static String[] HEADER = { "id", "role_id", "user_id", "valid_for" , "managedEntity_id"};
    @Autowired
    UserRoleService userRoleService;
    //@Autowired
      //      static
     //UserRoleRepository userRoleRepository;
  // UserRoleRepository userRoleRepository;
  //  public BulkHelper(UserRoleService  service)
   // {
    //    this.userRoleService=service;
    //}
    public static boolean hasCSVFormat(MultipartFile file) {

        if (!TYPE.equals(file.getContentType())) {
            return false;
        }

        return true;
    }

    public static List<UserRole> csvToJson(InputStream is, ManagedEntityRepository managedEntityRepository, RoleRepository roleRepository, IndividualPartyRepository individualPartyRepository) {
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            try (CSVParser csvParser = new CSVParser(fileReader,
                    CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim())) {

                List<UserRole> userRoles = new ArrayList<UserRole>();

                Iterable<CSVRecord> csvRecords = csvParser.getRecords();

                for (CSVRecord csvRecord : csvRecords) {
                    Long id=Long.parseLong(csvRecord.get("Id"));
                    ManagedEntity managedEntity=managedEntityRepository.findByManagedEntityId(Long.parseLong(csvRecord.get("managed_entity_id"))).get(0);
                    Role role=roleRepository.findByRoleId(Long.parseLong(csvRecord.get("role_id"))).get(0);
                    IndividualParty individualParty=individualPartyRepository.findByUserId(Long.parseLong(csvRecord.get("user_id"))).get(0);
                    String valid_for= csvRecord.get("valid_for");

                    UserRole userRole = new UserRole(
                            id,managedEntity,role,individualParty,valid_for);
                    userRoles.add(userRole);
                }

                return userRoles;
            }
        } catch (IOException e) {
            throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
        }
    }

}

