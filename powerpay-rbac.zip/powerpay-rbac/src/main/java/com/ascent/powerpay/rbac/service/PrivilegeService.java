package com.ascent.powerpay.rbac.service;


import com.ascent.powerpay.rbac.domain.Privilege;
import com.ascent.powerpay.rbac.exception.NotFoundException;

import java.util.List;

public interface PrivilegeService
{

    Privilege savePrivilege(String managedEntity_Id, Privilege privilege) throws NotFoundException;

    Privilege getPrivilegeById(String managedEntityCode, String privilegeId) throws NotFoundException;

    Privilege getPrivilegeByCode(String managedEntityCode, String privilegeCode) throws NotFoundException;

    List<Privilege> getAllPrivilege(String managedEntityCode) throws NotFoundException;

    Privilege updatePrivilege(String managedEntity_Code, String privilege_Code, Privilege privilegeRequest) throws NotFoundException;

    void deletePrivilegeById(String managedEntityCode, String privilegeId) throws NotFoundException;

    void deletePrivilegeByCode(String managedEntityCode, String privilegeCode) throws NotFoundException;

}
