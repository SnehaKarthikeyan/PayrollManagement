package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.exception.RoleNotFoundException;
import com.ascent_project.RBAC.model.Role;
import com.ascent_project.RBAC.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    public long saveRole(Role role)
    {

        Long id = roleRepository.save(role).getId();
        return id;
    }
    public Role getOneRole(Long id) {
        Role role = roleRepository.findById(id)
                .orElseThrow(()->new RoleNotFoundException(
                        new StringBuffer().append("Role  '")
                                .append(id)
                                .append("' not exist")
                                .toString())
                );
        return role;
    }

}
