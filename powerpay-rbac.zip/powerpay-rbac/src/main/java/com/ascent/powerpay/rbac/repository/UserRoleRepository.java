package com.ascent.powerpay.rbac.repository;


import com.ascent.powerpay.rbac.domain.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRoleRepository extends JpaRepository<UserRole, String> {

    UserRole findByCode(String userRole_Code);
    UserRole findByManagedEntityIdAndIndividualPartyIdAndRoleIdAndId(String managedEntityId, String userId, String roleId, String userRoleId);
    List<UserRole> findAllByManagedEntityIdAndIndividualPartyIdAndRoleId(String managedEntityId, String userId, String roleId);
    UserRole findByManagedEntityIdAndIndividualPartyIdAndRoleIdAndCode(String managedEntityId, String userId, String roleId, String userRoleCode);
}
