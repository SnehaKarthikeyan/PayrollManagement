package com.ascentproject.rbac.exception;

public class PrivilegeNotFoundException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public PrivilegeNotFoundException() {
        super();
    }

    public PrivilegeNotFoundException(String message) {
        super(message);
    }

}
