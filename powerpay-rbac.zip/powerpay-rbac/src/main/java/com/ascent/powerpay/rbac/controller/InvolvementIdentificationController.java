package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.domain.InvolvementIdentification;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.InvolvementIdentificationService;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/involvementidentification", "/manage/involvementidentification"})
public class InvolvementIdentificationController {

    @Autowired
    private InvolvementIdentificationService involvementIdentificationService;

    @PostMapping("/managedentity/{managedEntityCode}/user/{userCode}")
    public ResponseEntity<InvolvementIdentification> saveInvolvementIdentification
                                            (@PathVariable("managedEntityCode") String managedEntityCode,
                                             @PathVariable("userCode") String userCode,
                                             @RequestBody InvolvementIdentification involvementIdentification) {
        ResponseEntity<InvolvementIdentification> responseEntity = null;
        InvolvementIdentification involvementIdentification1 = null;
        try {
            involvementIdentification1 = involvementIdentificationService.saveInvolvementIdentification(managedEntityCode, userCode, involvementIdentification);
            if(involvementIdentification1 == null) {
                responseEntity= new ResponseEntity<InvolvementIdentification>(involvementIdentification, HttpStatus.BAD_REQUEST);
            } else {
                responseEntity = new ResponseEntity<InvolvementIdentification>(involvementIdentification1, HttpStatus.CREATED);
            }
        } catch(Exception exception) {
            log.error("Unable to save Involvement Identification", exception);
            responseEntity = new ResponseEntity<InvolvementIdentification>(involvementIdentification1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/user/{userCode}/involvementidentification/{involvementIdentificationId}")
    public ResponseEntity<?> getInvolvementIdentificationById(@PathVariable("managedEntityCode") String managedEntityCode,
                                                              @PathVariable("userCode") String userCode,
                                                              @PathVariable("involvementIdentificationId") String involvementIdentificationId) {
        ResponseEntity<?> responseEntity= null;
        try {
            InvolvementIdentification involvementIdentification = involvementIdentificationService.
                    getInvolvementIdentificationById(managedEntityCode,userCode,involvementIdentificationId);
            if(involvementIdentification == null)
                responseEntity= new ResponseEntity(HttpStatus.BAD_REQUEST);
            else
            responseEntity= new ResponseEntity<InvolvementIdentification>(involvementIdentification, HttpStatus.OK);
        } catch(Exception exception) {
            log.error("Unable to find Involvement Identification", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Involvement Identification", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/user/{userCode}/involvementidentification")
    public ResponseEntity<?> getAllInvolvementIdentification(@PathVariable("managedEntityCode") String managedEntityCode,
                                                             @PathVariable("userCode") String userCode,
                                                             @RequestParam(required = false) String involvementIdentificationCode) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        if(involvementIdentificationCode == null || involvementIdentificationCode.length() == 0)
            responseEntity = getAllInvolvementIdentifications(managedEntityCode,userCode);
        else
            responseEntity = getInvolvementIdentificationByCode(managedEntityCode,userCode,involvementIdentificationCode);
        return responseEntity;
    }

    @NotNull
    private ResponseEntity<?> getAllInvolvementIdentifications(String managedEntityCode,String userCode) {
        ResponseEntity<?> responseEntity;
        try {
            List<InvolvementIdentification> involvementIdentification = involvementIdentificationService.getAllInvolvementIdentification(managedEntityCode,userCode);
            responseEntity = new ResponseEntity<>(involvementIdentification, HttpStatus.OK);
        }catch(Exception exception){
            log.error("Unable to get All Involvement Identification", exception);
            responseEntity = new ResponseEntity<String>("Unable to get All Involvement Identification", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @NotNull
    public ResponseEntity<?> getInvolvementIdentificationByCode(String managedEntityCode,String userCode,
                                    @RequestParam(required = false) String involvementIdentificationCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            InvolvementIdentification involvementIdentification= involvementIdentificationService.
                    getInvolvementIdentificationByCode(managedEntityCode,userCode,involvementIdentificationCode);
            List<InvolvementIdentification> involvementIdentifications= new ArrayList<>();
            if(involvementIdentification != null)
                involvementIdentifications.add(involvementIdentification);
            responseEntity= new ResponseEntity<>(involvementIdentifications,HttpStatus.OK);
        }catch (Exception exception) {
            log.error("Unable to find Involvement Identification", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Involvement Identification", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/managedentity/{managedEntityCode}/user/{userCode}/involvementidentification/{involvementIdentificationCode}")
    public ResponseEntity<?> updateInvolvementIdentification(
            @PathVariable("managedEntityCode") String managedEntityCode,
            @PathVariable("userCode") String userCode,
            @PathVariable("involvementIdentificationCode") String involvementIdentificationCode,
            @RequestBody InvolvementIdentification involvementIdentification) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            InvolvementIdentification involvementIdentification1 = involvementIdentificationService.updateInvolvementIdentification(managedEntityCode, userCode,
                    involvementIdentificationCode, involvementIdentification);
            responseEntity = new ResponseEntity<InvolvementIdentification>(involvementIdentification1, HttpStatus.OK);
        }catch(Exception exception) {
            log.error("Unable to find Involvement Identification", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Involvement Identification", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/user/{userCode}/involvementidentification/internal/{involvementIdentificationId}")
    public ResponseEntity<?> deleteInvolvementIdentificationById(@PathVariable("managedEntityCode") String managedEntityCode,
                                                                 @PathVariable("userCode") String userCode,
                                            @PathVariable("involvementIdentificationId") String involvementIdentificationId) {
        ResponseEntity<?> response = null;
        try {
            involvementIdentificationService.deleteInvolvementIdentificationById(managedEntityCode,userCode,involvementIdentificationId);
            response= new ResponseEntity<String> ("Involvement Identification '"+involvementIdentificationId+"' deleted", HttpStatus.OK);
        } catch (Exception exception) {
            log.error("Unable to delete Involvement Identification", exception);
            response= new ResponseEntity<String>("Unable to delete Involvement Identification", HttpStatus.BAD_REQUEST);
        }
        return response;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/user/{userCode}/involvementidentification")
    public ResponseEntity<?> deleteInvolvementIdentificationByCode(@PathVariable("managedEntityCode") String managedEntityCode,
                                                                   @PathVariable("userCode") String userCode,
                                                @RequestParam("involvementIdentificationCode") String involvementIdentificationCode) {
        ResponseEntity<?> response = null;
        try {
            involvementIdentificationService.deleteInvolvementIdentificationByCode(managedEntityCode,userCode,involvementIdentificationCode);
            response= new ResponseEntity<String> ("Involvement Identification '"+involvementIdentificationCode+"' deleted", HttpStatus.OK);
        } catch (Exception exception) {
            log.error("Unable to delete Involvement Identification", exception);
            response= new ResponseEntity<String>("Unable to delete Involvement Identification", HttpStatus.BAD_REQUEST);
        }
        return response;
    }

}
