package com.ascent.powerpay.rbac.service;

import com.ascent.powerpay.rbac.domain.UserRole;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface UserRoleService
{

    UserRole saveUserRole(String managedEntityCode, String roleCode, String userCode, UserRole userRole) throws NotFoundException;

    void saveBulkUpload(MultipartFile file) throws NotFoundException;

    UserRole getUserRoleById(String managedEntityCode, String roleCode, String userCode, String userRoleId) throws NotFoundException;

    UserRole getUserRoleByCode(String managedEntityCode, String roleCode, String userCode, String userRoleCode) throws NotFoundException;

    List<UserRole> getAllUserRole(String managedEntityCode, String roleCode, String userCode) throws NotFoundException;

    UserRole updateUserRole(String managedEntity_Code, String role_Code,
                   String user_Code, String userRole_Code, UserRole userRole) throws NotFoundException;

    void deleteUserRoleById(String managedEntityCode, String roleCode, String userCode, String userRoleId) throws NotFoundException;

    void deleteUserRoleByCode(String managedEntityCode, String roleCode, String userCode, String userRoleCode) throws NotFoundException;

}
