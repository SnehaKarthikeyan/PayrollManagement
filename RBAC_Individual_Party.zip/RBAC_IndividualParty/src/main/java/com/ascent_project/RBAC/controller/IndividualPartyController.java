package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.exception.NotFoundException;
import com.ascent_project.RBAC.model.IndividualParty;
import com.ascent_project.RBAC.service.serviceImpl.IndividualPartyServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/api/v1")
public class IndividualPartyController {

    @Autowired
    private IndividualPartyServiceImpl individualPartyServiceImpl;

    @GetMapping
    public ResponseEntity<?> getAllIndividualParty() {
        ResponseEntity<?> responseEntity=null;
        try {
            List<IndividualParty> list= individualPartyServiceImpl.getAllIndividualParty();
            responseEntity= new ResponseEntity<List<IndividualParty>>(list,HttpStatus.OK);
        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get All Individual Party",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @GetMapping("/individualPartyId/{individualParty_Id}")
    public ResponseEntity<?> getIndividualPartyById(@PathVariable("individualParty_Id")
                                                                String individualParty_Id){
        ResponseEntity<?> responseEntity = null;
        try {
            IndividualParty individualParty= individualPartyServiceImpl.getIndividualPartyById(individualParty_Id);
            responseEntity = new ResponseEntity<IndividualParty>(individualParty,HttpStatus.OK);
        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception e) {
            e.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to find Individual Party ID",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/individualPartyCode/{individualParty_Code}")
    public ResponseEntity<?> getIndividualPartyByCode(@PathVariable("individualParty_Code")
                                                            String individualParty_Code){
        ResponseEntity<?> responseEntity = null;
        try {
            IndividualParty individualParty= individualPartyServiceImpl.getIndividualPartyByCode(individualParty_Code);
            responseEntity = new ResponseEntity<IndividualParty>(individualParty,HttpStatus.OK);
        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception e) {
            e.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to find Individual Party Code",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/individualPartyCode/{code}")
    public ResponseEntity<?> updateByCode(@RequestBody IndividualParty individualParty, @PathVariable String individualParty_Code) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            IndividualParty individualParty1 = individualPartyServiceImpl.getIndividualPartyByCode(individualParty_Code);
            individualParty1.setName(individualParty.getName());
            individualParty1.setCode(individualParty.getCode());
            individualParty1.setActive(true);
            individualParty = individualPartyServiceImpl.updateIndividualPartyByCode(individualParty1);
            resp = new ResponseEntity<IndividualParty>(individualParty, HttpStatus.ACCEPTED); //202-accepted
        } catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception e) {
            e.printStackTrace();
            resp = new ResponseEntity<String>(
                    "Unable to find Individual Party Code",
                    HttpStatus.BAD_REQUEST);
        }
        return resp;
    }

    @DeleteMapping("/individualPartyId/{individualParty_Id}")
    public ResponseEntity<String> deleteIndividualPartyById(@PathVariable("individualParty_Id")
                                                                    String individualParty_Id){

        ResponseEntity<String> responseEntity= null;
        try {
            individualPartyServiceImpl.deleteIndividualPartyById(individualParty_Id);
            responseEntity= new ResponseEntity<String> (
                    "Individual Party '"+individualParty_Id+"' deleted",HttpStatus.OK);
        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/individualPartyCode/{individualParty_Code}")
    public ResponseEntity<String> deleteIndividualPartyByCode(@PathVariable("individualParty_Code")
                                                                String individualParty_Code){

        ResponseEntity<String> responseEntity= null;
        try {
            individualPartyServiceImpl.deleteIndividualPartyByCode(individualParty_Code);
            responseEntity= new ResponseEntity<String> (
                    "Individual Party '"+individualParty_Code+"' deleted",HttpStatus.OK);
        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Individual Party", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PostMapping
    public ResponseEntity<IndividualParty> saveIndividualParty(@RequestBody IndividualParty individualParty){
        ResponseEntity<IndividualParty> responseEntity = null;
        individualParty.setActive(true);
        try{
            String id = individualPartyServiceImpl.saveIndividualParty(individualParty);
            individualParty.setId(id);
            responseEntity= new ResponseEntity<IndividualParty>(
                    individualParty,HttpStatus.CREATED);
        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<IndividualParty>(
                    individualParty,
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

}
