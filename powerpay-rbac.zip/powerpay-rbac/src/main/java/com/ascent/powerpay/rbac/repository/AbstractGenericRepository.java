package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.util.ObjectMapperUtil;
import com.ascent.powerpay.rbac.util.SearchCriteria;
import com.ascent.powerpay.rbac.util.SearchQueryCriteriaConsumer;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public abstract class AbstractGenericRepository {

    @PersistenceContext
    protected EntityManager entityManager;
    private String DISTINCT_QUERY_TEMPLATE = "distinct on (%s) %s,";
    private String ORDER_BY_QUERY_TEMPLATE = "order by %s";
    private String WHERE_QUERY_TEMPLATE = "where %s ";
    private String SQL_SELECT_QUERY_TEMPLATE = "select %s * from %s %s %s";
    private String EMPTY_STRING = "";
    private String SQL_AGGREGATE_QUERY_TEMPLATE = "select %s from %s e";
    private String SQL_AGGREGATOR_FUNCTION_TEMPLATE = "%s(%s)";
    private String GROUP_BY_QUERY_TEMPLATE = "group by %s";
    private String SQL_FLOAT_CAST_TEMPLATE = "((e.%s)\\:\\:float) ";

    protected CriteriaQuery<?> getCriteraQuery(EntityManager entityManager, List<SearchCriteria> params, Class type) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<?> query = builder.createQuery(type);
        Root r = query.from(type);

        Predicate predicate = builder.conjunction();

        SearchQueryCriteriaConsumer searchConsumer =
                new SearchQueryCriteriaConsumer(predicate, builder, r);
        params.stream().forEach(searchConsumer);
        predicate = searchConsumer.getPredicate();
        query.where(predicate);
        return query;
    }

    abstract public List<?> searchEntity(List<SearchCriteria> params);

    public void save(Object entity) {
        throw new UnsupportedOperationException("Operation not supported by this repository");
    }

    public void truncate(Class entityClass) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaDelete query = builder.createCriteriaDelete(entityClass);
        query.from(entityClass);
        entityManager.createQuery(query).executeUpdate();
    }

    public Object findById(Long id, Class type) {
        return entityManager.find(type, id);
    }

    public void remove(Long id, String className) {
        try {
            Object object = findById(id, Class.forName(className).getClass());
            if (object != null) {
                entityManager.remove(Class.forName(className).cast(object));
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<Object> executeQuery(String distinct, String order_by, List<SearchCriteria> conditions, String tableName, String separator) {
        String distinct_column = buildDistinctQuery(distinct);
        String order_by_column = buildOrderByQuery(Arrays.asList(distinct, order_by));
        String condition_qs = buildConditionQuery(conditions, separator);
        String qs = String.format(SQL_SELECT_QUERY_TEMPLATE, distinct_column, tableName, condition_qs, order_by_column);

        //log.info("Query string executed: {}", qs);
        return processQuery(qs);
    }

    public Object aggregateQuery(String function, Object attributes) {
        if (function.equals("sum")) {
            return aggregateSumQuery(function, attributes);
        }
        return aggregateCountQuery(function, attributes);
    }

    private Object aggregateSumQuery(String functionName, Object attributes) {
        Map<String, Object> fields = ObjectMapperUtil.convertToMap(attributes);
        List<Object> fs = ObjectMapperUtil.convertToList(fields.get("fields"));
        String sumFieldsString = fs.stream().map(e -> String.format(SQL_FLOAT_CAST_TEMPLATE, e))
                .collect(Collectors.joining("+ "));
        String aggregatorQueryString = String.format(SQL_AGGREGATOR_FUNCTION_TEMPLATE, functionName, sumFieldsString);
        String sumString = String.format(SQL_AGGREGATE_QUERY_TEMPLATE, aggregatorQueryString, fields.get("table"));
        String groupBy = fields.containsKey("group") ? String.format(GROUP_BY_QUERY_TEMPLATE, fields.get("group")) : "";
        String whereCondition = fields.containsKey("condition") ? String.format(WHERE_QUERY_TEMPLATE, fields.get("condition")) : "";
        String str = String.format("%s %s%s", sumString, whereCondition, groupBy);
        return processAggregateQuery(str);
    }

    private Object aggregateCountQuery(String functionName, Object attributes) {
        Map<String, Object> fields = ObjectMapperUtil.convertToMap(attributes);
        List<Object> fs = ObjectMapperUtil.convertToList(fields.get("fields"));
        String aggregatorQueryString = String.format(SQL_AGGREGATOR_FUNCTION_TEMPLATE, functionName, fs.get(0));
        String sumString = String.format(SQL_AGGREGATE_QUERY_TEMPLATE, aggregatorQueryString, fields.get("table"));
        String groupBy = fields.containsKey("group") ? String.format(GROUP_BY_QUERY_TEMPLATE, fields.get("group")) : "";
        String whereCondition = fields.containsKey("condition") ? String.format(WHERE_QUERY_TEMPLATE, fields.get("condition")) : "";
        String str = String.format("%s %s%s", sumString, whereCondition, groupBy);
        return processAggregateQuery(str);
    }

    abstract Object processAggregateQuery(String queryString);

    abstract List<Object> processQuery(String queryString);

    private String buildConditionQuery(List<SearchCriteria> conditions, String separator) {
        String condition_qs = "";
        if (conditions != null && conditions.size() != 0) {
            List<String> condition_queries = new ArrayList<>();
            for (SearchCriteria condition : conditions) {
                condition_queries.add(String.format("%s %s %s", condition.getKey(), condition.getOperation(),
                        condition.getValue()));
            }
            String query = StringUtils.join(condition_queries, String.format(" %s ", separator));
            condition_qs = String.format(WHERE_QUERY_TEMPLATE, query);
        }
        return condition_qs;
    }

    private String buildDistinctQuery(String distinct) {
        if (distinct != null) {
            return String.format(DISTINCT_QUERY_TEMPLATE, distinct, distinct);
        }
        return EMPTY_STRING;
    }

    private String buildOrderByQuery(List<String> order_by_columns) {
        List<String> columns = order_by_columns.stream().filter(c -> c != null).collect(Collectors.toList());
        if (columns == null || columns.size() < 1) {
            return EMPTY_STRING;
        }
        if (columns.size() == 1) {
            return String.format(ORDER_BY_QUERY_TEMPLATE, columns.get(0));
        }
        return String.format(ORDER_BY_QUERY_TEMPLATE, StringUtils.join(order_by_columns, ", "));
    }
}
