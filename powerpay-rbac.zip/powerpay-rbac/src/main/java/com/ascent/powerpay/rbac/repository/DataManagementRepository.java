package com.ascent.powerpay.rbac.repository;

import java.util.List;

public interface DataManagementRepository {

    List<String> truncateAll();

    void dropTable(String[] tableNames);
}
