package com.ascent_project.RBAC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RbacApplicationTests {

	@Test
	void contextLoads() {
	}

}
