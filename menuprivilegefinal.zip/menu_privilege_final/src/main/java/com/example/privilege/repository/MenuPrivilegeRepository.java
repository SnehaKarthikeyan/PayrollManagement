package com.example.privilege.repository;

import com.example.privilege.model.MenuPrivilege;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface MenuPrivilegeRepository extends JpaRepository<MenuPrivilege,String> {


    MenuPrivilege findByCode (String code);
    MenuPrivilege findByManagedEntityIdAndId(String managedEntityId, String id);
    @Query("Select p from MenuPrivilege p order by menuOrder")
    List<MenuPrivilege> sortMenuOrder();
    MenuPrivilege findByManagedEntityIdAndCode(String managedEntityId, String privilegeCode);
}
