package com.Ascentproject.report.repository;

import com.Ascentproject.report.domain.ReportJoinField;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReportJoinFieldRepository extends JpaRepository<ReportJoinField,Integer> {

    List<ReportJoinField> findByReportId(int reportId);
}