package com.ascent.powerpay.rbac;

import com.ascent.powerpay.kernel.tenant.TenantUtil;
import com.ascent.powerpay.kernel.util.MappingUtil;
import com.ascent.powerpay.rbac.repository.DataManagementRepository;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

@Rollback
@ActiveProfiles("test")
@TestPropertySource(locations = "classpath:/application-test.properties")
@SpringBootTest(classes = UserPermissionServiceApplication.class)
@DirtiesContext
public abstract class AbstractRbacIntegrationTestcase extends AbstractRbacTestcase {

    @Autowired
    protected DataManagementRepository repository;

    @BeforeEach
    @AfterEach
    void truncateTables() {
        TenantUtil.addTenantIdToContext(TEST_TENANT);
//        repository.truncateAll();
    }

    protected <T> T eventFrom(String fileName, Class<T> clazz) throws IOException {
        InputStream eventJson = this.getClass().getResourceAsStream(fileName);
        String json = IOUtils.toString(eventJson, Charset.defaultCharset());
        return MappingUtil.fromJsonUsingGson(json, clazz);
    }
}
