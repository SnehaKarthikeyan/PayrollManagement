package com.Ascentproject.report.repository;

import com.Ascentproject.report.domain.ReportFilterField;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReportFilterFieldRepository extends JpaRepository<ReportFilterField,Integer> {
    List<ReportFilterField> findByReportId(int reportId);
}
