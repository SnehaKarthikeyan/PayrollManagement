package com.example.datasource.service.impl;

import com.example.datasource.domain.Datasource;
import com.example.datasource.domain.DatasourceParameter;
import com.example.datasource.exception.NotFoundException;
import com.example.datasource.repository.DatasourceParameterRepository;
import com.example.datasource.repository.DatasourceRepository;
import com.example.datasource.service.DatasourceParameterService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class DatasourceParameterServiceImpl implements DatasourceParameterService {
    @Autowired
    private DatasourceParameterRepository datasourceParameterRepository;

    @Autowired
    private DatasourceRepository datasourceRepository;

    @Override
    public DatasourceParameter saveDatasourceParameter(String datasourceCode, DatasourceParameter datasourceParameter) {
        boolean exists = false;
        if (datasourceParameter.getId() != 0) {
            exists = datasourceParameterRepository.existsById(datasourceParameter.getId());
        }
        if (exists) {
            return null;
        }
        long datasourceId;
        DatasourceParameter datasourceParameter1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            datasourceParameter.setActive(true);
            datasourceParameter.setDatasourceId(datasourceId);
            datasourceParameter1 = datasourceParameterRepository.save(datasourceParameter);
        }
        return datasourceParameter1;

    }

    @Override
    public DatasourceParameter getDatasourceParameterById(String datasourceCode, long datasourceParameterId) {
        long datasourceId;
        DatasourceParameter datasourceParameter = null;
        DatasourceParameter datasourceParameter1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            datasourceParameter = datasourceParameterRepository.findByDatasourceIdAndId(datasourceId, datasourceParameterId);
            if(datasourceParameter.isActive()) { datasourceParameter1 = datasourceParameter; }
        } else {
            log.info("DatasourceParameter object not found for {} & {}", datasourceCode, datasourceParameterId);
        }
        return datasourceParameter1;
    }

    @Override
    public List<Object> getAllDatasourceParameter(String datasourceCode) {
        long datasourceId;
        List<DatasourceParameter> list = null;
        List<Object> result = new ArrayList<Object>();
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            list = datasourceParameterRepository.findByDatasourceId(datasourceId);
            for(DatasourceParameter datasourceParameter: list) {
                if(datasourceParameter.isActive()) { result.add(datasourceParameter); }
            }
        } else {
            log.info("DatasourceParameter object not found for {}", datasourceCode);
        }
        return result;
    }

    @Override
    public DatasourceParameter updateDatasourceParameter(String datasourceCode, long datasourceParameterId, DatasourceParameter datasourceParameter) {
        DatasourceParameter datasourceParameter1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceParameter1 = getDatasourceParameterById(datasourceCode, datasourceParameterId);
            datasourceParameter1.setActive(true);
            BeanUtils.copyProperties(datasourceParameter, datasourceParameter1);
            datasourceParameterRepository.save(datasourceParameter1);
        } else {
            log.info("DatasourceParameter object not found for {}", datasourceCode);
        }
        return datasourceParameter;
    }

    @Override
    public void deleteDatasourceParameterById(String datasourceCode, long datasourceParameterId) {
        DatasourceParameter datasourceParameter = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null ) {
            datasourceParameter = getDatasourceParameterById(datasourceCode, datasourceParameterId);
            datasourceParameter.setActive(false);
            datasourceParameterRepository.save(datasourceParameter);
        } else {
            log.info("DatasourceParameter object not found for {}", datasourceCode);
        }
    }
}
