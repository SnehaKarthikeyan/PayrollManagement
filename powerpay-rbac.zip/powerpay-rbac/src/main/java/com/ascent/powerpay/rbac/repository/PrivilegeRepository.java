package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.domain.Privilege;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PrivilegeRepository extends JpaRepository<Privilege, String> {
    Privilege findByCode(String privilegeCode);
    Privilege findByManagedEntityIdAndId(String managedEntityId, String privilegeId);
    Privilege findByManagedEntityIdAndCode(String managedEntityId, String privilegeCode);
    List<Privilege> findAllByManagedEntityId(String managedEntityId);
}
