package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.ReportJoinField;
import java.util.List;

public interface ReportJoinFieldService {
    List<ReportJoinField> saveReportJoinField(int reportId, List<ReportJoinField> reportJoinFieldList);
    List<ReportJoinField> getReportJoinField(int reportId);
    List<ReportJoinField> updateReportJoinField(int reportId, List<ReportJoinField> reportJoinFieldList);
}
