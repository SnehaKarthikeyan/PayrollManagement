package com.ascent.powerpay.rbac.domain;

import com.ascent.powerpay.rbac.domain.JSONBUserType;
import com.ascent.powerpay.rbac.util.DateUtil;
import com.ascent.powerpay.rbac.util.Utils;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.Map;

@Entity
@Table(name = "employee")
@TypeDef(name = "jsonb", typeClass = JSONBUserType.class,
        parameters = {@Parameter(name = JSONBUserType.CLASS_TYPE, value = "java.util.Map")})
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class Employee extends AbstractEntity {

    public static final String EMP_CODE_KEY = "code";
    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @Column(name = "EMPLOYEE_ID")
    private String employeeId;

    @Type(type = "jsonb")
    @Column(name = "configuration")
    private Map<String, Object> properties;

    private String effectiveDate;

    @Column(name = "RUN_DATE")
    private Date runDate;

    @Column(name = "EMPLOYEE_CODE")
    private String code;

    @Column(name = "TIME_IN_MILLIS")
    private long timeInMillis;

    @Column(name = "LAST_PAYROLL_PERIOD_END_DATE")
    private Date payrollPeriodEnd;

    public Employee(String employeeId, Map<String, Object> properties, String effectiveDate) {
        this(null, employeeId, properties, effectiveDate, Utils.toDate(effectiveDate),
                (String) properties.getOrDefault(EMP_CODE_KEY, employeeId)
                , System.currentTimeMillis(), null);
    }

    public boolean earlierThan(Employee existingEmployee) {
        if ((effectiveDate == null || existingEmployee.effectiveDate == null) && (effectiveDate == "" || existingEmployee.effectiveDate == ""))
            return this.compareTimeInMillis(existingEmployee);
        return DateUtil.smaller(effectiveDate, existingEmployee.effectiveDate, "yyyy-mm-dd");
    }

    public boolean compareTimeInMillis(Employee existingEmployee) {
        return timeInMillis < existingEmployee.timeInMillis;
    }
}
