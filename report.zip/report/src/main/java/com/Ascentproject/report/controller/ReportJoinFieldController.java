package com.Ascentproject.report.controller;

import com.Ascentproject.report.domain.ReportJoinField;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.ReportJoinFieldService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/reportjoinfield", "/manage/reportjoinfield"})

public class ReportJoinFieldController {
    @Autowired
    private ReportJoinFieldService reportJoinFieldService;

    @CrossOrigin
    @PostMapping("reportId/{reportId}")
    public ResponseEntity<?> saveReportJoinField(@PathVariable int reportId,@RequestBody List<ReportJoinField> reportJoinFieldList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<ReportJoinField> reportJoinFieldList1= reportJoinFieldService.saveReportJoinField(reportId,reportJoinFieldList);
            if(reportJoinFieldList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save Report join field ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<ReportJoinField>>(
                    reportJoinFieldList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Report join field ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("reportId/{reportId}")
    public ResponseEntity<?> getAllReportJoinField(@PathVariable int reportId) throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<ReportJoinField> reportJoinFieldList =reportJoinFieldService.getReportJoinField(reportId);
            resp= new ResponseEntity<List<ReportJoinField>>(
                    reportJoinFieldList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report Join Field doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }

    @PutMapping("/reportId/{reportId}")
    public ResponseEntity<?> updateOrCopyById(@PathVariable int reportId,@RequestBody List<ReportJoinField> reportJoinFieldList) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            List<ReportJoinField> reportJoinFieldList1=reportJoinFieldService.updateReportJoinField(reportId,reportJoinFieldList);
            if(reportJoinFieldList1.size()<=0)
            {
                resp = new ResponseEntity<String>("Report Join Field doesn't exist", HttpStatus.BAD_REQUEST);
            }

            resp = new ResponseEntity<List<ReportJoinField>>( reportJoinFieldList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report Join Field doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }
}
