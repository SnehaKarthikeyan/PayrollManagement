package com.ascent.powerpay.rbac.service;

import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.exception.NotFoundException;

import java.util.List;

public interface IndividualPartyService
{

    IndividualParty saveIndividualParty(IndividualParty individualParty) throws NotFoundException;

    IndividualParty getIndividualPartyById(String user_Id) throws NotFoundException;

    List<IndividualParty> getAllIndividualParty() throws NotFoundException;

    IndividualParty getIndividualPartyByCode(String user_Code) throws NotFoundException;

    IndividualParty updateIndividualParty(String user_Code, IndividualParty individualParty) throws NotFoundException;

    void deleteIndividualPartyById(String user_Code) throws NotFoundException;

    void deleteIndividualPartyByCode(String user_Code) throws NotFoundException;

}

