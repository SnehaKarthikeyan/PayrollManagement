package com.Ascentproject.report.repository;

import com.Ascentproject.report.domain.DataField;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DataFieldRepository extends JpaRepository<DataField, Integer> {
}
