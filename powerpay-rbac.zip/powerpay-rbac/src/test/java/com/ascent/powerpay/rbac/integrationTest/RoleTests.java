package com.ascent.powerpay.rbac.integrationTest;

import com.ascent.powerpay.kernel.tenant.TenantInfo;
import com.ascent.powerpay.rbac.AbstractRestDocumentationTestCase;
import com.ascent.powerpay.rbac.TestUtil;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Role;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import javax.validation.constraints.NotNull;

import java.io.IOException;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
class RoleTests extends AbstractRestDocumentationTestCase {

    @Autowired
    TestUtil testUtil;

    @BeforeEach
    public void createManagedEntity() throws Exception
    {
        ManagedEntity managedEntity = testUtil.getManagedEntity("entityCode1",
                "entityType1", "entityName1");
        managedEntity = testUtil.addManagedEntityAPI(this.mockMvc, managedEntity);
        assertNotNull(managedEntity);
        assertEquals("entityCode1", managedEntity.getCode());
        assertEquals("entityType1", managedEntity.getType());
        assertEquals("entityName1", managedEntity.getName());
    }

    private Role[] getRoleArray(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Role[].class);
    }

    @Test
    public void testSaveRole() throws Exception
    {
        Role role = testUtil.getRole("roleCodeForSave", "roleNameForSave");
        role = testUtil.addRoleAPI(this.mockMvc,role);
        assertNotNull(role);
        assertEquals("roleCodeForSave", role.getCode());
        assertEquals("roleNameForSave", role.getName());
    }

    @Test
    public void testGetRoleById() throws Exception {
        Role role = testUtil.getRole("roleCodeForGetId","roleCodeForGetName");
        role = testUtil.addRoleAPI(this.mockMvc,role);
        String id = role.getId();

        role = getRoleById(id);
        assertNotNull(role);
        assertEquals("roleCodeForGetId", role.getCode());
        assertEquals("roleCodeForGetName", role.getName());
    }

    private Role getRoleById(String id) throws Exception {
        Role role;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/role/managedentity/entityCode1/role/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        role = testUtil.getRole(mvcResult);
        return role;
    }

    @Test
    public void testGetRoleByCode() throws Exception {
        Role role = testUtil.getRole("roleCodeForGetCode", "roleCodeForGetName");
        role = testUtil.addRoleAPI(this.mockMvc,role);
        String code = role.getCode();
        role = getRoleByCode(code);
        assertNotNull(role);
        assertEquals("roleCodeForGetCode", role.getCode());
        assertEquals("roleCodeForGetName", role.getName());
    }

    private Role getRoleByCode(String code) throws Exception {
        Role role;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/role/managedentity/entityCode1/role/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("roleCode", code)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        Role[]  roleArray = getRoleArray(mvcResult);
        assertEquals(1, roleArray.length);
        return roleArray[0];
    }

    @Test
    public void testGetAllRole() throws Exception {
        Role role = testUtil.getRole("code4", "name4");
        role = testUtil.addRoleAPI(this.mockMvc,role);

        assertEquals("code4", role.getCode());
        assertEquals("name4", role.getName());

        role = testUtil.getRole("code5", "name5");
        role = testUtil.addRoleAPI(this.mockMvc,role);

        Role[] result = getAllRole();
        assertNotNull(result);
        assertTrue(result.length == 2);
    }

    private Role[] getAllRole() throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/role/managedentity/entityCode1/role/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        Role[] roleResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Role[].class);
        return roleResult;
    }

    @Test
    public void testUpdateRole() throws Exception
    {
        Role role = testUtil.getRole("code6", "name6");
        role = testUtil.addRoleAPI(this.mockMvc,role);
        role.setName("updatedRoleName");
        String code = role.getCode();
        updateRoleAPI(role);
        role = getRoleByCode(code);

        assertNotNull(role);
        assertEquals("code6", role.getCode());
        assertEquals("updatedRoleName", role.getName());
    }

    private Role updateRoleAPI(Role me) throws Exception {

        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/role/managedentity/entityCode1/role/" + me.getCode())
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        Role roleResult = testUtil.getRole(mvcResult);
        return roleResult;

    }

    @Test
    public void testDeleteRoleById() throws Exception {
        Role role = testUtil.getRole("code7", "name7");
        role = testUtil.addRoleAPI(this.mockMvc,role);
        String id = role.getId();
        delete(id);
        try {
            this.mockMvc.perform(RestDocumentationRequestBuilders
                            .get("/manage/role/managedentity/entityCode1/role/" + id)
                            .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                            .accept(MediaType.APPLICATION_JSON))
                    .andExpect(status().isBadRequest());

        } catch (final Exception e) {
            fail("object status should have been saved.");
        }
    }

    @Test
    public void testDeleteRoleByCode() throws Exception {
        Role role = testUtil.getRole("code8", "name8");
        role = testUtil.addRoleAPI(this.mockMvc,role);
        String code = role.getCode();
        markForDelete(code);
        try
        {
            Role role1 = getRoleByCode(code);
            assertFalse(role1.isActive());
        }
        catch (final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private void markForDelete(String code) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/role/managedentity/entityCode1/role/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("roleCode", code)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

    private void delete(String id) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/role/managedentity/entityCode1/role/internal/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

}
