package com.ascent_project.RBAC.exception;

import com.ascent_project.RBAC.model.Role;

import java.util.function.Supplier;

public class RoleNotFoundException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    public RoleNotFoundException() {
        super();
    }

    public RoleNotFoundException(String message) {
        super(message);
    }

}
