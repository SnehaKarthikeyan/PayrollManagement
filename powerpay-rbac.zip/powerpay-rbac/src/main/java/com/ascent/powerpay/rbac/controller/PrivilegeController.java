package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.domain.Privilege;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.PrivilegeService;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/privilege", "/manage/privilege"})
public class PrivilegeController {

    @Autowired
    private PrivilegeService privilegeService;

    @PostMapping("/managedentity/{managedEntityCode}")
    public ResponseEntity<Privilege> savePrivilege(@PathVariable("managedEntityCode") String managedEntityCode,
                                                   @RequestBody Privilege privilege) throws NotFoundException {
        ResponseEntity<Privilege> responseEntity = null;
        Privilege privilege1 = null;
        try  {
            privilege1 = privilegeService.savePrivilege(managedEntityCode, privilege);
            if(privilege1 == null) {
                responseEntity= new ResponseEntity<>(privilege, HttpStatus.BAD_REQUEST);
            } else {
                responseEntity = new ResponseEntity<>(privilege1, HttpStatus.CREATED);
            }
        } catch (Exception exception) {
            log.error("Unable to save Privilege", exception);
            responseEntity = new ResponseEntity<>(privilege1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/privilege/{privilegeId}")
    public ResponseEntity<?> getPrivilegeById(@PathVariable("managedEntityCode") String managedEntityCode,
                                              @PathVariable("privilegeId") String privilegeId) throws NotFoundException {
        ResponseEntity<?> responseEntity= null;
        try {
            Privilege privilege= privilegeService.getPrivilegeById(managedEntityCode,privilegeId);
            if(privilege == null)
                responseEntity= new ResponseEntity(HttpStatus.BAD_REQUEST);
            else
            responseEntity= new ResponseEntity<Privilege>(privilege,HttpStatus.OK);
        } catch (Exception exception) {
            log.error("Unable to find Privilege", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Privilege", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/privilege")
    public ResponseEntity<?> getAllPrivilege(@PathVariable("managedEntityCode") String managedEntityCode,
                                             @RequestParam(required = false) String privilegeCode) throws NotFoundException {
        ResponseEntity<?> responseEntity =null;
        if(privilegeCode == null || privilegeCode.length() == 0)
            responseEntity = getAllPrivileges(managedEntityCode);
        else
            responseEntity = getPrivilegeByCode(managedEntityCode,privilegeCode);
        return responseEntity;
    }

    @NotNull
    private ResponseEntity<?> getAllPrivileges(String managedEntityCode) {
        ResponseEntity<?> responseEntity;
        try {
            List<Privilege> list= privilegeService.getAllPrivilege(managedEntityCode);
            responseEntity = new ResponseEntity<List<Privilege>>(list, HttpStatus.OK);
        } catch(Exception exception) {
            log.error("Unable to get Privilege", exception);
            responseEntity = new ResponseEntity<String>("Unable to get Privilege", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    public ResponseEntity<?> getPrivilegeByCode(String managedEntityCode,
                                                @RequestParam(required = false) String privilegeCode) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            Privilege privilege= privilegeService.getPrivilegeByCode(managedEntityCode,privilegeCode);
            List<Privilege> privileges= new ArrayList<>();
            if(privilege != null)
                privileges.add(privilege);
            responseEntity = new ResponseEntity<>(privileges,HttpStatus.OK);
        } catch (Exception exception) {
            log.error("Unable to find Privilege", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Privilege", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/managedentity/{managedEntityCode}/privilege/{privilegeCode}")
    public ResponseEntity<?> updatePrivilege(@PathVariable(value = "managedEntityCode") String managedEntityCode,
                                             @PathVariable(value = "privilegeCode") String privilegeCode,
                                             @RequestBody Privilege privilegeRequest) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            Privilege privilege= privilegeService.updatePrivilege(managedEntityCode, privilegeCode, privilegeRequest);
            responseEntity= new ResponseEntity<Privilege>(privilege,HttpStatus.OK);
        } catch (Exception exception) {
            log.error("Unable to find Privilege", exception);
            responseEntity = new ResponseEntity<String>("Unable to find Privilege", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/privilege/internal/{privilegeId}")
    public ResponseEntity<String> deletePrivilegeById(@PathVariable("managedEntityCode") String managedEntityCode,
                                                      @PathVariable("privilegeId") String privilegeId) throws NotFoundException {
        ResponseEntity<String> responseEntity = null;
        try {
            privilegeService.deletePrivilegeById(managedEntityCode,privilegeId);
            responseEntity= new ResponseEntity<String> ("Privilege '"+privilegeId+"' was deleted",HttpStatus.OK);
        } catch (Exception exception) {
            log.error("Unable to delete Privilege", exception);
            responseEntity= new ResponseEntity<String>("Unable to delete Privilege", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/privilege")
    public ResponseEntity<String> deletePrivilegeByCode(@PathVariable("managedEntityCode") String managedEntityCode,
                                                        @RequestParam("privilegecode") String privilegeCode) throws NotFoundException {
        ResponseEntity<String> responseEntity = null;
        try {
            privilegeService.deletePrivilegeByCode(managedEntityCode,privilegeCode);
            responseEntity= new ResponseEntity<String> ("Privilege '"+privilegeCode+"' was deleted",HttpStatus.OK);
        } catch (Exception exception) {
            log.error("Unable to delete Privilege", exception);
            responseEntity= new ResponseEntity<String>("Unable to delete Privilege", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
}
