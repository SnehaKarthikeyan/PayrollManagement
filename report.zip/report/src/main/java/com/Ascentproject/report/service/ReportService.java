package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.Report;
import java.util.List;

public interface ReportService {
    Report saveReport(int tenantId, Report report);
    Report findReportById(int tenantId, int reportId);
    Report updateReport(Report report, Report report1);
    List<Report> getReports(int tenantId);
    Report findReportByName(int tenantId, String reportName);
    void deleteOneReportByCode(int tenantId, String reportCode);
    void deleteOneReportById(int tenantId, int reportId);
}
