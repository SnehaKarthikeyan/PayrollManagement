package com.ascent.powerpay.rbac.util;

import lombok.extern.slf4j.Slf4j;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

@Slf4j
public class DateUtil {

    public static Date convertToDate(String date, String pattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        try {
            return simpleDateFormat.parse(date);
        } catch (ParseException e) {
            log.error("unable to parse date " + e);
        }
        return null;
    }

    public static boolean smaller(String date1, String date2, String pattern) {
        return convertToDate(date1, pattern).compareTo(convertToDate(date2, pattern)) < 0;
    }

    public static long compareTwoTimeStampsInMin(Timestamp currentTime, Timestamp oldTime){
        try {
            long diff = currentTime.getTime() - oldTime.getTime();
            return diff / (60 * 1000);
        }catch (Exception e){
            log.error("Error while calculating difference in hours - compareTwoTimeStamps");
        }return 0;
    }

    public static Timestamp getCurrentTimeStamp(){
        Date date = new Date();
        return new Timestamp(date.getTime());
    }

    public static int getMonth(Date date){
        LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        return localDate.getMonthValue();
    }

    public static int getYear(Date date){
        LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        return localDate.getYear();
    }
}
