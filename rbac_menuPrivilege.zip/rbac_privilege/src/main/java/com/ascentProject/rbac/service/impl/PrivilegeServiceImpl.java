package com.ascentProject.rbac.service.impl;

import com.ascentProject.rbac.domain.MenuPrivilege;

import com.ascentProject.rbac.repository.MenuPrivilegeRepository;

import com.ascentProject.rbac.service.PrivilegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PrivilegeServiceImpl implements PrivilegeService {


   @Autowired
    private MenuPrivilegeRepository menuPrivilegeRepository;

    @Override
    public List<MenuPrivilege> savePrivilege(List<MenuPrivilege> privilegeList) {

        List<MenuPrivilege> PrivilegeListNew = new ArrayList<>(privilegeList.size());

        MenuPrivilege privilege = new MenuPrivilege();
        privilege.setManagedEntityId(privilegeList.get(0).getManagedEntityId());
        privilege.setType(privilegeList.get(0).getType());
        privilege.setName(privilegeList.get(0).getName());
        privilege.setActive(privilegeList.get(0).getActive());
        privilege.setParentId(privilegeList.get(0).getParentId());
        privilege.setCode(privilegeList.get(0).getCode());
        privilege.setOrder(privilegeList.get(0).getOrder());

        PrivilegeListNew.add(privilege);


        List<MenuPrivilege> list = (List<MenuPrivilege>) menuPrivilegeRepository.saveAll(PrivilegeListNew);
        return list;
}


    public  void deleteOnePrivilegeByCode(String code)
    {
        MenuPrivilege privilege=menuPrivilegeRepository.findByCode(code);
        menuPrivilegeRepository.delete(privilege);
    }

    public void deleteOnePrivilegeById(String privilege_id) {
        MenuPrivilege privilege=menuPrivilegeRepository.findByPrivilegeId(privilege_id);
        menuPrivilegeRepository.delete(privilege);
    }
    public void deleteOnePrivilegeByParentId(String parent_id) {
        MenuPrivilege privilege=menuPrivilegeRepository.findByPrivilegeParentById(parent_id);
        menuPrivilegeRepository.delete(privilege);
    }

    public MenuPrivilege findPrivilegeByCode(String code) {
        MenuPrivilege privilege=menuPrivilegeRepository.findByCode(code);
        return privilege;

    }

    public MenuPrivilege updatePrivilege(MenuPrivilege menuPrivilege) {
        return menuPrivilegeRepository.save(menuPrivilege);
    }
}

