package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.exception.IndividualPartyNotFoundException;
import com.ascent_project.RBAC.model.IndividualParty;
import com.ascent_project.RBAC.repository.IndividualPartyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class IndividualPartyService {
    @Autowired
    private IndividualPartyRepository individualPartyRepository;

    public long saveIndividualParty(IndividualParty individualParty)
    {
        Long id = individualPartyRepository.save(individualParty).getId();
        return id;
    }
    public void deleteIndividualParty(Long id) {
        IndividualParty individualParty= getOneIndividualParty(id);
        individualPartyRepository.delete(individualParty);
    }
    public IndividualParty getOneIndividualParty(Long id) {
        IndividualParty individualParty = individualPartyRepository.findById(id)
                .orElseThrow(()->new IndividualPartyNotFoundException(
                        new StringBuffer().append("Individual Party having  '")
                                .append(id)
                                .append("' not exist")
                                .toString())
                );
        return individualParty;
    }

    public List<IndividualParty> getAllIndividualParty() {
        List<IndividualParty> individualPartyList = individualPartyRepository.findAll();
        individualPartyList.sort((ob1,ob2)->ob1.getId().intValue()-ob2.getId().intValue());
        //list.sort((ob1,ob2)->ob1.getAmount().compareTo(ob2.getAmount())); //ASC
        //list.sort((ob1,ob2)->ob2.getAmount().compareTo(ob1.getAmount())); // DESC
        return individualPartyList;
    }


}
