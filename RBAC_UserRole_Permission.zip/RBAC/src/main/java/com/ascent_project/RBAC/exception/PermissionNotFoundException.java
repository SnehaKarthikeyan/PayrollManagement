package com.ascent_project.RBAC.exception;

public class PermissionNotFoundException extends RuntimeException
{

    private static final long serialVersionUID = 1L;

    public PermissionNotFoundException() {
        super();
    }

    public PermissionNotFoundException(String message) {
        super(message);
    }
}
