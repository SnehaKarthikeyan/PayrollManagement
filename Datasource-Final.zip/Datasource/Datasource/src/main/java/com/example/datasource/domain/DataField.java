package com.example.datasource.domain;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Table(name = "DATA_FIELD")
@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class DataField {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "DATASOURCE_ID")
    private long datasourceId;

    @Column(name = "NAME")
    private String name;

    @Column(name = "DATATYPE_ID")
    private long dataTypeId;

    @Column(name= "ISJOINFIELD")
    private boolean joinField;

    @Column(name= "ISGROUPFIELD")
    private boolean groupField;

    @Column(name= "ISSORTFIELD")
    private boolean sortField;

    @Column(name= "ISDYNAMICFIELD")
    private boolean dynamicField;

    @Column(name= "ISFORMULAFIELD")
    private boolean formulaField;

    @Column(name= "ISFILTERFIELD")
    private boolean filterField;

    @Column(name = "FILTERDATASOURCE_ID")
    private long filterDatasourceId;

    @Column(name = "RECORDSTATUS_ID")
    private long recordStatusId;

    @Column(name= "ISACTIVE")
    private boolean active;

    @Column(name = "CREATED_BY_ID")
    private String createdById;

    @Column(name = "CREATED_BY_IP")
    private String createdByIp;

    @Column(name = "LAST_MODIFIED_BY_ID")
    private String lastModifiedById;

    @Column(name = "LAST_MODIFIED_BY_IP")
    private String lastModifiedByIp;
}
