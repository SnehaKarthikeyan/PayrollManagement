package com.Ascentproject.report.domain;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import javax.persistence.*;

@Table(name = "REPORT")
@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class Report {
    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    private int id;

    @Column(name = "CODE")
    private String code;

    @Column(name = "NAME")
    private String name;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "TENANT_ID")
    private int tenantId;

    @JoinColumn
    private Category categoryId;

    @JoinColumn
    private GraphType graphTypeId;

    @JoinColumn
    private ReportType reportTypeId;

    @Column(name = "PREVIOUS_DATA_MONTH")
    private int previousDataMonth;

    @Column(name= "EXCEL_PASSWORD")
    private String excelPassword;

    @Column(name= "EXCEL_SHEET_PASSWORD")
    private String excelSheetPassword;

    @Column(name = "REPORT_NAME_FORMAT")
    private String reportNameFormat;

    @Column(name = "BATCH_REPORT")
    private boolean batchReport;

    @Column(name = "PERIODIC_REPORT")
    private boolean periodicReport;

    @Column(name = "RECORD_STATUS_ID")
    private boolean recordStatus;


}

