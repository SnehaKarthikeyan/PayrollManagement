package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.ReportJoinField;
import com.Ascentproject.report.repository.*;
import com.Ascentproject.report.service.ReportJoinFieldService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportJoinFieldServiceImpl implements ReportJoinFieldService {

    @Autowired
    private ReportDataSourceRepository reportDataSourceRepository;

    @Autowired
    private ReportJoinFieldRepository reportJoinFieldRepository;

    @Autowired
    private DataFieldRepository dataFieldRepository;



    public List<ReportJoinField> saveReportJoinField (int reportId, List<ReportJoinField> reportJoinFieldList) {
        reportJoinFieldList.stream().forEach(reportJoinField-> reportJoinField.setReportId(reportId));
        return reportJoinFieldRepository.saveAll(reportJoinFieldList);
    }

    public List<ReportJoinField> getReportJoinField(int reportId){
        List<ReportJoinField> reportJoinFieldList= reportJoinFieldRepository.findByReportId(reportId).stream()
                .collect(Collectors.toList());
        return reportJoinFieldList;
    }

    public List<ReportJoinField> updateReportJoinField(int reportId, List<ReportJoinField> reportJoinFieldList) {
        List<ReportJoinField> reportJoinFieldList1=reportJoinFieldRepository.findByReportId(reportId);
        reportJoinFieldList1.stream().forEach(reportJoinField -> reportJoinFieldRepository.delete(reportJoinField));
        return saveReportJoinField(reportId,reportJoinFieldList);
    }

}
