package com.example.datasource.service.impl;

import com.example.datasource.domain.Datasource;
import com.example.datasource.exception.NotFoundException;
import com.example.datasource.repository.DataFieldRepository;
import com.example.datasource.repository.DatasourceRepository;
import com.example.datasource.service.DatasourceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class DatasourceServiceImpl implements DatasourceService {
    @Autowired
    private DatasourceRepository datasourceRepository;

    @Autowired
    private DataFieldRepository dataFieldRepository;

    @Override
    public Datasource saveDatasource(Datasource datasource) {
        boolean exists = false;
        if(datasource.getId() != 0) {
            exists = datasourceRepository.existsById(datasource.getId());
        }
        if(exists) {
            return null;
        }
        datasource.setDefault(true);
        datasource.setActive(true);
        Datasource datasource1 = datasourceRepository.save(datasource);
        return datasource1;
    }

    @Override
    public Datasource getDatasourceById(long datasourceId) {
        Datasource datasource1 = null;
        Datasource datasource = datasourceRepository.findById(datasourceId)
                .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Datasource  '")
                                .append(datasourceId)
                                .append("' not exist")
                                .toString()));
        if(datasource.isActive()) {
            datasource1 = datasource;
        }
        return datasource1;
    }

    @Override
    public Datasource getDatasourceByCode(String datasourceCode) {
        Datasource datasource;
        Datasource datasource1 = null;
        datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource.isActive()) {
            datasource1 = datasource;
        }
        return datasource1;
    }

    @Override
    public List<Datasource> getAllDatasource() {
        List<Datasource> result = new ArrayList<Datasource>();
        List<Datasource> list = datasourceRepository.findAll();
        for(Datasource datasource: list) {
            if(datasource.isActive()) { result.add(datasource);}
        }
        return result;
    }

    @Override
    public Datasource updateDatasource(String datasourceCode, Datasource datasource) {
        Datasource datasource1 = datasourceRepository.findByCode(datasourceCode);
        datasource1.setDefault(true);
        datasource1.setActive(true);
        BeanUtils.copyProperties(datasource, datasource1);
        return datasourceRepository.save(datasource1);
    }

    @Override
    public void deleteDatasourceById(long datasourceId) {
        Datasource datasource = getDatasourceById(datasourceId);
        datasource.setActive(false);
        datasourceRepository.save(datasource);
    }

    @Override
    public void deleteDatasourceByCode(String datasourceCode) {
        Datasource datasource = getDatasourceByCode(datasourceCode);
        datasource.setActive(false);
        datasourceRepository.save(datasource);
    }
}
