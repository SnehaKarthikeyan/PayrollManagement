package com.report.ReportGroup.Service;

import com.report.ReportGroup.Domain.ReportGroup;

import java.util.List;

public interface ReportGroupService {
    ReportGroup saveReportGroup(ReportGroup reportGroup);

    ReportGroup getReportGroupById(int reportGroupId);

    ReportGroup getReportGroupByCode(String reportGroupCode);

    List<ReportGroup> getAllReportGroup();

    List<ReportGroup> updateReportGroup(String reportGroupCode, ReportGroup reportGroup);

    void deleteReportGroupById(int reportGroupId);

    void deleteReportGroupByCode(String reportGroupCode);
}
