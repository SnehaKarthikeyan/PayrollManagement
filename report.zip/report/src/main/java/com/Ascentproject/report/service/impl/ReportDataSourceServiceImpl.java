package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.ReportDataSource;
import com.Ascentproject.report.repository.DatasourceRepository;
import com.Ascentproject.report.repository.ReportDataSourceRepository;
import com.Ascentproject.report.repository.ReportRepository;
import com.Ascentproject.report.service.ReportDataSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportDataSourceServiceImpl implements ReportDataSourceService {

    @Autowired
    private ReportDataSourceRepository reportDataSourceRepository;

    @Autowired
    private DatasourceRepository dataSourceRepository;

    @Autowired
    private ReportRepository reportRepository;



    public List<ReportDataSource> saveReportDataSource (int reportId,List<ReportDataSource> reportDataSourceList) {

         reportDataSourceList.stream().forEach(reportDataSource -> reportDataSource.setReportId(reportId));
         return reportDataSourceRepository.saveAll(reportDataSourceList);
    }


    public  List<ReportDataSource> getReportDataSource(int reportId) {
        List<ReportDataSource> reportDataSourceList= reportDataSourceRepository.findById(reportId).stream()
                .collect(Collectors.toList());
        return reportDataSourceList;
    }
    public List<ReportDataSource> updateDatasource(int reportId, List<ReportDataSource> reportDataSourceList)
    {
        List<ReportDataSource>reportDataSourceList1=reportDataSourceRepository.findByReportId(reportId);
        reportDataSourceList1.stream().forEach(reportDataSource -> reportDataSourceRepository.delete(reportDataSource));
        return saveReportDataSource(reportId,reportDataSourceList1);
    }
    public int findByReportId(int reportId) {

      int reportId1 =reportRepository.findById(reportId);
      return reportId1;

    }
}
