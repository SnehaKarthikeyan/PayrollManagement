package com.ascent_project.RBAC.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="PERMISSION")
public class Permission {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "VALID_FOR")
    private String validFor;

    @ManyToOne
    @JoinColumn(name = "MANAGED_ENTITY_ID")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private ManagedEntity managedEntity;

    public Permission(long id, ManagedEntity managedEntity,String name, String description, String valid_for) {
        this.id=id;
        this.managedEntity=managedEntity;
        this.name=name;
        this.description=description;
        this.validFor=valid_for;
    }
}
