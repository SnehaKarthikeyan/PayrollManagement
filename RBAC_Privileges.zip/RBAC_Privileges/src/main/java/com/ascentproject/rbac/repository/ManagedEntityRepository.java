package com.ascentproject.rbac.repository;


import com.ascentproject.rbac.model.ManagedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManagedEntityRepository extends JpaRepository<ManagedEntity, Long> {
}
