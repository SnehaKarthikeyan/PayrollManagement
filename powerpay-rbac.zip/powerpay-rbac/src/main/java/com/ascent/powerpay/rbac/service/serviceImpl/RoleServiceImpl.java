package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Role;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.repository.ManagedEntityRepository;
import com.ascent.powerpay.rbac.repository.RoleRepository;
import com.ascent.powerpay.rbac.service.RoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class RoleServiceImpl implements RoleService
{

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public Role saveRole(String managedEntity_Code, Role role) throws NotFoundException {
        boolean exists = false;
        if(role.getId() != null)
        {
            exists = roleRepository.existsById(role.getId());
        }
        if(exists)
        {
            return null;
        }
        ManagedEntity managedEntity = getManagedEntity(managedEntity_Code);
        role.setManagedEntityId(managedEntity.getId());
        role.setActive(true);
        Role role1 = roleRepository.save(role);
        return role1;
    }

    public Role getRoleById(String managedEntityCode,String roleId) throws NotFoundException
    {
        String managedEntityId = null;
        Role role = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        if(me != null) {
            managedEntityId = me.getId();
            role = roleRepository.findByManagedEntityIdAndId(managedEntityId,roleId);
        } else {
            log.info("role object not found for {} & {}", managedEntityCode, roleId);
        }
        return role;
    }

    public Role getRoleByCode(String managedEntityCode,String roleCode) throws NotFoundException {
        String managedEntityId = null;
        Role role = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        if(me != null) {
            managedEntityId = me.getId();
            role = roleRepository.findByManagedEntityIdAndCode(managedEntityId,roleCode);
        } else {
            log.info("role object not found for {} & {}", managedEntityCode, roleCode);
        }

        return role;
    }

    public List<Role> getAllRole(String managedEntityCode) throws NotFoundException {
        String managedEntityId = null;
        List<Role> list = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        if(me != null) {
            managedEntityId = me.getId();
            list = roleRepository.findAllByManagedEntityId(managedEntityId);
        } else {
            log.info("managed entity object not found for {}", managedEntityCode);
        }

        return list;
    }

    public Role updateRole(String managedEntityCode, String roleCode, Role role) throws NotFoundException {
        ManagedEntity managedEntity = getManagedEntity(managedEntityCode);
        Role role1 = roleRepository.findByManagedEntityIdAndCode(managedEntity.getId(),roleCode);
        role1.setCode(role.getCode());
        role1.setName(role.getName());
        role1.setActive(role.isActive());
        return roleRepository.save(role1);
    }

    private ManagedEntity getManagedEntity(String managedEntityCode) throws NotFoundException {
        ManagedEntity me = managedEntityRepository.findByCode(managedEntityCode);
        if(me == null) throw new NotFoundException(managedEntityCode + " Managed Entity Not Found");
        return me;
    }

    public void deleteRoleById(String managedEntityCode,String roleId) throws NotFoundException{

        Role role = getRoleById(managedEntityCode,roleId);
        roleRepository.delete(role);
    }

    public void deleteRoleByCode(String managedEntityCode,String roleCode) throws NotFoundException{
        Role role = getRoleByCode(managedEntityCode,roleCode);
        role.setActive(false);
        roleRepository.save(role);
    }

}
