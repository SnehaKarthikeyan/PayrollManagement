package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.dse.config.StorageConfiguration;
import com.ascent.powerpay.dse.repository.StorageStructureRepository;
import com.ascent.powerpay.dse.storage.ConfigurationProcessor;
import com.ascent.powerpay.rbac.util.DBSessionHandler;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class DataManagementRepositoryImpl implements DataManagementRepository {

    private static final String ALL_TABLES_QUERY = "SELECT table_name FROM information_schema.tables " +
            " WHERE table_schema NOT IN ('information_schema', 'pg_catalog') AND " +
            " table_type = 'BASE TABLE'";
    private final StorageStructureRepository repository;
    private final ConfigurationProcessor processor;
    private String SQL_TRUNCATE_TEMPLATE = "TRUNCATE TABLE %s CASCADE;";
    private EntityManager entityManager;
    private StorageConfiguration configuration;


    @Autowired
    public DataManagementRepositoryImpl(EntityManager entityManager,
                                        StorageStructureRepository repository,
                                        ConfigurationProcessor processor,
                                        StorageConfiguration configuration) {
        this.entityManager = entityManager;
        this.repository = repository;
        this.processor = processor;
        this.configuration = configuration;
    }

    @Transactional
    public void dropTable(String[] tableNames) {
        DBSessionHandler handler = new DBSessionHandler(entityManager);
        final ArrayList<String> tableNamesfinal = new ArrayList<>();
        Session session = entityManager.unwrap(Session.class);
        session.doWork(c -> {
            ResultSet resultSet = c.prepareStatement(ALL_TABLES_QUERY).executeQuery();
            List<String> includedTables = List.of(tableNames);

            while (resultSet.next()) {
                String name = resultSet.getString(1);
                if (includedTables.contains(name)) {
                    tableNamesfinal.add(name);
                }
            }
        });

        for (String tableName : tableNamesfinal) {
            try {
                handler.dropTable(tableName);
            } catch (Exception e) {
                log.info(e.getMessage());
            }

        }
    }

    @Transactional
    public List<String> truncateAll() {
        processor.reset();
        configuration.clear();
        Session session = entityManager.unwrap(Session.class);
        return session.doReturningWork(c -> {
            ResultSet resultSet = c.prepareStatement(ALL_TABLES_QUERY).executeQuery();
            ArrayList<String> tableNames = new ArrayList<>();
            List<String> excludeTables = List.of("databasechangelog", "databasechangeloglock");

            while (resultSet.next()) {
                String name = resultSet.getString(1);
                if (!excludeTables.contains(name)) {
                    tableNames.add(name);
                }
            }

            tableNames.forEach(name -> {
                try {
                    c.prepareStatement(String.format(SQL_TRUNCATE_TEMPLATE, name))
                            .executeUpdate();
                } catch (SQLException e) {
                    log.error("Failed to truncate: {}" + name, e);
                    throw new IllegalStateException("Failed to truncate table: " + name, e);
                }
            });

            return tableNames;
        });
    }
}
