package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.ManagedEntityService;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/managedentity", "/manage/managedentity"})

public class ManagedEntityController {

    @Autowired
    private ManagedEntityService managedEntityService;

    @PostMapping
    public ResponseEntity<ManagedEntity> saveManagedEntity(@RequestBody ManagedEntity managedEntity) throws NotFoundException {
        ResponseEntity<ManagedEntity> responseEntity = null;
        ManagedEntity managedEntitySaved = null;
        try {
            managedEntitySaved = managedEntityService.saveManagedEntity(managedEntity);
            if(managedEntitySaved == null) {
                responseEntity= new ResponseEntity<>(managedEntity, HttpStatus.BAD_REQUEST);
            } else {
                responseEntity = new ResponseEntity<>(managedEntitySaved, HttpStatus.CREATED);
            }
        }catch(Exception e) {
            log.debug("Unable to save Managed Entity");
            responseEntity = new ResponseEntity<>(managedEntity, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{managedEntityId}")
    public ResponseEntity<?> getManagedEntityById(@PathVariable("managedEntityId") String managedEntityId) throws NotFoundException {
        ResponseEntity<?> responseEntity= null;
        try {
            ManagedEntity managedEntity= managedEntityService.getManagedEntityById(managedEntityId);
            responseEntity= new ResponseEntity<ManagedEntity>(managedEntity,HttpStatus.OK);
        }catch(Exception e) {
            log.debug("Unable to get Managed Entity");
            responseEntity = new ResponseEntity<String>("Unable to get Managed Entity", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping
    public ResponseEntity<?> getAllManagedEntity(@RequestParam(required = false) String code) {
        ResponseEntity<?> responseEntity= null;
        if(code == null || code.length() == 0)
            responseEntity = getAllManagedEntities();
        else
            responseEntity = getResponseEntityByCode(code);
        return responseEntity;
    }

    @NotNull
    private ResponseEntity<?> getResponseEntityByCode(@RequestParam(required = false) String code) {
        ResponseEntity<?> responseEntity;
        try {
            ManagedEntity managedEntity= managedEntityService.getManagedEntityByCode(code);
            List<ManagedEntity> managedEntities= new ArrayList<>();
            if(managedEntity != null)
                managedEntities.add(managedEntity);
            responseEntity= new ResponseEntity<>(managedEntities, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get All Managed Entity");
            responseEntity = new ResponseEntity<String>("Unable to get All Managed Entity", HttpStatus.BAD_REQUEST);

        }
        return responseEntity;
    }

    @NotNull
    private ResponseEntity<?> getAllManagedEntities() {
        ResponseEntity<?> responseEntity;
        try {
            List<ManagedEntity> managedEntity= managedEntityService.getAllManagedEntity();
            responseEntity= new ResponseEntity<List<ManagedEntity>>(managedEntity, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get All Managed Entity");
            responseEntity = new ResponseEntity<String>("Unable to get All Managed Entity", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/{managedEntityCode}")
    public ResponseEntity<?> updateManagedEntity(@PathVariable("managedEntityCode") String managedEntityCode,
                                                             @RequestBody ManagedEntity managedEntity) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        List<ManagedEntity> managedEntities = null;
        try {
            ManagedEntity me  = managedEntityService.updateManagedEntity(managedEntityCode, managedEntity);
            responseEntity = new ResponseEntity<ManagedEntity>(me, HttpStatus.OK);
        }catch(Exception e) {
            log.debug("Unable to find Managed Entity");
            responseEntity = new ResponseEntity<String>("Unable to find Managed Entity", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/internal/{managedEntityId}")
    public ResponseEntity<?> deleteManagedEntityById(@PathVariable(value = "managedEntityId") String managedEntityId)  {
        ResponseEntity<?> responseEntity= null;
        try {
            managedEntityService.deleteManagedEntityById(managedEntityId);
            responseEntity = new ResponseEntity<String> ("Managed Entity "+managedEntityId+"' deleted", HttpStatus.OK);
        }catch (NotFoundException e) {
            log.debug("Unable to delete Managed Entity");
            responseEntity = new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping
    public ResponseEntity<?> deleteManagedEntityByCode(@RequestParam("code") String managedEntityCode) throws NotFoundException {
        ResponseEntity<?> responseEntity= null;
        try {
            managedEntityService.deleteManagedEntityByCode(managedEntityCode);
            responseEntity = new ResponseEntity<String>("Managed Entity '" + managedEntityCode + "' deleted", HttpStatus.OK);
        }catch (Exception e) {
            log.debug("Unable to delete Managed Entity");
            responseEntity = new ResponseEntity<String>("Unable to delete Managed Entity", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

}
