package com.ascent_project.RBAC.exception;

public class UserRoleNotFoundException extends RuntimeException
{

    private static final long serialVersionUID = 1L;

    public UserRoleNotFoundException() {
        super();
    }

    public UserRoleNotFoundException(String message) {
        super(message);
    }
}
