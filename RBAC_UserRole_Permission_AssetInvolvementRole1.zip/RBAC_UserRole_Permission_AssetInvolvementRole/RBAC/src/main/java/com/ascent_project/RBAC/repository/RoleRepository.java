package com.ascent_project.RBAC.repository;

import com.ascent_project.RBAC.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RoleRepository extends JpaRepository<Role, Long> {
    @Query("SELECT u from Role u WHERE id=:role_id")
    List<Role> findByRoleId(Long role_id);
}
