package com.ascent_project.RBAC;

import com.ascent_project.RBAC.model.UserRole;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RbacApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}
	@Test
	void contextLoads() {
	}

	@Test
	@Order(1)
	public void testGetAllEmployees() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/role/5/user",
				HttpMethod.GET, entity, String.class);
		assertNotNull(response.getBody());
	}

	@Test
	@Order(2)
	public void testGetUserRoleById() {
		UserRole userRole = restTemplate.getForObject(getRootUrl() + "/role/6/user/4", UserRole.class);
		//System.out.println(employee.getFirstName());
		assertNotNull(userRole);
	}

	@Test
	@Order(4)
	public void testDeleteUserRole(){
		int id = 4;
		UserRole userRole= restTemplate.getForObject(getRootUrl() + "/role/6/user/" + id, UserRole.class);
		assertNotNull(userRole);
		restTemplate.delete(getRootUrl() + "/role/5/user/" + id);
		try {
			userRole = restTemplate.getForObject(getRootUrl() + "/role/5/user/" + id, UserRole.class);
		} catch (final HttpClientErrorException e) {
			assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}

	@Test
	@Order(3)
	public void testCreateEmployee() {
		UserRole userRole = new UserRole();
		userRole.setId(4L);
		userRole.setValid_for("1999-02-09");


		HttpHeaders headers = new HttpHeaders();
		headers.set("COM-PERSIST","true");
		HttpEntity<UserRole> entity= new HttpEntity<>(userRole,headers);
		ResponseEntity<String> result = this.restTemplate.postForEntity(getRootUrl() + "/role/6/user/30", entity, String.class);
		//assertNotNull(postResponse);
		//assertNotNull(postResponse.getBody());
	}

}
