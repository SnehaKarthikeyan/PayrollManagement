package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.BulkHelper.BulkHelperPermission;
import com.ascent_project.RBAC.model.*;
import com.ascent_project.RBAC.repository.ManagedEntityRepository;
import com.ascent_project.RBAC.repository.PermissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class PermissionServiceImpl {

    @Autowired
    ManagedEntityRepository managedEntityRepository;

    @Autowired
    PermissionRepository permissionRepository;

    public Long saveIndividualPermission(Long managedEntity_id, Permission permission) {
        ManagedEntity managedEntity=managedEntityRepository.findById(managedEntity_id).get();
        permission.setManagedEntity(managedEntity);
        permissionRepository.save(permission);
        return permission.getId();
    }
    public Permission getOnePermission(Long managedEntity_id, Long permission_id) {
        Permission permission;
        permission = permissionRepository.findByManagedEntityAndPermissionId(managedEntity_id, permission_id);
        return permission;
    }

    public List<Permission> getAllPermissions(Long managedEntity_id) {
        List<Permission> permission = permissionRepository.findByManagedEntityId(managedEntity_id);
        return permission;
    }


    public void saveBulkUpload(MultipartFile file) {
        try {
            List<Permission> permissions = BulkHelperPermission.csvToJson(file.getInputStream(),managedEntityRepository,permissionRepository);

          /* for(UserRole user : userRoles)
            {
                System.out.println(user);
                userRoleRepository.save(user);
                userRoleRepository.flush();
            }*/
            permissionRepository.saveAll(permissions);
        }
        catch (IOException e) {
            throw new RuntimeException("fail to store csv user roles data " + e.getMessage());
        }
    }

    public void deleteOnePermission(Long managedEntity_id, Long permission_id) {
        Permission permission = getOnePermission(managedEntity_id, permission_id);
        permissionRepository.delete(permission);
    }
}
