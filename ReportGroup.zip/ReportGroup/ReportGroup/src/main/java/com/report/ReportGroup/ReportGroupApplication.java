package com.report.ReportGroup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportGroupApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportGroupApplication.class, args);
	}

}
