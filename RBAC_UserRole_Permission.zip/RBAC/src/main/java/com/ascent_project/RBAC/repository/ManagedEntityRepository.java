package com.ascent_project.RBAC.repository;


import com.ascent_project.RBAC.model.ManagedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ManagedEntityRepository extends JpaRepository<ManagedEntity, Long> {
    @Query("SELECT u from ManagedEntity u WHERE id=:managed_entity_id")
    List<ManagedEntity> findByManagedEntityId(Long managed_entity_id);

}
