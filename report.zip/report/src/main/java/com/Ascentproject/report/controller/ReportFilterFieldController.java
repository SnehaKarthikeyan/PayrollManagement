package com.Ascentproject.report.controller;


import com.Ascentproject.report.domain.ReportFilterField;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.ReportFilterFieldService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/reportFilterField", "/manage/reportFilterField"})

public class ReportFilterFieldController {
    @Autowired
    private ReportFilterFieldService reportFilterFieldService;

    @CrossOrigin
    @PostMapping("/reportId/{reportId}")
    public ResponseEntity<?> saveReportFilterField(@PathVariable int reportId,@RequestBody List<ReportFilterField> reportFilterFieldList){
        ResponseEntity<?> responseEntity = null;
        try{
            List<ReportFilterField> reportFilterFieldList1= reportFilterFieldService.saveReportFilterField(reportId,reportFilterFieldList);
            if(reportFilterFieldList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save Report Filter field ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<ReportFilterField>>(
                    reportFilterFieldList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Report Filter field",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("reportId/{reportId}")
    public ResponseEntity<?> updateOrCopyById(@RequestBody List<ReportFilterField> reportFilterFieldList , @PathVariable int reportId) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            int reportId1= reportFilterFieldService.findByReportId(reportId);
            if(reportId1==0)
            {
                resp = new ResponseEntity<String>("Report Filter Field doesn't exist", HttpStatus.BAD_REQUEST);
            }
            List<ReportFilterField> reportDataSourceList1= reportFilterFieldService.updateFilterField(reportId,reportFilterFieldList);
            resp = new ResponseEntity<List<ReportFilterField>>( reportDataSourceList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report Filter Field doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }

    @GetMapping("reportId/{reportId}")
    public ResponseEntity<?> getAllReportFilterFields(@PathVariable int reportId) throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<ReportFilterField> reportFilterFieldList = reportFilterFieldService.getReportFilterField(reportId);
            resp= new ResponseEntity<List<ReportFilterField>>(
                    reportFilterFieldList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report Filter Field doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}


