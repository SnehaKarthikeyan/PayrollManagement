package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.model.ManagedEntity;

import java.util.List;

public interface IManagedEntityService {
    Long saveEntity(ManagedEntity me);
    void deleteEntity(Long id);
    ManagedEntity getOneEntity(Long id);
    List<ManagedEntity> getAllEntity();

}
