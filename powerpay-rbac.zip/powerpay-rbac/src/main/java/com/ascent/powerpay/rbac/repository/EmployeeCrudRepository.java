package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.domain.Employee;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;

@Repository
@Transactional
public interface EmployeeCrudRepository extends CrudRepository<Employee, String> {
    Employee findByEmployeeId(String employeeId);

    Employee findByCode(String code);

    List<Employee> findBymodifiedOnBetween(Date RangeStart, Date RangeEnd);
}
