package com.Ascentproject.report.domain;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import javax.persistence.*;

@Table(name = "DATASOURCE")
@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class Datasource {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "TENANT_ID")
    private long tenantId;

    @Column(name = "CODE")
    private String code;

    @Column(name = "NAME")
    private String name;

    @Column(name = "DATASOURCETYPE_ID")
    private long datasourceTypeId;

    @Column(name= "COMMAND_TEXT")
    private String commandText;

    @Column(name= "COUNTRY_ID")
    private String countryId;

    @Column(name= "ISDEFAULT")
    private boolean isDefault;

    @Column(name= "RECORD_STATUS_ID")
    private long recordStatusId;

    @Column(name= "ISACTIVE")
    private boolean isActive;

    @Column(name = "CREATED_BY_ID")
    private String createdById;

    @Column(name = "CREATED_BY_IP")
    private String createdByIp;

    @Column(name = "LAST_MODIFIED_BY_ID")
    private String lastModifiedById;

    @Column(name = "LAST_MODIFIED_BY_IP")
    private String lastModifiedByIp;
}
