package com.ascent_project.RBAC;

import com.ascent_project.RBAC.model.Role;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RbacApplication.class,
		webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RbacApplicationTests {

	@LocalServerPort
	private int port;

	@Autowired
	private TestRestTemplate restTemplate;

	public HttpHeaders headers = new HttpHeaders();

	private String getRootUrl() {
		return "http://localhost:" + port;
	}
	@Test
	@Order(1)
	public void testGetAllRole() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/user_roles/rest/role",
				HttpMethod.GET, entity, String.class);
		assertNotNull(response.getBody());
	}

	@Test
	@Order(2)
	public void testGetRoleById(){
		Role role = restTemplate.getForObject(getRootUrl() + "/user_roles/rest/role/4", Role.class);
		assertNotNull(role);
	}

	@Test
	@Order(3)
	public void testCreateRole() throws RestClientException{
		Role role = new Role();
		role.setId(4);
		role.setName("Abi");
		role.setRole_code("ADM");
		headers.set("X_COM_PERSIST","true");
		HttpEntity<Role> request = new HttpEntity<>(role,headers);
		ResponseEntity<String> postResponse = this.restTemplate.postForEntity(getRootUrl() + "/user_roles/rest/role", request, String.class);

		assertNotNull(postResponse);
		assertNotNull(postResponse.getBody());
	}

	@Test
	@Order(4)
	public void testDeleteRole() {
		int id = 4;
		Role role= restTemplate.getForObject(getRootUrl() + "/user_roles/rest/role/" + id, Role.class);
		assertNotNull(role);
		restTemplate.delete(getRootUrl() + "/employees/" + id);
		try {
			role = restTemplate.getForObject(getRootUrl() + "/user_roles/rest/role/" + id, Role.class);
		} catch (final HttpClientErrorException e) {
			assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}
}
