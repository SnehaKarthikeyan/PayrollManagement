/*package com.ascentProject.rbac.repository;

import com.ascentProject.rbac.domain.MenuPrivilege;
import com.ascentProject.rbac.domain.Privilege;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PrivilegeRepository extends JpaRepository<MenuPrivilege,String> {
    @Query("Select  p from MenuPrivilege p where code=:code")
    MenuPrivilege findByCode (String code);
}*/

