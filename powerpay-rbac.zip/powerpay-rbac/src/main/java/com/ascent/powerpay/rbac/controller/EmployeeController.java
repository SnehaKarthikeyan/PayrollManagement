package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.domain.Employee;
import com.ascent.powerpay.rbac.repository.EmployeeCrudRepository;
import com.ascent.powerpay.rbac.repository.EmployeeHistoryRepository;
import com.ascent.powerpay.rbac.service.EmployeeService;
import com.ascent.powerpay.rbac.util.ObjectMapperUtil;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/manage/employee")
public class EmployeeController {

    private EmployeeService employeeService;
    private EmployeeCrudRepository repository;
    private EmployeeHistoryRepository historyRepository;

    @Autowired
    public EmployeeController(EmployeeService employeeService,
                              EmployeeCrudRepository repository,
                              EmployeeHistoryRepository historyRepository) {
        this.employeeService = employeeService;
        this.repository = repository;
        this.historyRepository = historyRepository;
    }

    @RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<?> list() {
        return new ResponseEntity<>(Lists.newLinkedList(repository.findAll()), HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<?> byEmployeeCode(@PathVariable("id") String id) {
        return new ResponseEntity<>(repository.findByCode(id), HttpStatus.OK);
    }

    @RequestMapping(value = "/history/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<?> history(@PathVariable("id") String id) {
        return new ResponseEntity<>(historyRepository.findByEmployeeId(id), HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<?> create(@RequestBody Map<String, Object> employeePayload) {
        String employeeId = (String) employeePayload.get("employeeId");
        String effectiveDate = (String) employeePayload.get("effective_date");
        Map<String, Object> properties = ObjectMapperUtil.convertToMap(employeePayload.get("configuration"));

        employeeService.save(new Employee(employeeId, properties, effectiveDate));
        return new ResponseEntity<>("{\"status\":\"OK\"}", HttpStatus.OK);
    }
}
