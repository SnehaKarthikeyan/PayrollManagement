package com.Ascentproject.report.service;

public interface ReportOptionService {
}
