package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.GraphType;
import java.util.List;

public interface GraphTypeService {
     List<GraphType> saveGraphType(List<GraphType> graphTypeList);
     List<GraphType> getGraphType();
}
