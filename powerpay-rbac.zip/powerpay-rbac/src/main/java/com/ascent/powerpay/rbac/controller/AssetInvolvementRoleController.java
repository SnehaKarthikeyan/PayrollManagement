package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.domain.AssetInvolvementRole;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.AssetInvolvementRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/assetinvolvementrole", "/manage/assetinvolvementrole"})
public class AssetInvolvementRoleController {

    @Autowired
    private AssetInvolvementRoleService assetInvolvementRoleService;

    @PostMapping("/managedentity/{managedEntityCode}/privilege/{privilegeCode}/permission/{permissionCode}/userrole/{userRoleCode}")
    public ResponseEntity<List<AssetInvolvementRole>> saveAssetInvolvementRole(@PathVariable (name="managedEntityCode") String managedEntityCode,
                                                                         @PathVariable (name="privilegeCode") String privilegeCode,
                                                                         @PathVariable (name="permissionCode") String permissionCode,
                                                                         @PathVariable (name="userRoleCode") String userRoleCode,
                                                                         @RequestBody AssetInvolvementRole assetInvolvementRole ) throws NotFoundException {
        ResponseEntity<List<AssetInvolvementRole>> responseEntity = null;
        List<AssetInvolvementRole> assetInvolvementRole1 = null;
        try {
            assetInvolvementRole1 = (List<AssetInvolvementRole>)assetInvolvementRoleService.saveAssetInvolvementRole(managedEntityCode,
                    privilegeCode, permissionCode, userRoleCode, assetInvolvementRole);
            if(assetInvolvementRole1 == null) {
                responseEntity= new ResponseEntity<List<AssetInvolvementRole>>((List<AssetInvolvementRole>)assetInvolvementRole, HttpStatus.BAD_REQUEST);
            } else {
                responseEntity = new ResponseEntity<List<AssetInvolvementRole>>(assetInvolvementRole1, HttpStatus.CREATED);
            }
        } catch (Exception exception) {
            log.debug("Unable to save Asset Involvement Role");
            responseEntity = new ResponseEntity<List<AssetInvolvementRole>>(assetInvolvementRole1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/privilege/{privilegeCode}/permission/{permissionCode}/userrole/{userRoleCode}/{assetInvolvementRoleId}")
    public ResponseEntity<?> getAssetInvolvementRoleById(@PathVariable("assetInvolvementRoleId")
                                                                    String assetInvolvementRoleId) throws NotFoundException {
        ResponseEntity<?> responseEntity=null;
        try {
            AssetInvolvementRole assetInvolvementRole= assetInvolvementRoleService.getAssetInvolvementRoleById(assetInvolvementRoleId);
            responseEntity= new ResponseEntity<AssetInvolvementRole>(assetInvolvementRole,HttpStatus.OK);
        } catch (Exception exception) {
            log.debug("Unable to get Asset Involvement Role");
            responseEntity = new ResponseEntity<String>("Unable to get Asset Involvement Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/privilege/{privilegeCode}/permission/{permissionCode}/userrole/{userRoleCode}/{assetInvolvementRoleCode}")
    public ResponseEntity<?> getAssetInvolvementRoleByCode(@RequestParam("assetInvolvementRoleCode")
                                                                 String assetInvolvementRoleCode) throws NotFoundException {
        if(assetInvolvementRoleCode == null)
            return getAllAssetInvolvementRole();
        ResponseEntity<?> responseEntity=null;
        try {
            List<AssetInvolvementRole> assetInvolvementRole= (List<AssetInvolvementRole>)assetInvolvementRoleService.getAssetInvolvementRoleByCode(assetInvolvementRoleCode);
            responseEntity= new ResponseEntity<List<AssetInvolvementRole>>(assetInvolvementRole,HttpStatus.OK);
        } catch (Exception exception) {
            log.debug("Unable to get Asset Involvement Role");
            responseEntity = new ResponseEntity<String>("Unable to get Asset Involvement Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    public ResponseEntity<?> getAllAssetInvolvementRole() throws NotFoundException {
        ResponseEntity<?> responseEntity=null;
        try {
            List<AssetInvolvementRole> assetInvolvementRoleList = assetInvolvementRoleService.getAllAssetInvolvementRole();
            responseEntity= new ResponseEntity<List<AssetInvolvementRole>>(assetInvolvementRoleList, HttpStatus.OK);
        } catch (Exception exception) {
            log.debug("Unable to get All Asset Involvement Role");
            responseEntity = new ResponseEntity<String>("Unable to get All Asset Involvement Role", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    @PutMapping("/managedentity/{managedEntityCode}/privilege/{privilegeCode}" +
            "/permission/{permissionCode}/userrole/{userRoleCode}" +
            "/assetinvolvementrole/{assetInvolvementRoleCode}")
    public ResponseEntity<List<AssetInvolvementRole>> updateAssetInvolvementRole( @PathVariable (name="managedEntityCode") String managedEntityCode,
                                                                            @PathVariable (name="privilegeCode") String privilegeCode,
                                                                            @PathVariable (name="permissionCode") String permissionCode,
                                                                            @PathVariable (name="userRoleCode") String userRoleCode,
                                                                            @PathVariable(name = "assetInvolvementRoleCode") String assetInvolvementRoleCode,
                                                                            @RequestBody AssetInvolvementRole assetInvolvementRole ) throws NotFoundException {
        ResponseEntity<List<AssetInvolvementRole>> responseEntity = null;
        List<AssetInvolvementRole> assetInvolvementRole1 = null;
        try {
            assetInvolvementRole1 = (List<AssetInvolvementRole>)assetInvolvementRoleService.updateAssetInvolvementRole(managedEntityCode,
                            privilegeCode, permissionCode, userRoleCode, assetInvolvementRoleCode, assetInvolvementRole);
                responseEntity = new ResponseEntity<List<AssetInvolvementRole>>(assetInvolvementRole1, HttpStatus.OK);
        } catch (Exception exception) {
            log.debug("Unable to save Asset Involvement Role");
            responseEntity = new ResponseEntity<List<AssetInvolvementRole>>(assetInvolvementRole1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{assetInvolvementRoleId}")
    public ResponseEntity<String> deleteAssetInvolvementRoleById(@PathVariable("assetInvolvementRoleId")
                                                                    String assetInvolvementRoleId) throws NotFoundException {
        ResponseEntity<String> responseEntity= null;
        try {
            assetInvolvementRoleService.deleteAssetInvolvementRoleById(assetInvolvementRoleId);
            responseEntity= new ResponseEntity<String> ("AssetInvolvementRole '"+assetInvolvementRoleId+"' deleted",HttpStatus.OK);
        } catch(Exception exception) {
            log.debug("Unable to delete Asset Involvement Role");
            responseEntity= new ResponseEntity<String>("Unable to delete Asset Involvement Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{assetInvolvementRoleCode}")
    public ResponseEntity<String> deleteAssetInvolvementRoleByCode(@RequestParam("assetInvolvementRoleCode")
                                                                           String assetInvolvementRoleCode) throws NotFoundException {
        ResponseEntity<String> responseEntity= null;
        try {
            assetInvolvementRoleService.deleteAssetInvolvementRoleByCode(assetInvolvementRoleCode);
            responseEntity= new ResponseEntity<String> ("Asset Involvement Role '"+assetInvolvementRoleCode+"' deleted",HttpStatus.OK);
        } catch(Exception exception) {
            log.debug("Unable to delete Asset Involvement Role");
            responseEntity= new ResponseEntity<String>("Unable to delete Asset Involvement Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
