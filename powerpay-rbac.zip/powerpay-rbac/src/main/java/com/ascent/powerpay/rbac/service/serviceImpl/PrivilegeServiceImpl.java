package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Privilege;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.repository.ManagedEntityRepository;
import com.ascent.powerpay.rbac.repository.PrivilegeRepository;
import com.ascent.powerpay.rbac.service.PrivilegeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class PrivilegeServiceImpl implements PrivilegeService
{

    @Autowired
    private PrivilegeRepository privilegeRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public Privilege savePrivilege(String managedEntity_Code, Privilege privilege) throws NotFoundException {
        boolean exists = false;
        if(privilege.getId() != null)
        {
            exists = privilegeRepository.existsById(privilege.getId());
        }
        if(exists)
        {
            return null;
        }
        ManagedEntity managedEntity = getManagedEntity(managedEntity_Code);
        privilege.setManagedEntityId(managedEntity.getId());
        privilege.setActive(true);
        Privilege privilege1 = privilegeRepository.save(privilege);
        return privilege1;
    }

    private ManagedEntity getManagedEntity(String managedEntityCode) throws NotFoundException {
        ManagedEntity me = managedEntityRepository.findByCode(managedEntityCode);
        if(me == null) throw new NotFoundException(managedEntityCode + " Managed Entity Not Found");
        return me;
    }

    public Privilege getPrivilegeById(String managedEntityCode, String privilegeId) throws NotFoundException {
        String managedEntityId = null;
        Privilege privilege = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        if(me != null) {
            managedEntityId = me.getId();
        privilege = privilegeRepository.findByManagedEntityIdAndId(managedEntityId, privilegeId);
        } else {
            log.info("Privilege object not found for {} & {}", managedEntityCode, privilegeId);
        }
        return privilege;
    }

    public Privilege getPrivilegeByCode(String managedEntityCode, String privilegeCode) throws NotFoundException {
        String managedEntityId = null;
        Privilege privilege = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        if(me != null) {
            managedEntityId = me.getId();
        privilege = privilegeRepository.findByManagedEntityIdAndCode(managedEntityId,privilegeCode);
        } else {
            log.info("Privilege object not found for {} & {}", managedEntityCode, privilegeCode);
        }
        return privilege;
    }

    public List<Privilege> getAllPrivilege(String managedEntityCode) throws NotFoundException {
        String managedEntityId = null;
        List<Privilege> list = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        if(me != null) {
            managedEntityId = me.getId();
            list = privilegeRepository.findAllByManagedEntityId(managedEntityId);
        } else {
            log.info("Managed Entity object not found for {}", managedEntityCode);
        }
        return list;
    }

    public Privilege updatePrivilege(String managedEntityCode, String privilege_Code,
                                         Privilege privilege) throws NotFoundException {
        ManagedEntity managedEntity = getManagedEntity(managedEntityCode);
        Privilege privilege1 = privilegeRepository.findByManagedEntityIdAndCode(managedEntity.getId(), privilege_Code);
        privilege1.setCode(privilege.getCode());
        privilege1.setAction(privilege.getAction());
        privilege1.setFunction(privilege.getFunction());
        privilege1.setActive(privilege.isActive());
        return privilegeRepository.save(privilege1);
    }

    public void deletePrivilegeById(String managedEntityCode, String privilegeId) throws NotFoundException
    {
        Privilege privilege = getPrivilegeById(managedEntityCode, privilegeId);
        privilegeRepository.delete(privilege);
    }

    public void deletePrivilegeByCode(String managedEntityCode, String privilegeCode) throws NotFoundException {
        Privilege privilege = getPrivilegeByCode(managedEntityCode,privilegeCode);
        privilege.setActive(false);
        privilegeRepository.save(privilege);
    }
}
