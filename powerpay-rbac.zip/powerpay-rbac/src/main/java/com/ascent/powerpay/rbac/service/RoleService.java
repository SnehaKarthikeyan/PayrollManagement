package com.ascent.powerpay.rbac.service;

import com.ascent.powerpay.rbac.domain.Role;
import com.ascent.powerpay.rbac.exception.NotFoundException;

import java.util.List;

public interface RoleService
{

    Role saveRole(String manageEntity_Code, Role role) throws NotFoundException;

    Role getRoleById(String managedEntityCode,String roleId) throws NotFoundException;

    Role getRoleByCode(String managedEntityCode,String roleCode) throws NotFoundException;

    List<Role> getAllRole(String managedEntityCode) throws NotFoundException;

    Role updateRole(String managedEntitycode, String rolecode, Role role) throws NotFoundException;

    void deleteRoleById(String managedEntityCode,String roleId) throws NotFoundException;

    void deleteRoleByCode(String managedEntityCode,String roleCode) throws NotFoundException;

}
