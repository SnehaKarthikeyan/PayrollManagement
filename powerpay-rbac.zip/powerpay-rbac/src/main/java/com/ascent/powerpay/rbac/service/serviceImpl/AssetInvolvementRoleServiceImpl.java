package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.rbac.domain.*;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.repository.*;
import com.ascent.powerpay.rbac.service.AssetInvolvementRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetInvolvementRoleServiceImpl implements AssetInvolvementRoleService
{

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private AssetInvolvementRoleRepository assetInvolvementRoleRepository;

    @Autowired
    private PrivilegeRepository privilegeRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public AssetInvolvementRole saveAssetInvolvementRole(String managedEntity_Code, String privilege_Code,
                                                         String permission_Code, String userRole_Code,
                                                         AssetInvolvementRole assetInvolvementRole)
    {
        boolean exists = false;
        if(assetInvolvementRole.getId() != null)
        {
            exists = assetInvolvementRoleRepository.existsById(assetInvolvementRole.getId());
        }
        if(exists)
        {
            return null;
        }
        ManagedEntity managedEntity = managedEntityRepository.findByCode(managedEntity_Code);
        Privilege privilege = privilegeRepository.findByCode(privilege_Code);
        Permission permission = permissionRepository.findByCode(permission_Code);
        UserRole userRole = userRoleRepository.findByCode(userRole_Code);
        assetInvolvementRole.setManagedEntity(managedEntity);
        assetInvolvementRole.setPrivilege(privilege);
        assetInvolvementRole.setPermission(permission);
        assetInvolvementRole.setUserRole(userRole);
        assetInvolvementRole.setActive(true);
        assetInvolvementRoleRepository.save(assetInvolvementRole);
        return assetInvolvementRole;
    }

    public AssetInvolvementRole getAssetInvolvementRoleById(String assetInvolvementRole_Id) throws NotFoundException
    {
        AssetInvolvementRole assetInvolvementRole;
        assetInvolvementRole = assetInvolvementRoleRepository.findById(assetInvolvementRole_Id).get();
        return assetInvolvementRole;
    }

    public AssetInvolvementRole getAssetInvolvementRoleByCode(String assetInvolvementRole_Code) throws NotFoundException
    {
        AssetInvolvementRole assetInvolvementRole;
        assetInvolvementRole = assetInvolvementRoleRepository.findByCode(assetInvolvementRole_Code);
        return assetInvolvementRole;
    }

    public List<AssetInvolvementRole> getAllAssetInvolvementRole()
    {
        List<AssetInvolvementRole> assetInvolvementRoles = assetInvolvementRoleRepository.findAll();
        return assetInvolvementRoles;
    }

    public AssetInvolvementRole updateAssetInvolvementRole(String managedEntity_Code, String privilege_Code,
                                                           String permission_Code, String userRole_Code,
                                                           String assetInvolvementRole_Code,
                                                           AssetInvolvementRole assetInvolvementRole)
    {
        AssetInvolvementRole assetInvolvementRole1 = assetInvolvementRoleRepository.findByCode(assetInvolvementRole_Code);
        ManagedEntity managedEntity = managedEntityRepository.findByCode(managedEntity_Code);
        Privilege privilege = privilegeRepository.findByCode(privilege_Code);
        Permission permission = permissionRepository.findByCode(permission_Code);
        UserRole userRole = userRoleRepository.findByCode(userRole_Code);
        assetInvolvementRole1.setManagedEntity(managedEntity);
        assetInvolvementRole1.setPrivilege(privilege);
        assetInvolvementRole1.setPermission(permission);
        assetInvolvementRole1.setUserRole(userRole);
        if(assetInvolvementRole.getCode()!=null)
        {
            assetInvolvementRole1.setCode(assetInvolvementRole.getCode());
        }
        assetInvolvementRole1.setActive(true);
        assetInvolvementRoleRepository.save(assetInvolvementRole1);
        return assetInvolvementRole1;
    }

    @Override
    public void deleteAssetInvolvementRoleById(String assetInvolvementRole_Id) throws NotFoundException
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRoleById(assetInvolvementRole_Id);
        assetInvolvementRoleRepository.delete(assetInvolvementRole);
    }

    @Override
    public void deleteAssetInvolvementRoleByCode(String assetInvolvementRole_Code) throws NotFoundException
    {
        AssetInvolvementRole assetInvolvementRole = getAssetInvolvementRoleByCode(assetInvolvementRole_Code);
        assetInvolvementRole.setActive(false);
        assetInvolvementRoleRepository.save(assetInvolvementRole);
    }

}
