package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.GraphType;
import com.Ascentproject.report.repository.GraphTypeRepository;
import com.Ascentproject.report.service.GraphTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GraphTypeServiceImpl implements GraphTypeService {
    @Autowired
    public GraphTypeRepository graphTypeRepository;

    public List<GraphType> saveGraphType(List<GraphType> graphTypeList)
    {
        return graphTypeRepository.saveAll(graphTypeList);
    }
    public  List<GraphType> getGraphType()
    {
        List<GraphType> graphTypeList= graphTypeRepository.findAll().stream()
                .collect(Collectors.toList());
        return graphTypeList;
    }
}
