package com.ascent.powerpay.rbac.integrationTest;

import com.ascent.powerpay.kernel.tenant.TenantInfo;
import com.ascent.powerpay.rbac.AbstractRestDocumentationTestCase;
import com.ascent.powerpay.rbac.TestUtil;
import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.domain.InvolvementIdentification;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import javax.validation.constraints.NotNull;

import java.io.IOException;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
class InvolvementIdentificationTests extends AbstractRestDocumentationTestCase {

    @Autowired
    TestUtil testUtil;

    @BeforeEach
    public void createManagedEntity() throws Exception
    {
        ManagedEntity managedEntity = testUtil.getManagedEntity("entityCode1",
                "entityType1", "entityName1");
        managedEntity = testUtil.addManagedEntityAPI(this.mockMvc, managedEntity);
        assertNotNull(managedEntity);
        assertEquals("entityCode1", managedEntity.getCode());
        assertEquals("entityType1", managedEntity.getType());
        assertEquals("entityName1", managedEntity.getName());
    }

    @BeforeEach
    public void createIndividualParty() throws Exception
    {
        IndividualParty individualParty = testUtil.getIndividualParty("userCode1","userName1");
        individualParty = testUtil.addIndividualPartyAPI(this.mockMvc,individualParty);
        assertNotNull(individualParty);
        assertEquals("userCode1", individualParty.getCode());
        assertEquals("userName1", individualParty.getName());
    }

    @NotNull
    private InvolvementIdentification getInvolvementIdentification(String code, String name)  {
        InvolvementIdentification involvementIdentification = new InvolvementIdentification();
        involvementIdentification.setCode(code);
        involvementIdentification.setName(name);
        return involvementIdentification;
    }

    private InvolvementIdentification addInvolvementIdentificationAPI(InvolvementIdentification me) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/involvementidentification/managedentity/entityCode1/user/userCode1")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        InvolvementIdentification involvementIdentification = getInvolvementIdentification(mvcResult);
        return involvementIdentification;
    }

    private InvolvementIdentification getInvolvementIdentification(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), InvolvementIdentification.class);
    }

    @Test
    public void testSaveInvolvementIdentification() throws Exception
    {
        InvolvementIdentification involvementIdentification= getInvolvementIdentification(
                "code1","name1");
        addInvolvementIdentificationAPI(involvementIdentification);
        assertNotNull(involvementIdentification);
        assertEquals("code1", involvementIdentification.getCode());
        assertEquals("name1", involvementIdentification.getName());
    }

    @Test
    public void testGetInvolvementIdentificationById() throws Exception {
        InvolvementIdentification involvementIdentification = getInvolvementIdentification("code2","name2");
        involvementIdentification = addInvolvementIdentificationAPI(involvementIdentification);
        String id = involvementIdentification.getId();

        involvementIdentification = getInvolvementIdentificationById(id);
        assertNotNull(involvementIdentification);
        assertEquals("code2", involvementIdentification.getCode());
        assertEquals("name2", involvementIdentification.getName());
    }

    private InvolvementIdentification getInvolvementIdentificationById(String id) throws Exception {
        InvolvementIdentification involvementIdentification;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/involvementidentification/managedentity/entityCode1/user/userCode1/involvementidentification/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        involvementIdentification = getInvolvementIdentification(mvcResult);
        return involvementIdentification;
    }

    @Test
    public void testGetInvolvementIdentificationByCode() throws Exception {
        InvolvementIdentification involvementIdentification = getInvolvementIdentification("code3", "name3");
        involvementIdentification = addInvolvementIdentificationAPI(involvementIdentification);
        String code = involvementIdentification.getCode();

        involvementIdentification = getInvolvementIdentificationByCode(code);
        assertNotNull(involvementIdentification);
        assertEquals("code3", involvementIdentification.getCode());
        assertEquals("name3", involvementIdentification.getName());
    }

    private InvolvementIdentification getInvolvementIdentificationByCode(String code) throws Exception {
        InvolvementIdentification involvementIdentification;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/involvementidentification/managedentity/entityCode1/user/userCode1/involvementidentification/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("involvementIdentificationCode", code)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        InvolvementIdentification[]  involvementIdentificationArray = getInvolvementIdentificationArray(mvcResult);
        assertEquals(1, involvementIdentificationArray.length);
        return involvementIdentificationArray[0];
    }

    private InvolvementIdentification[] getInvolvementIdentificationArray(MvcResult mvcResult) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), InvolvementIdentification[].class);
    }

    @Test
    public void testGetAllInvolvementIdentification() throws Exception {
        InvolvementIdentification involvementIdentification = getInvolvementIdentification("code4", "name4");
        involvementIdentification = addInvolvementIdentificationAPI(involvementIdentification);

        assertEquals("code4", involvementIdentification.getCode());
        assertEquals("name4", involvementIdentification.getName());

        involvementIdentification = getInvolvementIdentification("code5", "name5");
        involvementIdentification = addInvolvementIdentificationAPI(involvementIdentification);

        InvolvementIdentification[] result = getAllInvolvementIdentification();
        assertNotNull(result);
        assertTrue(result.length == 2);
    }

    private InvolvementIdentification[] getAllInvolvementIdentification() throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/involvementidentification/managedentity/entityCode1/user/userCode1/involvementidentification/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        InvolvementIdentification[] involvementIdentificationResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), InvolvementIdentification[].class);
        return involvementIdentificationResult;
    }

    @Test
    public void testUpdateInvolvementIdentification() throws Exception
    {
        InvolvementIdentification involvementIdentification = getInvolvementIdentification("code6", "name6");
        involvementIdentification = addInvolvementIdentificationAPI(involvementIdentification);
        involvementIdentification.setName("updatedInvolvementIdentificationName");
        String code = involvementIdentification.getCode();

        updateInvolvementIdentificationAPI(involvementIdentification);
        involvementIdentification = getInvolvementIdentificationByCode(code);


        assertNotNull(involvementIdentification);
        assertEquals("code6", involvementIdentification.getCode());
        assertEquals("updatedInvolvementIdentificationName", involvementIdentification.getName());
    }

    private InvolvementIdentification updateInvolvementIdentificationAPI(InvolvementIdentification me) throws Exception {

        Gson gson = new Gson();
        String meStr = gson.toJson(me);

        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/involvementidentification/managedentity/entityCode1/user/userCode1/involvementidentification/" + me.getCode())
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        InvolvementIdentification involvementIdentificationResult = getInvolvementIdentification(mvcResult);
        return involvementIdentificationResult;

    }

    @Test
    public void testDeleteInvolvementIdentificationById() throws Exception {
        InvolvementIdentification involvementIdentification = getInvolvementIdentification("code7", "name7");
        involvementIdentification = addInvolvementIdentificationAPI(involvementIdentification);
        String id = involvementIdentification.getId();
        delete(id);
        try {
            this.mockMvc.perform(RestDocumentationRequestBuilders
                            .get("/manage/involvementidentification/managedentity/entityCode1/user/userCode1/involvementidentification/" + id)
                            .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                            .accept(MediaType.APPLICATION_JSON))
                    .andExpect(status().isBadRequest());

        } catch (final Exception e) {
            fail("object status should have been saved.");
        }
    }

    @Test
    public void testDeleteInvolvementIdentificationByCode() throws Exception {
        InvolvementIdentification involvementIdentification = getInvolvementIdentification("code8", "name8");
        involvementIdentification = addInvolvementIdentificationAPI(involvementIdentification);
        String code = involvementIdentification.getCode();
        markForDelete(code);
        try
        {
            InvolvementIdentification involvementIdentification1 = getInvolvementIdentificationByCode(code);
            assertFalse(involvementIdentification1.isActive());
        }
        catch (final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private void markForDelete(String code) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/involvementidentification/managedentity/entityCode1/user/userCode1/involvementidentification/")
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .param("involvementIdentificationCode", code)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

    private void delete(String id) throws Exception {
        this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/involvementidentification/managedentity/entityCode1/user/userCode1/involvementidentification/internal/" + id)
                        .header(TenantInfo.TENANT_ID_KEY, TEST_TENANT)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk());
    }

}
