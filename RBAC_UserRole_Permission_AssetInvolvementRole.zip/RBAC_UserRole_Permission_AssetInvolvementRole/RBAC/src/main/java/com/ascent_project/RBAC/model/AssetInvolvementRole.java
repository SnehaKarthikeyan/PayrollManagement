package com.ascent_project.RBAC.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="AssetInvolvementRole")
public class AssetInvolvementRole {
    @Id
    @Column(name = "ID")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "managedEntity_id")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private ManagedEntity managedEntity;

    @ManyToOne
    @JoinColumn(name = "permission_id")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private Permission permission;

    @ManyToOne
    @JoinColumn(name = "privilege_id")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private Privilege privilege;

    @ManyToOne
    @JoinColumn(name = "userRole_id")
    @OnDelete(action= OnDeleteAction.CASCADE)
    private UserRole userRole;
}
