package com.example.datasource.controller;

import com.example.datasource.domain.DatasourceParameter;
import com.example.datasource.service.DatasourceParameterService;
import com.example.datasource.service.DatasourceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/datasourceparameter","/manage/datasourceparameter"})
public class DatasourceParameterController {
    @Autowired
    private DatasourceParameterService datasourceParameterService;

    @Autowired
    private DatasourceService datasourceService;

    @PostMapping("/{datasourceCode}")
    public ResponseEntity<?> saveDatasourceParameter(@PathVariable("datasourceCode") String datasourceCode, @RequestBody List<DatasourceParameter> datasourceParameter) {
        ResponseEntity<?> responseEntity = null;
        try {
            for(DatasourceParameter datasourceParameter1: datasourceParameter) {
                datasourceParameterService.saveDatasourceParameter(datasourceCode, datasourceParameter1);
            }
            responseEntity = new ResponseEntity<List<DatasourceParameter>>(datasourceParameter, HttpStatus.CREATED);
        } catch(Exception e) {
            log.debug("Unable to save Datasource Parameter");
            responseEntity = new ResponseEntity<List<DatasourceParameter>>(datasourceParameter, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{datasourceCode}/search")
    public ResponseEntity<?> getDatasourceParameterById(@PathVariable("datasourceCode") String datasourceCode,
                                                        @RequestParam("id") long datasourceParameterId) {
        ResponseEntity<?> responseEntity= null;
        try {
            DatasourceParameter datasourceParameter = datasourceParameterService.getDatasourceParameterById(datasourceCode, datasourceParameterId);
            responseEntity = new ResponseEntity<DatasourceParameter>(datasourceParameter,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource Parameter");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource Parameter", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{datasourceCode}")
    public ResponseEntity<?> getAllDatasourceParameter(@PathVariable("datasourceCode") String datasourceCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            List<Object> datasourceParameter = datasourceParameterService.getAllDatasourceParameter(datasourceCode);
            responseEntity = new ResponseEntity<List<Object>>(datasourceParameter,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource Parameter");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource Parameter", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/{datasourceCode}/{datasourceParameterId}")
    public ResponseEntity<?> updateDatasourceParameter(@PathVariable("datasourceCode") String datasourceCode,
                                                       @PathVariable("datasourceParameterId") long datasourceParameterId,
                                                       @RequestBody DatasourceParameter datasourceParameter) {
        ResponseEntity<?> responseEntity = null;
        try {
            DatasourceParameter datasourceParameter1 = datasourceParameterService.updateDatasourceParameter(datasourceCode, datasourceParameterId, datasourceParameter);
            responseEntity = new ResponseEntity<DatasourceParameter>(datasourceParameter1, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to update Datasource Parameter");
            responseEntity = new ResponseEntity<String>("Unable to update Datasource Parameter", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{datasourceCode}")
    public ResponseEntity<?> deleteDatasourceParameterById(@PathVariable("datasourceCode") String datasourceCode, @RequestParam("id") long datasourceParameterId) {
        ResponseEntity<?> responseEntity= null;
        try {
            datasourceParameterService.deleteDatasourceParameterById(datasourceCode, datasourceParameterId);
            responseEntity = new ResponseEntity<String> ("Datasource Parameter '"+datasourceParameterId+"' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Datasource Parameter");
            responseEntity = new ResponseEntity<String>("Unable to delete Datasource Parameter", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
