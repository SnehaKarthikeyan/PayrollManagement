package com.example.datasource.service.impl;

import com.example.datasource.domain.Datasource;
import com.example.datasource.domain.DatasourceOptions;
import com.example.datasource.exception.NotFoundException;
import com.example.datasource.repository.DatasourceOptionsRepository;
import com.example.datasource.repository.DatasourceRepository;
import com.example.datasource.service.DatasourceOptionsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class DatasourceOptionsServiceImpl implements DatasourceOptionsService {
    @Autowired
    private DatasourceOptionsRepository datasourceOptionsRepository;

    @Autowired
    private DatasourceRepository datasourceRepository;

    @Override
    public DatasourceOptions saveDatasourceOptions(String datasourceCode, DatasourceOptions datasourceOptions) {
        boolean exists = false;
        if(datasourceOptions.getId() != 0) {
            exists = datasourceOptionsRepository.existsById(datasourceOptions.getId());
        }
        if(exists) {
            return null;
        }
        long datasourceId;
        DatasourceOptions datasourceOptions1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            datasourceOptions.setActive(true);
            datasourceOptions.setDatasourceId(datasourceId);
            datasourceOptions1 = datasourceOptionsRepository.save(datasourceOptions);
        }
        return datasourceOptions1;
    }

    @Override
    public DatasourceOptions getDatasourceOptionsById(String datasourceCode, long datasourceOptionsId) {
        long datasourceId;
        DatasourceOptions datasourceOptions = null;
        DatasourceOptions datasourceOptions1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            datasourceOptions = datasourceOptionsRepository.findByDatasourceIdAndId(datasourceId, datasourceOptionsId);
            if(datasourceOptions.isActive()) { datasourceOptions1 = datasourceOptions; }
        } else {
            log.info("DatasourceOptions object not found for {} & {}", datasourceCode, datasourceOptionsId);
        }
        return datasourceOptions1;
    }

    @Override
    public List<Object> getAllDatasourceOptions(String datasourceCode) {
        long datasourceId;
        List<DatasourceOptions> list = null;
        List<Object> result = new ArrayList<Object>();
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceId = datasource.getId();
            list = datasourceOptionsRepository.findByDatasourceId(datasourceId);
            for(DatasourceOptions datasourceOptions1: list) {
                if(datasourceOptions1.isActive()) { result.add(datasourceOptions1); }
            }
        } else {
            log.info("DatasourceOptions object not found for {}", datasourceCode);
        }
        return result;
    }

    @Override
    public DatasourceOptions updateDatasourceOptions(String datasourceCode, long datasourceOptionsId, DatasourceOptions datasourceOptions) {
        DatasourceOptions datasourceOptions1 = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceOptions1 = getDatasourceOptionsById(datasourceCode, datasourceOptionsId);
            datasourceOptions1.setActive(true);
            BeanUtils.copyProperties(datasourceOptions, datasourceOptions1);
            datasourceOptionsRepository.save(datasourceOptions1);
        } else {
            log.info("DatasourceOptions object not found for {}", datasourceCode);
        }
        return datasourceOptions1;
    }

    @Override
    public void deleteDatasourceOptionsById(String datasourceCode, long datasourceOptionsId) {
        DatasourceOptions datasourceOptions = null;
        Datasource datasource = datasourceRepository.findByCode(datasourceCode);
        if(datasource == null || !datasource.isActive()) throw new NotFoundException(datasourceCode + " datasource is Not Found");
        else if(datasource != null) {
            datasourceOptions = getDatasourceOptionsById(datasourceCode, datasourceOptionsId);
            datasourceOptions.setActive(false);
            datasourceOptionsRepository.save(datasourceOptions);
        } else {
            log.info("DatasourceOptions object not found for {}", datasourceCode);
        }
    }
}
