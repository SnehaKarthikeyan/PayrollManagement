package com.ascent.powerpay.rbac.controller;

import com.ascent.powerpay.rbac.BulkHelper.BulkHelperUserRole;
import com.ascent.powerpay.rbac.domain.Role;
import com.ascent.powerpay.rbac.domain.UserRole;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.service.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;


@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/userrole", "/manage/userrole"})
public class UserRoleController {

    @Autowired
    private UserRoleService userRoleService;

    @PostMapping("/managedentity/{managedEntityCode}/role/{roleCode}/user/{userCode}")
    public ResponseEntity<UserRole> saveIndividualUserRole(@PathVariable (name="managedEntityCode") String managedEntityCode,
                                                           @PathVariable (name="roleCode") String roleCode,
                                                           @PathVariable (name="userCode") String userCode,
                                                           @RequestBody UserRole userRole) throws NotFoundException {
        ResponseEntity<UserRole> responseEntity = null;
        UserRole userRole1 = null;
        try {
            userRole1 = userRoleService.saveUserRole(managedEntityCode, roleCode, userCode, userRole);
            if(userRole1 == null) {
                responseEntity = new ResponseEntity<UserRole>(userRole, HttpStatus.BAD_REQUEST);
            }else {
                responseEntity = new ResponseEntity<UserRole>(userRole1, HttpStatus.CREATED);
            }
        }catch (Exception exception) {
            log.error("Unable to save User Role", exception);
            responseEntity = new ResponseEntity<UserRole>(userRole1, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PostMapping("/role/user")
    public ResponseEntity<String> BulkUploadFile(@RequestParam("file") MultipartFile file) throws NotFoundException {
        String message = "";
        if (BulkHelperUserRole.hasCSVFormat(file)) {
            try {
                userRoleService.saveBulkUpload(file);
                message = "Uploaded the file successfully: " + file.getOriginalFilename();
                return ResponseEntity.status(HttpStatus.OK).body(message);
            }catch (Exception exception) {
                log.error("Unable to upload the file", exception);
                message = "Could not upload the file: " + file.getOriginalFilename() + "!";
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
            }
        }
        message = "Please upload a csv file!";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

    @GetMapping("/managedentity/{managedEntityCode}/role/{roleCode}/user/{userCode}/userrole/{userRoleId}")
    public ResponseEntity<?> getUserRoleById(@PathVariable (name="managedEntityCode") String managedEntityCode,
                                             @PathVariable (name="roleCode") String roleCode,
                                             @PathVariable (name="userCode") String userCode,
                                             @PathVariable("userRoleId") String userRoleId) {
        ResponseEntity<?> responseEntity=null;
        try {
            UserRole userRole= userRoleService.getUserRoleById(managedEntityCode,roleCode,userCode,userRoleId);
            if(userRole == null)
                responseEntity= new ResponseEntity(HttpStatus.BAD_REQUEST);
            else
            responseEntity= new ResponseEntity<UserRole>(userRole,HttpStatus.OK);
        }catch (Exception exception) {
            log.error("Unable to get User Role", exception);
            responseEntity = new ResponseEntity<String>("Unable to get User Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/managedentity/{managedEntityCode}/role/{roleCode}/user/{userCode}/userrole")
    public ResponseEntity<?> getAllUserRole(@PathVariable (name="managedEntityCode") String managedEntityCode,
                                            @PathVariable (name="roleCode") String roleCode,
                                            @PathVariable (name="userCode") String userCode,
                                            @RequestParam(required = false) String userRoleCode) {
        ResponseEntity<?> responseEntity=null;
        if(userRoleCode == null || userRoleCode.length() == 0)
            responseEntity = getAllUserRoles(managedEntityCode, roleCode, userCode);
        else
            responseEntity = getUserRoleByCode(managedEntityCode,roleCode, userCode, userRoleCode);

        return responseEntity;
    }

    @NotNull
    private ResponseEntity<?> getAllUserRoles(String managedEntityCode, String roleCode, String userCode) {
        ResponseEntity<?> responseEntity;
        try {
            List<UserRole> userRoleList= userRoleService.getAllUserRole(managedEntityCode,roleCode,userCode);
            responseEntity= new ResponseEntity<List<UserRole>>(userRoleList,HttpStatus.OK);
        }catch (Exception exception) {
            log.error("Unable to get All User Role", exception);
            responseEntity = new ResponseEntity<String>("Unable to get All Users", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    public ResponseEntity<?> getUserRoleByCode(String managedEntityCode,String roleCode, String userCode,
                                                @RequestParam(required = false) String userRoleCode) {
        ResponseEntity<?> responseEntity=null;
        try {
            UserRole userRole= userRoleService.getUserRoleByCode(managedEntityCode,roleCode,userCode,userRoleCode);
            List<UserRole> userRoles= new ArrayList<>();
            if(userRole != null)
                userRoles.add(userRole);
            responseEntity= new ResponseEntity<>(userRoles,HttpStatus.OK);
        }catch (Exception exception) {
            log.error("Unable to get User Role", exception);
            responseEntity = new ResponseEntity<String>("Unable to get User Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @PutMapping("/managedentity/{managedEntityCode}/role/{roleCode}/user/{userCode}/userrole/{userRoleCode}")
    public ResponseEntity<?> updateUserRole(@PathVariable (name = "managedEntityCode") String managedEntityCode,
                                            @PathVariable (name = "roleCode") String roleCode,
                                            @PathVariable (name = "userCode") String userCode,
                                            @PathVariable (name = "userRoleCode") String userRoleCode,
                                            @RequestBody UserRole userRole) throws NotFoundException {
        ResponseEntity<?> responseEntity = null;
        try {
            UserRole userRole1 = userRoleService.updateUserRole(managedEntityCode, roleCode, userCode, userRoleCode, userRole);
            responseEntity= new ResponseEntity<UserRole>(userRole1,HttpStatus.OK);
        }catch (Exception exception) {
            log.error("Unable to find User Role", exception);
            responseEntity = new ResponseEntity<String>("Unable to find User Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/role/{roleCode}/user/{userCode}/userrole/internal/{userRoleId}")
    public ResponseEntity<String> deleteUserRoleById(@PathVariable (name="managedEntityCode") String managedEntityCode,
                                                     @PathVariable (name="roleCode") String roleCode,
                                                     @PathVariable (name="userCode") String userCode,
                                                     @PathVariable (name="userRoleId") String userRoleId) {
        ResponseEntity<String> responseEntity= null;
        try {
            userRoleService.deleteUserRoleById(managedEntityCode,roleCode,userCode,userRoleId);
            responseEntity= new ResponseEntity<String> ("User Role '"+userRoleId+"' deleted",HttpStatus.OK);
        }catch (Exception exception) {
            log.error("Unable to delete User Role", exception);
            responseEntity= new ResponseEntity<String>("Unable to delete User Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/managedentity/{managedEntityCode}/role/{roleCode}/user/{userCode}/userrole")
    public ResponseEntity<String> deleteUserRoleByCode(@PathVariable (name="managedEntityCode") String managedEntityCode,
                                                       @PathVariable (name="roleCode") String roleCode,
                                                       @PathVariable (name="userCode") String userCode,
                                                       @RequestParam(required = false) String userRoleCode) {
        ResponseEntity<String> responseEntity= null;
        try {
            userRoleService.deleteUserRoleByCode(managedEntityCode,roleCode,userCode,userRoleCode);
            responseEntity= new ResponseEntity<String> ("User Role '"+userRoleCode+"' deleted",HttpStatus.OK);
        }catch (Exception exception) {
            log.error("Unable to delete User Role", exception);
            responseEntity= new ResponseEntity<String>("Unable to delete User Role", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

}
