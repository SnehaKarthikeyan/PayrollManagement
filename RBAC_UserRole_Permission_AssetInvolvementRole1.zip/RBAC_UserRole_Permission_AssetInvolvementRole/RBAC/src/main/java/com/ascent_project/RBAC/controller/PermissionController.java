package com.ascent_project.RBAC.controller;

import com.ascent_project.RBAC.BulkHelper.BulkHelperUserRole;
import com.ascent_project.RBAC.model.Permission;
import com.ascent_project.RBAC.service.PermissionServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@RestController
@RequestMapping("/managedEntity")
public class PermissionController {
    @Autowired
    private PermissionServiceImpl permissionService;

    @PostMapping("/{managedEntity_id}/permission")
    public ResponseEntity<String> saveIndividualPermission(@PathVariable (name="managedEntity_id") Long managedEntity_id,@RequestBody Permission permission){
        ResponseEntity<String> responseEntity = null;
        try{
            Long id = permissionService.saveIndividualPermission(managedEntity_id, permission);

            responseEntity= new ResponseEntity<String>(
                    "Permission'"+id+"' created",HttpStatus.CREATED); //201-created}

        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Permission",
                    HttpStatus.INTERNAL_SERVER_ERROR); //500-Internal Server Error
        }
        return responseEntity;
    }

    @GetMapping("/{managedEntity_id}/permission")
    public ResponseEntity<?> getAllPermissions(@PathVariable("managedEntity_id") Long managedEntity_id) {
        ResponseEntity<?> responseEntity=null;
        try {
            List<Permission> permissionList= permissionService.getAllPermissions(managedEntity_id);
            responseEntity= new ResponseEntity<List<Permission>>(permissionList,HttpStatus.OK);
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get Users",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }

    @GetMapping("/{managedEntity_id}/permission/{permission_id}")
    public ResponseEntity<?> getOnePermission(@PathVariable("managedEntity_id") Long managedEntity_id, @PathVariable("permission_id") Long permission_id) {
        ResponseEntity<?> responseEntity=null;
        try {
            Permission permission= permissionService.getOnePermission(managedEntity_id,permission_id);
            responseEntity= new ResponseEntity<Permission>
                    (permission,HttpStatus.OK);
        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to get User Role",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
    @DeleteMapping("/{managedEntity_id}/permission/{permission_id}")
    public ResponseEntity<String> deleteOnePermission(@PathVariable (name="managedEntity_id") Long managedEntity_id, @PathVariable (name="permission_id") Long permission_id){

        ResponseEntity<String> responseEntity= null;
        try {
            permissionService.deleteOnePermission(managedEntity_id,permission_id);
            responseEntity= new ResponseEntity<String> (
                    "Permission having permission_id '"+permission_id+"' deleted",HttpStatus.OK);

        }
        catch (PermissionNotFoundException exception) {
         throw exception;
         }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Permission", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }


    @PostMapping("/managedEntity/permission")
    public ResponseEntity<String> BulkUploadFile(@RequestParam("file") MultipartFile file) {
        String message = "";

        if (BulkHelperUserRole.hasCSVFormat(file)) {
            try {
                permissionService.saveBulkUpload(file);
                message = "Uploaded the file successfully: " + file.getOriginalFilename();
                return ResponseEntity.status(HttpStatus.OK).body(message);
            } catch (Exception exception) {
                exception.printStackTrace();
                message = "Could not upload the file: " + file.getOriginalFilename() + "!";
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
            }
        }

        message = "Please upload a csv file!";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

}
