package com.Ascentproject.report.controller;


import com.Ascentproject.report.domain.ReportDataSource;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.ReportDataSourceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/reportdatasource", "/manage/reportdatasource"})

public class ReportDataSourceController {
    @Autowired
    private ReportDataSourceService reportDataSourceService;

    @CrossOrigin
    @PostMapping("/reportId/{reportId}")
    public ResponseEntity<?> saveReportDataSource(@PathVariable int reportId,@RequestBody List<ReportDataSource> reportDataSourceList){
        ResponseEntity<?> responseEntity = null;
        try{
            List<ReportDataSource> reportDataSourceList1= reportDataSourceService.saveReportDataSource(reportId,reportDataSourceList);
            if(reportDataSourceList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save Report Data Source ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<ReportDataSource>>(
                    reportDataSourceList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Report Data Source ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("reportId/{reportId}")
    public ResponseEntity<?> updateOrCopyById(@RequestBody List<ReportDataSource> reportDataSourceList , @PathVariable int reportId) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            int reportId1= reportDataSourceService.findByReportId(reportId);
            if(reportId1==0)
            {
                resp = new ResponseEntity<String>("Report doesn't exist", HttpStatus.BAD_REQUEST);
            }
            List<ReportDataSource> reportDataSourceList1=reportDataSourceService.updateDatasource(reportId,reportDataSourceList);
            resp = new ResponseEntity<List<ReportDataSource>>( reportDataSourceList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report Data Source doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }

    @GetMapping("reportId/{reportId}")
    public ResponseEntity<?> getAllReportDataSource(@PathVariable int reportId) throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<ReportDataSource> reportDataSourceList = reportDataSourceService.getReportDataSource(reportId);
            resp= new ResponseEntity<List<ReportDataSource>>(
                    reportDataSourceList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report Data Source doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}

