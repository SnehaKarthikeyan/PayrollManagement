package com.upload.UploadFolder.Service.Impl;

import com.upload.UploadFolder.Domain.UploadFolder;
import com.upload.UploadFolder.Repository.UploadFolderRepository;
import com.upload.UploadFolder.Service.UploadFolderService;
import com.upload.UploadFolder.exception.NotFoundException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UploadFolderServiceImpl implements UploadFolderService {
    @Autowired
    private UploadFolderRepository uploadFolderRepository;

    @Override
    public UploadFolder saveUploadFolder(UploadFolder uploadFolder) {
        boolean exists = false;
        if(uploadFolder.getId() != 0) {
            exists = uploadFolderRepository.existsById(uploadFolder.getId());
        }
        if(exists) {
            return null;
        }
        uploadFolder.setActive(true);
        UploadFolder uploadFolder1 = uploadFolderRepository.save(uploadFolder);
        return uploadFolder1;
    }

    @Override
    public UploadFolder getUploadFolderById(int uploadFolderId) {
        UploadFolder uploadFolder1 = null;
        UploadFolder uploadFolder = uploadFolderRepository.findById(uploadFolderId)
                .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Upload Folder  '")
                                .append(uploadFolderId)
                                .append("' not exist")
                                .toString()));
        if(uploadFolder.isActive()){ uploadFolder1 = uploadFolder; }
        return uploadFolder1;
    }

    @Override
    public List<UploadFolder> getAllUploadFolder() {
        List<UploadFolder> list = uploadFolderRepository.findAll();
        List<UploadFolder> result = new ArrayList<UploadFolder>();
        for(UploadFolder uploadFolder : list) {
            if(uploadFolder.isActive()) { result.add(uploadFolder); }
        }
        return result;
    }

    @Override
    public List<UploadFolder> getUploadFolderByClientId(int clientId) {
        List<UploadFolder> list = uploadFolderRepository.findByClientId(clientId);
        List<UploadFolder> result = new ArrayList<UploadFolder>();
        for(UploadFolder uploadFolder : list) {
            if(uploadFolder.isActive()) { result.add(uploadFolder); }
        }
        return result;
    }

    @Override
    public List<UploadFolder> updateUploadFolder(int uploadFolderId, UploadFolder uploadFolder) {
        UploadFolder uploadFolder1 = uploadFolderRepository.findById(uploadFolderId)
                        .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Upload Folder '")
                                .append(uploadFolderId)
                                .append("' not exist")
                                .toString()));
        uploadFolder1.setActive(true);
        BeanUtils.copyProperties(uploadFolder, uploadFolder1);
        uploadFolderRepository.save(uploadFolder1);
        List<UploadFolder> result = getAllUploadFolder();
        return result;
    }

    @Override
    public void deleteUploadFolderById(int uploadFolderId) {
        UploadFolder uploadFolder = getUploadFolderById(uploadFolderId);
        uploadFolder.setActive(false);
        uploadFolderRepository.save(uploadFolder);
    }
}
