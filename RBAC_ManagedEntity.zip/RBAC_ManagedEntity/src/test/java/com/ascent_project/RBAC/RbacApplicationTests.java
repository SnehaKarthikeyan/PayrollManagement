package com.ascent_project.RBAC;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import com.ascent_project.RBAC.model.ManagedEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = RbacApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RbacApplicationTests {


    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    private String getRootUrl() {
        return "http://localhost:" + port;
    }

    @Test
    @Order(1)
    public void testGetAllEntity(){
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);
        ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/managedEntity",
                HttpMethod.GET, entity, String.class);
        assertNotNull(response.getBody());
    }
    @Test
    @Order(2)
    public void testSaveEntity() throws RestClientException {
        ManagedEntity me = new ManagedEntity();
        me.setId(123456l);
        me.setCode("ad123");
        me.setEntityType("Application");
        me.setEntityName("StoHRM berry");
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-COM-PERSIST","true");
        HttpEntity<ManagedEntity> entity = new HttpEntity<>(me, headers);
        ResponseEntity<String> result=this.restTemplate.postForEntity(getRootUrl() + "/managedEntity", entity, String.class);
        Assert.assertEquals(201,result.getStatusCodeValue());
    }

    @Test
    @Order(3)
    public void testGetEntityById() {
        ManagedEntity me = restTemplate.getForObject(getRootUrl() + "/managedEntity/12234", ManagedEntity.class);
        System.out.println(me.getId());
        assertNotNull(me);
    }
    @Test
    @Order(4)
    public void testDeleteEntity() {
        int id = 123456;
        ManagedEntity me = restTemplate.getForObject(getRootUrl() + "/managedEntity/" + id, ManagedEntity.class);
        assertNotNull(me);
        restTemplate.delete(getRootUrl() + "/managedEntity/" + id);
        try {
            me = restTemplate.getForObject(getRootUrl() + "/managedEntity/" + id, ManagedEntity.class);
        } catch (final HttpClientErrorException e) {
            assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
        }
    }

}


