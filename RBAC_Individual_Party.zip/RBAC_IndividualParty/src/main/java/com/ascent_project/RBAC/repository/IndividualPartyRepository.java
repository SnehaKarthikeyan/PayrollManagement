package com.ascent_project.RBAC.repository;

import com.ascent_project.RBAC.model.IndividualParty;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IndividualPartyRepository extends JpaRepository<IndividualParty, String>{

    IndividualParty findByCode(String individualParty_Code);

    @Query("SELECT u from IndividualParty u WHERE id=:user_id")
    List<IndividualParty> findByUserId(String user_id);
}
