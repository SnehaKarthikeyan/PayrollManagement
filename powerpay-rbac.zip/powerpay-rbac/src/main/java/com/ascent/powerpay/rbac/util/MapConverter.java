package com.ascent.powerpay.rbac.util;

import com.ascent.powerpay.rbac.util.ObjectMapperUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class MapConverter {

    public static Map<String, String> convertCompositeMapToFlatMap(Map<String, Object> data) {
        Map<String, String> flatMap = new HashMap<>();
        flatMapConverter(data, flatMap);
        log.debug("Map after it is converted to flat map: {}", flatMap);
        return flatMap;
    }


    private static void flatMapConverter(Map<String, Object> datamap, Map<String, String> flatMap) {
        Map<String, Object> valueMap;
        for (Map.Entry<String, Object> entry : datamap.entrySet()) {
            if (entry.getValue() instanceof Map && !(((Map) entry.getValue()).isEmpty())) {
                valueMap = ObjectMapperUtil.convertToMap(entry.getValue());
                flatMapConverter(valueMap, flatMap);
            } else if (entry.getValue() instanceof Map && ((Map) entry.getValue()).isEmpty()) {
                flatMap.put(entry.getKey(), "");
            } else if (entry.getValue() instanceof ArrayList && !(((ArrayList) entry.getValue()).isEmpty())) {
                for (int i = 0; i < ((ArrayList) entry.getValue()).size(); i++) {
                    valueMap = ObjectMapperUtil.convertToMap(((ArrayList) entry.getValue()).get(i));
                    flatMapConverter(valueMap, flatMap, i + 1);
                }
            } else if (entry.getValue() instanceof ArrayList && ((ArrayList) entry.getValue()).isEmpty()) {
                flatMap.put(entry.getKey(), "");
            } else
                flatMap.put(entry.getKey(), String.valueOf(entry.getValue()));

        }

    }

    private static void flatMapConverter(Map<String, Object> datamap, Map<String, String> flatMap, int index) {
        Map<String, Object> valueMap;
        for (Map.Entry<String, Object> entry : datamap.entrySet()) {
            if (entry.getValue() instanceof Map && !(((Map) entry.getValue()).isEmpty())) {
                valueMap = ObjectMapperUtil.convertToMap(entry.getValue());
                flatMapConverter(valueMap, flatMap);
            } else if (entry.getValue() instanceof Map && ((Map) entry.getValue()).isEmpty()) {
                flatMap.put(entry.getKey(), "");
            } else if (entry.getValue() instanceof ArrayList && !(((ArrayList) entry.getValue()).isEmpty())) {
                for (int i = 0; i < ((ArrayList) entry.getValue()).size(); i++) {
                    valueMap = ObjectMapperUtil.convertToMap(((ArrayList) entry.getValue()).get(i));
                    flatMapConverter(valueMap, flatMap, i + 1);
                }
            } else if (entry.getValue() instanceof ArrayList && ((ArrayList) entry.getValue()).isEmpty()) {
                flatMap.put(entry.getKey(), "");
            } else
                flatMap.put(entry.getKey() + "-" + index, String.valueOf(entry.getValue()));

        }

    }

}
