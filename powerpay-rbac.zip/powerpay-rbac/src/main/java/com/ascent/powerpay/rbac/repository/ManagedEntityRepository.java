package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.domain.ManagedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ManagedEntityRepository extends JpaRepository<ManagedEntity, String>
{

    @Query("SELECT u from ManagedEntity u WHERE id=:managed_entity_id")
    List<ManagedEntity> findByManagedEntityId(String managed_entity_id);

    ManagedEntity findByCode(String managedEntity_code);

    ManagedEntity findByName(String entityName);
}
