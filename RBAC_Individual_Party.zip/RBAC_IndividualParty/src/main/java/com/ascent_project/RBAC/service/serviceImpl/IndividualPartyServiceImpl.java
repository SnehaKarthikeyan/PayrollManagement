package com.ascent_project.RBAC.service.serviceImpl;

import com.ascent_project.RBAC.exception.NotFoundException;
import com.ascent_project.RBAC.model.IndividualParty;
import com.ascent_project.RBAC.repository.IndividualPartyRepository;
import com.ascent_project.RBAC.service.IndividualPartyService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class IndividualPartyServiceImpl implements IndividualPartyService {

    @Autowired
    private IndividualPartyRepository individualPartyRepository;

    @Override
    public String saveIndividualParty(IndividualParty individualParty)
    {
        String id = individualPartyRepository.save(individualParty).getId();
        return id;
    }

    @Override
    public IndividualParty getIndividualPartyById(String individualParty_Id) throws NotFoundException {
        IndividualParty individualParty = individualPartyRepository.findById(individualParty_Id)
                .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Individual Party having  '")
                                .append(individualParty_Id)
                                .append("' not exist")
                                .toString())
                );
        return individualParty;
    }

    @Override
    public IndividualParty getIndividualPartyByCode(String individualParty_Code) throws NotFoundException{
        IndividualParty individualParty = null;
        try {
            individualParty = individualPartyRepository.findByCode(individualParty_Code);
        }catch (Exception e){

        }
        return individualParty;
    }

    @Override
    public List<IndividualParty> getAllIndividualParty() {
        List<IndividualParty> individualPartyList = individualPartyRepository.findAll();
        return individualPartyList;
    }

    @Override
    public void deleteIndividualPartyByCode(String individualParty_Code) throws NotFoundException{
        IndividualParty individualParty= getIndividualPartyByCode(individualParty_Code);
        individualPartyRepository.delete(individualParty);
    }

    @Override
    public void deleteIndividualPartyById(String individualParty_Id) throws NotFoundException{
        IndividualParty individualParty= getIndividualPartyById(individualParty_Id);
        individualPartyRepository.delete(individualParty);
    }

    @Override
    public IndividualParty updateIndividualPartyByCode(IndividualParty individualParty1) {
        return individualPartyRepository.save(individualParty1);
    }
}
