package com.ascentproject.rbac.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ManagedEntity")
public class ManagedEntity {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "Code")
    private String code;

    @Column(name = "EntityType")
    private String entityType;

    @Column(name = "EntityName")
    private String entityName;

}
