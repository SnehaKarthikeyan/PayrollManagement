# powerpay-rbac

Powerpay service for Role based access control