package com.upload.UploadFolder.Repository;

import com.upload.UploadFolder.Domain.UploadFolder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UploadFolderRepository extends JpaRepository<UploadFolder, Integer> {
    List<UploadFolder> findByClientId(int clientId);
}
