package com.example.datasource;

import com.example.datasource.domain.Datasource;
import com.example.datasource.domain.DatasourceParameter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@Transactional
class DatasourceParameterTests extends DatasourceTests{
    @Autowired
    private MockMvc mockMvc;

    @NotNull
    private DatasourceParameter getDatasourceParameter(long datasourceId, String name, String defaultValue, long dataTypeId, String inputName, long recordStatusId) {
        DatasourceParameter datasourceParameter = new DatasourceParameter();
        datasourceParameter.setDatasourceId(datasourceId);
        datasourceParameter.setName(name);
        datasourceParameter.setDefaultValue(defaultValue);
        datasourceParameter.setDataTypeId(dataTypeId);
        datasourceParameter.setInputName(inputName);
        datasourceParameter.setRecordStatusId(recordStatusId);
        return datasourceParameter;
    }

    private DatasourceParameter getDatasourceParameter(MvcResult mvcResult) throws IOException{
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), DatasourceParameter.class);
    }

    private List<DatasourceParameter> addDatasourceParameterAPI(String datasourceCode, List<DatasourceParameter> datasourceParameter) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(datasourceParameter);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/datasourceparameter/" + datasourceCode)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        List<DatasourceParameter> datasourceParameters = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<DatasourceParameter>>(){});
        return datasourceParameters;
    }

    private DatasourceParameter getDatasourceParameterById(String datasourceCode, long id) throws Exception {
        DatasourceParameter datasourceParameter;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datasourceparameter/" + datasourceCode + "/search")
                        .param("id", String.valueOf(id))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        datasourceParameter = getDatasourceParameter(mvcResult);
        return datasourceParameter;
    }

    private DatasourceParameter[] getAllDatasourceParameter(String datasourceCode) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datasourceparameter/" + datasourceCode)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        DatasourceParameter[] datasourceParameterResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), DatasourceParameter[].class);
        return datasourceParameterResult;
    }

    private DatasourceParameter updateDatasourceParameterAPI(String datasourceCode, DatasourceParameter datasourceParameter) throws Exception {
        Gson gson = new Gson();
        String meStr = gson.toJson(datasourceParameter);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/datasourceparameter/" + datasourceCode + "/" + datasourceParameter.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(meStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        DatasourceParameter datasourceParameterResult = getDatasourceParameter(mvcResult);
        return datasourceParameterResult;
    }

    @Test
    public void testSaveDatasourceParameter() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceParameter> datasourceParameter = new ArrayList<DatasourceParameter>();
        datasourceParameter.add(getDatasourceParameter(123L, "name2", "value2", 2L, "input2",  1L));
        datasourceParameter = addDatasourceParameterAPI(datasource.get(0).getCode(), datasourceParameter);
        assertNotNull(datasourceParameter.get(0));
        assertEquals("name2", datasourceParameter.get(0).getName());
        assertEquals("value2", datasourceParameter.get(0).getDefaultValue());
        assertEquals(2L, datasourceParameter.get(0).getDataTypeId());
        assertEquals("input2", datasourceParameter.get(0).getInputName());
        assertEquals(1L, datasourceParameter.get(0).getRecordStatusId());
    }

    @Test
    public void testGetDatasourceParameterById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceParameter> datasourceParameter = new ArrayList<DatasourceParameter>();
        datasourceParameter.add(getDatasourceParameter(123L, "name2", "value2", 2L, "input2",  1L));
        datasourceParameter = addDatasourceParameterAPI(datasource.get(0).getCode(), datasourceParameter);
        long id = datasourceParameter.get(0).getId();
        DatasourceParameter datasourceParameter1 = getDatasourceParameterById(datasource.get(0).getCode(), id);
        assertEquals("name2", datasourceParameter1.getName());
        assertEquals(2L, datasourceParameter1.getDataTypeId());
        assertEquals("value2", datasourceParameter1.getDefaultValue());
        assertEquals("input2", datasourceParameter1.getInputName());
        assertEquals(1L, datasourceParameter1.getRecordStatusId());
    }

    @Test
    public void testGetAllDatasourceParameter() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceParameter> datasourceParameter = new ArrayList<DatasourceParameter>();
        datasourceParameter.add(getDatasourceParameter(123L, "name3", "value3", 2L, "input3",  1L));
        datasourceParameter = addDatasourceParameterAPI(datasource.get(0).getCode(), datasourceParameter);
        assertEquals("name3", datasourceParameter.get(0).getName());
        assertEquals(2L, datasourceParameter.get(0).getDataTypeId());
        assertEquals("value3", datasourceParameter.get(0).getDefaultValue());
        assertEquals("input3", datasourceParameter.get(0).getInputName());
        assertEquals(1L, datasourceParameter.get(0).getRecordStatusId());
        datasourceParameter.add(getDatasourceParameter(123L, "name4", "value4", 2L, "input4",  1L));
        addDatasourceParameterAPI(datasource.get(0).getCode(), datasourceParameter);
        DatasourceParameter[] result = getAllDatasourceParameter(datasource.get(0).getCode());
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testUpdateDatasourceParameter() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceParameter> datasourceParameter = new ArrayList<DatasourceParameter>();
        datasourceParameter.add(getDatasourceParameter(123L, "name5", "value5", 2L, "input5",  1L));
        datasourceParameter = addDatasourceParameterAPI(datasource.get(0).getCode(), datasourceParameter);
        datasourceParameter.get(0).setName("name6");
        datasourceParameter.get(0).setInputName("input6");
        DatasourceParameter datasourceParameter1 = updateDatasourceParameterAPI(datasource.get(0).getCode(), datasourceParameter.get(0));
        assertNotNull(datasourceParameter1);
        assertEquals("name6", datasourceParameter1.getName());
        assertEquals(2L, datasourceParameter1.getDataTypeId());
        assertEquals("value5", datasourceParameter1.getDefaultValue());
        assertEquals("input6", datasourceParameter1.getInputName());
        assertEquals(1L, datasourceParameter1.getRecordStatusId());
    }

    @Test
    public void testDeleteDatasourceParameterById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        List<DatasourceParameter> datasourceParameter = new ArrayList<DatasourceParameter>();
        datasourceParameter.add(getDatasourceParameter(123L, "name7", "value7", 2L, "input7",  1L));
        datasourceParameter = addDatasourceParameterAPI(datasource.get(0).getCode(), datasourceParameter);
        long id= datasourceParameter.get(0).getId();
        try {
            assertEquals("Datasource Parameter '"+ id + "' deleted", delete(datasource.get(0).getCode(), id));
        } catch(final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private String delete(String datasourceCode, long id) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/datasourceparameter/" + datasourceCode)
                        .param("id", String.valueOf(id))
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk()).andReturn();
        return mvcResult.getResponse().getContentAsString();
    }
}
