package com.ascent.powerpay.rbac.BulkHelper;

import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.domain.Role;
import com.ascent.powerpay.rbac.domain.UserRole;
import com.ascent.powerpay.rbac.repository.IndividualPartyRepository;
import com.ascent.powerpay.rbac.repository.ManagedEntityRepository;
import com.ascent.powerpay.rbac.repository.RoleRepository;
import com.ascent.powerpay.rbac.service.serviceImpl.UserRoleServiceImpl;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
//:TODO @Hari check that all columns in csv have code not id.
@Component
public class BulkHelperUserRole {
   public static String TYPE = "text/csv";
    static String[] HEADER = { "id", "code", "active", "roleCode", "userCode", "validUntil" , "managedEntityCode"};
    @Autowired
    UserRoleServiceImpl userRoleService;

    public static boolean hasCSVFormat(MultipartFile file) {

        if (!TYPE.equals(file.getContentType())) {
            return false;
        }

        return true;
    }

    public static List<UserRole> csvToJson(InputStream is, ManagedEntityRepository managedEntityRepository, RoleRepository roleRepository, IndividualPartyRepository individualPartyRepository) {
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            try (CSVParser csvParser = new CSVParser(fileReader,
                    CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim())) {

                List<UserRole> userRoles = new ArrayList<UserRole>();

                Iterable<CSVRecord> csvRecords = csvParser.getRecords();

                for (CSVRecord csvRecord : csvRecords) {
                    String id=csvRecord.get("Id");
                    String code= csvRecord.get("code");
                    boolean active= Boolean.parseBoolean(csvRecord.get("active"));
                    ManagedEntity managedEntity = managedEntityRepository.findByCode(csvRecord.get("managedEntityCode"));
                    String managedEntity1 = managedEntity.getId();
                    Role role = roleRepository.findByCode(csvRecord.get("roleCode"));
                    String role1 = role.getId();
                    IndividualParty individualParty = individualPartyRepository.findByCode(csvRecord.get("userCode"));
                    String individualParty1 = individualParty.getId();
                    String validUntil= csvRecord.get("validUntil");

                    UserRole userRole = new UserRole(
                            id,code,active,managedEntity1,role1,individualParty1,validUntil);
                    userRoles.add(userRole);
                }

                return userRoles;
            }
        } catch (IOException e) {
            throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
        }
    }

}

