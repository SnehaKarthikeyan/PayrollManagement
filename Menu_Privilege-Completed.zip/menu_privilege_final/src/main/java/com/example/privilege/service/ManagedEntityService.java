package com.example.privilege.service;



import com.example.privilege.exception.NotFoundException;
import com.example.privilege.model.ManagedEntity;

import java.util.List;

public interface ManagedEntityService
{

    ManagedEntity saveManagedEntity(ManagedEntity managedEntity) throws NotFoundException;

    ManagedEntity getManagedEntityById(String managedEntity_Id) throws NotFoundException;

    ManagedEntity getManagedEntityByCode(String managedEntity_Code) throws NotFoundException;

    List<ManagedEntity> getAllManagedEntity() throws NotFoundException;

    ManagedEntity updateManagedEntity(String managedEntity_Code, ManagedEntity managedEntity) throws NotFoundException;

    void deleteManagedEntityById(String managedEntity_Id) throws NotFoundException;

    void deleteManagedEntityByCode(String managedEntity_Code) throws NotFoundException;

}
