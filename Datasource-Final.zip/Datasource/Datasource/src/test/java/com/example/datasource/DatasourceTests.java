package com.example.datasource;

import com.example.datasource.domain.Datasource;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.HttpClientErrorException;

import javax.transaction.Transactional;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
@Transactional
class DatasourceTests {
    @Autowired
    private MockMvc mockMvc;

    @NotNull
    protected Datasource getDatasource(long tenantId, String code, String name, long datasourceTypeId, String commandText, String countryId, long recordStatusId)  {
        Datasource datasource = new Datasource();
        datasource.setTenantId(tenantId);
        datasource.setCode(code);
        datasource.setName(name);
        datasource.setDatasourceTypeId(datasourceTypeId);
        datasource.setCommandText(commandText);
        datasource.setCountryId(countryId);
        datasource.setRecordStatusId(recordStatusId);
        return datasource;
    }

    private Datasource getDatasource(MvcResult mvcResult) throws IOException{
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Datasource.class);
    }

    protected List<Datasource> addDatasourceAPI(List<Datasource> datasource) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(datasource);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .post("/manage/datasource")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        List<Datasource> datasources = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<Datasource>>(){});
        return datasources;
    }

    private Datasource getDatasourceById(long id) throws Exception {
        Datasource datasource;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datasource/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("id", String.valueOf(id))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        datasource = getDatasource(mvcResult);
        return datasource;
    }

    private Datasource getDatasourceByCode(String code) throws Exception {
        Datasource datasource;
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datasource/" + code)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        datasource = getDatasource(mvcResult);
        return datasource;
    }

    private Object[] getAllDatasource() throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .get("/manage/datasource")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        Object[] datasourceResult = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), Object[].class);
        return datasourceResult;
    }

    private Datasource updateDatasourceAPI(Datasource datasource) throws Exception {
        Gson gson = new Gson();
        String jsonStr = gson.toJson(datasource);
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .put("/manage/datasource/" + datasource.getCode())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonStr)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();
        Datasource datasourceResult = getDatasource(mvcResult);
        return datasourceResult;
    }

    @Test
    public void testSaveDatasource() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code1", "name1", 2L, "com1", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        assertNotNull(datasource.get(0));
        assertEquals(123L, datasource.get(0).getTenantId());
        assertEquals("code1", datasource.get(0).getCode());
        assertEquals("name1", datasource.get(0).getName());
        assertEquals(2L, datasource.get(0).getDatasourceTypeId());
        assertEquals("com1", datasource.get(0).getCommandText());
        assertEquals("Ind", datasource.get(0).getCountryId());
        assertEquals(1L, datasource.get(0).getRecordStatusId());
    }

    @Test
    public void testGetDatasourceById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code2", "name2", 2L, "com2", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        long id = datasource.get(0).getId();
        Datasource datasource1 = getDatasourceById(id);
        assertEquals(123L, datasource1.getTenantId());
        assertEquals("code2", datasource1.getCode());
        assertEquals("name2", datasource1.getName());
        assertEquals(2L, datasource1.getDatasourceTypeId());
        assertEquals("com2", datasource1.getCommandText());
        assertEquals("Ind", datasource1.getCountryId());
        assertEquals(1L, datasource1.getRecordStatusId());
    }

    @Test
    public void testGetDatasourceByCode() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code3", "name3", 2L, "com3", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        String code = datasource.get(0).getCode();
        Datasource datasource1 = getDatasourceByCode(code);
        assertNotNull(datasource1);
        assertEquals(123L, datasource1.getTenantId());
        assertEquals("code3", datasource1.getCode());
        assertEquals("name3", datasource1.getName());
        assertEquals(2L, datasource1.getDatasourceTypeId());
        assertEquals("com3", datasource1.getCommandText());
        assertEquals("Ind", datasource1.getCountryId());
        assertEquals(1L, datasource1.getRecordStatusId());
    }

    @Test
    public void testGetAllDatasource() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code4", "name4", 2L, "com4", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        assertEquals(123L, datasource.get(0).getTenantId());
        assertEquals("code4", datasource.get(0).getCode());
        assertEquals("name4", datasource.get(0).getName());
        assertEquals(2L, datasource.get(0).getDatasourceTypeId());
        assertEquals("com4", datasource.get(0).getCommandText());
        assertEquals("Ind", datasource.get(0).getCountryId());
        assertEquals(1L, datasource.get(0).getRecordStatusId());
        datasource.add(getDatasource(123L, "code5", "name5", 2L, "com5", "Ind", 1L));
        addDatasourceAPI(datasource);
        Object[] result = getAllDatasource();
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testUpdateDatasource() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code6", "name6", 2L, "com6", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        datasource.get(0).setName("name7");
        Datasource datasource1 = updateDatasourceAPI(datasource.get(0));
        assertNotNull(datasource1);
        assertEquals(123L, datasource1.getTenantId());
        assertEquals("code6", datasource1.getCode());
        assertEquals("name7", datasource1.getName());
        assertEquals(2L, datasource1.getDatasourceTypeId());
        assertEquals("com6", datasource1.getCommandText());
        assertEquals("Ind", datasource1.getCountryId());
        assertEquals(1L, datasource1.getRecordStatusId());
    }

    @Test
    public void testDeleteDatasourceById() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code8", "name8", 2L, "com8", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        long id= datasource.get(0).getId();
        try {
            assertEquals("Datasource '"+ id +"' deleted", delete(id));
        } catch(final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    @Test
    public void testDeleteDatasourceByCode() throws Exception {
        List<Datasource> datasource = new ArrayList<Datasource>();
        datasource.add(getDatasource(123L, "code9", "name9", 2L, "com9", "Ind", 1L));
        datasource = addDatasourceAPI(datasource);
        String code = datasource.get(0).getCode();
        try {
            assertEquals("Datasource '"+ datasource.get(0).getCode() +"' deleted", markForDelete(code));
        } catch(final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private String markForDelete(String code) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/datasource/" + code)
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk()).andReturn();
        return mvcResult.getResponse().getContentAsString();
    }

    private String delete(long id) throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
                        .delete("/manage/datasource")
                        .param("id", String.valueOf(id))
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isOk()).andReturn();
        return mvcResult.getResponse().getContentAsString();
    }
}
