package com.ascentProject.rbac.controller;



import com.ascentProject.rbac.domain.MenuPrivilege;
import com.ascentProject.rbac.exception.NotFoundException;
import com.ascentProject.rbac.service.impl.PrivilegeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/managedEntity/api/v1/privilege")
public class PrivilegeController {

    @Autowired
    private PrivilegeServiceImpl privilegeService;

    @PostMapping("/menu")
    public ResponseEntity<?> savePrivilege(@RequestBody List<MenuPrivilege> privilegeList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<MenuPrivilege> list = (List<MenuPrivilege>) privilegeService.savePrivilege(privilegeList);

            responseEntity= new ResponseEntity<String>(
                    "Privilege created", HttpStatus.CREATED); //201-created}

        } catch (Exception exception) {
            exception.printStackTrace();
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Privilege",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }


    @PutMapping("/{code}")
    public ResponseEntity<?> updateOrCopyPrivilegeByCode(@RequestBody MenuPrivilege menuPrivilege,@PathVariable String code) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            MenuPrivilege menuPrivilegeDb = privilegeService.findPrivilegeByCode(code);
            menuPrivilegeDb.setType( menuPrivilege.getType());
            menuPrivilegeDb.setName( menuPrivilege.getName());
            menuPrivilegeDb.setActive( menuPrivilege.getActive());
            menuPrivilegeDb.setOrder( menuPrivilege.getOrder());
            menuPrivilege = privilegeService.updatePrivilege(menuPrivilegeDb);
            resp = new ResponseEntity<MenuPrivilege>( menuPrivilege, HttpStatus.ACCEPTED); //202-accepted
        } catch (Exception e) {
            resp = new ResponseEntity<String>("code doesn't exist", HttpStatus.CREATED); //202-accepted
        }

        return resp;
    }


   @DeleteMapping("/menuCode/{code}")
    public ResponseEntity<String> deleteOnePrivilege(@PathVariable (name="code") String code){

        ResponseEntity<String> responseEntity= null;
        try {
            privilegeService.deleteOnePrivilegeByCode(code);
            responseEntity= new ResponseEntity<String> (
                    "privilege  '"+code+"' deleted",HttpStatus.OK);

        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete User Role", HttpStatus.BAD_REQUEST);
        }

        return responseEntity;
    }
    @DeleteMapping("/privilegeId/{privilege_id}")
    public ResponseEntity<String> deleteOnePrivilegeById(@PathVariable (name="privilege_id") String privilege_id){

        ResponseEntity<String> responseEntity= null;
        try {
            privilegeService.deleteOnePrivilegeById(privilege_id);
            responseEntity= new ResponseEntity<String> (
                    "privilege  '"+privilege_id+"' deleted",HttpStatus.OK);

        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete User Role", HttpStatus.BAD_REQUEST);
        }

        return responseEntity;
    }

    @DeleteMapping("/parentId/{parent_id}")
    public ResponseEntity<String> deleteOnePrivilegeByParentId(@PathVariable (name="parent_id") String privilege_id){

        ResponseEntity<String> responseEntity= null;
        try {
            privilegeService.deleteOnePrivilegeByParentId(privilege_id);
            responseEntity= new ResponseEntity<String> (
                    "privilege  '"+privilege_id+"' deleted",HttpStatus.OK);

        }
        catch (NotFoundException exception) {
            throw exception;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete User Role", HttpStatus.BAD_REQUEST);
        }

        return responseEntity;
    }





}

