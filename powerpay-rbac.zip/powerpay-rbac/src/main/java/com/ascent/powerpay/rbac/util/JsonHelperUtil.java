package com.ascent.powerpay.rbac.util;

import com.ascent.powerpay.kernel.resource.ConfigResourceLoader;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class JsonHelperUtil {
    public static String contentOf(String functionsFile, ConfigResourceLoader loader) {
        if (StringUtils.isBlank(functionsFile)) {
            return "";
        }
        Resource resource = loader.getResource(functionsFile);
        if (resource == null) {
            throw new IllegalArgumentException("Failed to find functions file: "
                    + functionsFile);
        }

        String structure = null;

        try {
            structure = IOUtils.toString(resource.getInputStream(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return structure;
    }

    public static String convertToJson(Object mapObject) {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonInString = null;
        try {
            jsonInString = objectMapper.writeValueAsString(mapObject);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return jsonInString;
    }

    public static void writeJsonToFile(String jsonTemplate, String path) {
        try {
            Files.write(Paths.get(path), jsonTemplate.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String readJsonFileAsString(String templatePath) {
        String jsonString = null;
        try {
            jsonString = Files.readString(Paths.get(templatePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonString;
    }
}
