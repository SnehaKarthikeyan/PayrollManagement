package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.repository.IndividualPartyRepository;
import com.ascent.powerpay.rbac.service.IndividualPartyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IndividualPartyServiceImpl implements IndividualPartyService
{

    @Autowired
    private IndividualPartyRepository individualPartyRepository;

    @Override
    public IndividualParty saveIndividualParty(IndividualParty individualParty)
    {
        boolean exists = false;
        if(individualParty.getId() != null)
        {
            exists = individualPartyRepository.existsById(individualParty.getId());
        }
        if(exists)
        {
            return null;
        }
        individualParty.setActive(true);
        IndividualParty individualParty1 = individualPartyRepository.save(individualParty);
        return individualParty1;
    }

    @Override
    public IndividualParty getIndividualPartyById(String user_Id) throws NotFoundException
    {
        IndividualParty individualParty = individualPartyRepository.findById(user_Id)
                .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Individual Party having  '")
                                .append(user_Id)
                                .append("' not exist")
                                .toString())
                );
        return individualParty;
    }

    @Override
    public IndividualParty getIndividualPartyByCode(String user_Code) throws NotFoundException {
        IndividualParty individualParty = null;
        try {
            individualParty = individualPartyRepository.findByCode(user_Code);
        }catch (Exception e){

        }
        return individualParty;
    }

    @Override
    public List<IndividualParty> getAllIndividualParty()
    {
        List<IndividualParty> individualPartyList = individualPartyRepository.findAll();
        return individualPartyList;
    }

    @Override
    public IndividualParty updateIndividualParty(String user_Code,
                                                 IndividualParty individualParty)
    {
        IndividualParty individualParty1 = individualPartyRepository.findByCode(user_Code);
        if(individualParty.getCode()!=null)
        {
            individualParty1.setCode(individualParty.getCode());
        }
        if(individualParty.getName()!=null)
        {
            individualParty1.setName(individualParty.getName());
        }
        individualParty1.setActive(true);
        individualPartyRepository.save(individualParty1);
        return individualParty1;
    }

    @Override
    public void deleteIndividualPartyById(String user_Id) throws NotFoundException
    {
        IndividualParty individualParty = getIndividualPartyById(user_Id);
        individualPartyRepository.delete(individualParty);
    }

    @Override
    public void deleteIndividualPartyByCode(String user_Code) throws NotFoundException
    {
        IndividualParty individualParty = getIndividualPartyByCode(user_Code);
        individualParty.setActive(false);
        individualPartyRepository.save(individualParty);
    }

}
