package com.ascent_project.RBAC.repository;

import com.ascent_project.RBAC.model.IndividualParty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IndividualPartyRepository extends JpaRepository<IndividualParty, Long>{
    @Query("SELECT u from IndividualParty u WHERE id=:role_id")
    List<IndividualParty> findByUserId(Long role_id);
}
