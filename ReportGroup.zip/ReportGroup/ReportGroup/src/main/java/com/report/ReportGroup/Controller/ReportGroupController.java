package com.report.ReportGroup.Controller;

import com.report.ReportGroup.Domain.ReportGroup;
import com.report.ReportGroup.Service.ReportGroupService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/reportgroup","/manage/reportgroup"})
public class ReportGroupController {
    @Autowired
    private ReportGroupService reportGroupService;

    @PostMapping
    public ResponseEntity<?> saveReportGroup(@RequestBody List<ReportGroup> reportGroup) {
        ResponseEntity<List<ReportGroup>> responseEntity = null;
        try {
            for(ReportGroup reportGroup1: reportGroup) {
                reportGroupService.saveReportGroup(reportGroup1);
            }
            responseEntity = new ResponseEntity<List<ReportGroup>>(reportGroup, HttpStatus.CREATED);
        } catch(Exception e) {
            log.debug("Unable to save Report group");
            responseEntity = new ResponseEntity<List<ReportGroup>>(reportGroup, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/search")
    public ResponseEntity<?> getReportGroupById(@RequestParam("id") int reportGroupId) {
        ResponseEntity<?> responseEntity= null;
        ReportGroup reportGroup = null;
        try {
            reportGroup = reportGroupService.getReportGroupById(reportGroupId);
            responseEntity= new ResponseEntity<ReportGroup>(reportGroup,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Report group");
            responseEntity = new ResponseEntity<String>("Unable to get Report group", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{reportGroupCode}")
    public ResponseEntity<?> getReportGroupByCode(@PathVariable("reportGroupCode") String reportGroupCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            ReportGroup reportGroup= reportGroupService.getReportGroupByCode(reportGroupCode);
            responseEntity= new ResponseEntity<ReportGroup>(reportGroup,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Report group");
            responseEntity = new ResponseEntity<String>("Unable to get Report group", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping
    public ResponseEntity<?> getAllReportGroup() {
        ResponseEntity<?> responseEntity= null;
        try {
            List<ReportGroup> reportGroups= reportGroupService.getAllReportGroup();
            responseEntity= new ResponseEntity<List<ReportGroup>>(reportGroups,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Report group");
            responseEntity = new ResponseEntity<String>("Unable to get Report group", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/{reportGroupCode}")
    public ResponseEntity<?> updateReportGroup(@PathVariable("reportGroupCode") String reportGroupCode,
                                              @RequestBody ReportGroup reportGroup) {
        ResponseEntity<?> responseEntity = null;
        List<ReportGroup> reportGroup1 = null;
        try {
            reportGroup1 = reportGroupService.updateReportGroup(reportGroupCode, reportGroup);
            responseEntity = new ResponseEntity<List<ReportGroup>>(reportGroup1, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to update Report group");
            responseEntity = new ResponseEntity<String>("Unable to update Report group", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping
    public ResponseEntity<?> deleteReportGroupById(@RequestParam("id") int reportGroupId) {
        ResponseEntity<?> responseEntity= null;
        try {
            reportGroupService.deleteReportGroupById(reportGroupId);
            responseEntity = new ResponseEntity<String> ("Report Group '"+reportGroupId+"' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Report group");
            responseEntity = new ResponseEntity<String>("Unable to delete Report group", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{reportGroupCode}")
    public ResponseEntity<?> deleteReportGroupByCode(@PathVariable("reportGroupCode") String reportGroupCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            reportGroupService.deleteReportGroupByCode(reportGroupCode);
            responseEntity = new ResponseEntity<String>("Report Group '" + reportGroupCode + "' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Report Group");
            responseEntity = new ResponseEntity<String>("Unable to delete Report Group", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
