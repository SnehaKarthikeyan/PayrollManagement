package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.ReportType;
import com.Ascentproject.report.repository.ReportTypeRepository;
import com.Ascentproject.report.service.ReportTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportTypeServiceImpl implements ReportTypeService{
    @Autowired
    public ReportTypeRepository reportTypeRepository;

    public List<ReportType> saveReportType(List<ReportType> reportTypeList)
    {
        return reportTypeRepository.saveAll(reportTypeList);
    }
    public  List<ReportType> getReportType()
    {
        List<ReportType> reportTypeList= reportTypeRepository.findAll().stream()
                .collect(Collectors.toList());
        return reportTypeList;
    }
}
