package com.ascent.powerpay.rbac.repository;


import com.ascent.powerpay.rbac.domain.InvolvementIdentification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InvolvementIdentificationRepository extends JpaRepository<InvolvementIdentification, String> {

    InvolvementIdentification findByCode(String involvementIdentification_code);
    InvolvementIdentification findByManagedEntityIdAndIndividualPartyIdAndId(String managedEntityId, String individualPartyId, String involvementIdentificationId);
    List<InvolvementIdentification> findAllByManagedEntityIdAndIndividualPartyId(String managedEntityId, String individualPartyId);
    InvolvementIdentification findByManagedEntityIdAndIndividualPartyIdAndCode(String managedEntityId, String individualPartyId, String involvementIdentificationCode);
}
