package com.example.datasource.controller;

import com.example.datasource.domain.Datasource;
import com.example.datasource.service.DataFieldService;
import com.example.datasource.service.DatasourceOptionsService;
import com.example.datasource.service.DatasourceParameterService;
import com.example.datasource.service.DatasourceService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/datasource","/manage/datasource"})
public class DatasourceController {
    @Autowired
    private DatasourceService datasourceService;

    @Autowired
    private DataFieldService dataFieldService;

    @Autowired
    private DatasourceParameterService datasourceParameterService;

    @Autowired
    private DatasourceOptionsService datasourceOptionsService;

    @PostMapping
    public ResponseEntity<?> saveDatasource(@RequestBody List<Datasource> datasource) {
        ResponseEntity<?> responseEntity;
        try {
            for(Datasource datasource1: datasource) {
                datasourceService.saveDatasource(datasource1);
            }
            responseEntity = new ResponseEntity<List<Datasource>>(datasource, HttpStatus.CREATED);
        } catch(Exception e) {
            log.debug("Unable to save Datasource");
            responseEntity = new ResponseEntity<List<Datasource>>(datasource, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/search")
    public ResponseEntity<?> getDatasourceById(@RequestParam("id") long datasourceId) {
        ResponseEntity<?> responseEntity= null;
        Datasource datasource = null;
        try {
            datasource = datasourceService.getDatasourceById(datasourceId);
            responseEntity = new ResponseEntity<Datasource>(datasource, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{datasourceCode}")
    public ResponseEntity<?> getDatasourceByCode(@PathVariable("datasourceCode") String datasourceCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            Datasource datasource= datasourceService.getDatasourceByCode(datasourceCode);
            responseEntity = new ResponseEntity<Datasource>(datasource, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping
    public ResponseEntity<?> getAllDatasource() {
        ResponseEntity<?> responseEntity= null;
        ArrayList<List<Object>> result = new ArrayList<List<Object>>();
        try {
            List<Datasource> datasource = datasourceService.getAllDatasource();
            System.out.println(datasource);
            for(Datasource datasource1 : datasource) {
                System.out.println( dataFieldService.getJoinFields(datasource1.getCode()));
                result.add((List<Object>) dataFieldService.getJoinFields(datasource1.getCode()));
            }
            responseEntity= new ResponseEntity<ArrayList<List<Object>>>(result, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/details")
    public ResponseEntity<?> getDatasourceDetailsById(@RequestParam("id") long datasourceId) {
        ResponseEntity<?> responseEntity= null;
        Datasource datasource = datasourceService.getDatasourceById(datasourceId);
        ArrayList<ArrayList<Object>> result = new ArrayList<ArrayList<Object>>();
        try {
            result.add((ArrayList<Object>) dataFieldService.getJoinFields(datasource.getCode()));
            result.add((ArrayList<Object>) datasourceOptionsService.getAllDatasourceOptions(datasource.getCode()));
            result.add((ArrayList<Object>) datasourceParameterService.getAllDatasourceParameter(datasource.getCode()));
            responseEntity = new ResponseEntity<ArrayList<ArrayList<Object>>>(result, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/{datasourceCode}")
    public ResponseEntity<?> updateDatasource(@PathVariable("datasourceCode") String datasourceCode,
                                                 @RequestBody Datasource datasource) {
        ResponseEntity<?> responseEntity = null;
        Datasource datasource1 = null;
        try {
            datasource1 = datasourceService.updateDatasource(datasourceCode, datasource);
            responseEntity = new ResponseEntity<Datasource>(datasource1, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to update Datasource");
            responseEntity = new ResponseEntity<String>("Unable to update Datasource", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping
    public ResponseEntity<?> deleteDatasourceById(@RequestParam("id") long datasourceId) {
        ResponseEntity<?> responseEntity= null;
        try {
            datasourceService.deleteDatasourceById(datasourceId);
            responseEntity = new ResponseEntity<String> ("Datasource '"+datasourceId+"' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Datasource");
            responseEntity = new ResponseEntity<String>("Unable to delete Datasource", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{datasourceCode}")
    public ResponseEntity<?> deleteDatasourceByCode(@PathVariable("datasourceCode") String datasourceCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            datasourceService.deleteDatasourceByCode(datasourceCode);
            responseEntity = new ResponseEntity<String>("Datasource '" + datasourceCode + "' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Datasource");
            responseEntity = new ResponseEntity<String>("Unable to delete Datasource", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
