package com.Ascentproject.report.repository;

import com.Ascentproject.report.domain.ReportDataSource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReportDataSourceRepository extends JpaRepository<ReportDataSource,Integer> {

    List<ReportDataSource> findByReportId(int reportId);
}