package com.ascent_project.RBAC.service.impl;

public class AssetInvolvementRoleService {
}
