package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.ReportPage;
import com.Ascentproject.report.service.ReportPageService;
import org.springframework.stereotype.Service;
import com.Ascentproject.report.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportPageServiceImpl  implements ReportPageService {

    @Autowired
    public ReportPageRepository reportPageRepository;

   public List<ReportPage> saveReportPage(int reportId,List<ReportPage> reportPageList){
       reportPageList.stream().forEach(reportPage -> reportPage.setReportId(reportId));
        return reportPageRepository.saveAll(reportPageList);
    }
    public List<ReportPage> getReportPage(int reportId) {
        List<ReportPage> reportPageList= reportPageRepository.findByReportId(reportId).stream()
                .collect(Collectors.toList());
        return reportPageList;
    }
}
