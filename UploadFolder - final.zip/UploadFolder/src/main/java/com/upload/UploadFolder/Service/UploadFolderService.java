package com.upload.UploadFolder.Service;

import com.upload.UploadFolder.Domain.UploadFolder;

import java.util.List;

public interface UploadFolderService {
    UploadFolder saveUploadFolder(UploadFolder uploadFolder);

    UploadFolder getUploadFolderById(int uploadFolderId);

    List<UploadFolder> getAllUploadFolder();

    List<UploadFolder> getUploadFolderByClientId(int clientId);

    List<UploadFolder> updateUploadFolder(int uploadFolderId, UploadFolder uploadFolder);

    void deleteUploadFolderById(int uploadFolderId);
}
