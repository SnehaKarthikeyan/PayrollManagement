package com.example.privilege.service.impl;

import com.example.privilege.exception.NotFoundException;
import com.example.privilege.model.ManagedEntity;
import com.example.privilege.repository.ManagedEntityRepository;
import com.example.privilege.service.ManagedEntityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManagedEntityServiceImpl implements ManagedEntityService
{

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    @Override
    public ManagedEntity saveManagedEntity(ManagedEntity managedEntity)
    {
        boolean exists = false;
        if(managedEntity.getId() != null)
        {
            exists = managedEntityRepository.existsById(managedEntity.getId());
        }
        if(exists)
        {
            return null;
        }
        managedEntity.setActive(true);
        ManagedEntity managedEntity1 = managedEntityRepository.save(managedEntity);
        return managedEntity1;
    }

    @Override
    public ManagedEntity getManagedEntityById(String managedEntity_Id) throws NotFoundException
    {
        ManagedEntity managedEntity = managedEntityRepository.findById(managedEntity_Id)
                .orElseThrow(()->new NotFoundException(
                        new StringBuffer().append("Entity  '")
                                .append(managedEntity_Id)
                                .append("' not exist")
                                .toString())
                );
        return managedEntity;
    }

    @Override
    public ManagedEntity getManagedEntityByCode(String managedEntity_Code) throws NotFoundException
    {
        ManagedEntity managedEntity;
        managedEntity = managedEntityRepository.findByCode(managedEntity_Code);
        return managedEntity;
    }

    @Override
    public List<ManagedEntity> getAllManagedEntity()
    {
        List<ManagedEntity> list = managedEntityRepository.findAll();
        return list;
    }

    @Override
    public ManagedEntity updateManagedEntity(String managedEntity_Code, ManagedEntity managedEntity)
    {
        ManagedEntity managedEntity1 = managedEntityRepository.findByCode(managedEntity_Code);
        if(managedEntity.getCode()!=null)
        {
            managedEntity1.setCode(managedEntity.getCode());
        }
        if(managedEntity.getType()!=null)
        {
            managedEntity1.setType(managedEntity.getType());
        }
        if(managedEntity.getName()!=null)
        {
            managedEntity1.setName(managedEntity.getName());
        }
        managedEntity1.setActive(true);
        return managedEntityRepository.save(managedEntity1);
    }

    @Override
    public void deleteManagedEntityById(String managedEntity_Id) throws NotFoundException
    {
        ManagedEntity managedEntity = getManagedEntityById(managedEntity_Id);
        if(managedEntity == null)
            throw new NotFoundException(managedEntity_Id + " not found for delete");
        managedEntityRepository.delete(managedEntity);
    }

    @Override
    public void deleteManagedEntityByCode(String managedEntity_Code) throws NotFoundException
    {
        ManagedEntity managedEntity = getManagedEntityByCode(managedEntity_Code);
        if(managedEntity == null)
            throw new NotFoundException(managedEntity_Code + " code not found mark for delete");
        managedEntity.setActive(false);
        managedEntityRepository.save(managedEntity);
    }

}


