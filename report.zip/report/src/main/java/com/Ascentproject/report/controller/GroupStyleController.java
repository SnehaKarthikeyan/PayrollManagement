package com.Ascentproject.report.controller;


import com.Ascentproject.report.domain.GroupStyle;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.GroupStyleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/pagetype", "/manage/pagetype"})

public class GroupStyleController {
    @Autowired
    private GroupStyleService groupStyleService;

    @CrossOrigin
    @PostMapping
    public ResponseEntity<?> saveGroupStyle(@RequestBody List<GroupStyle> groupStyleList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<GroupStyle> groupStyleList1= groupStyleService.saveGroupStyle(groupStyleList);
            if(groupStyleList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save Group Style ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<GroupStyle>>(
                    groupStyleList, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Group Style ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @GetMapping
    public ResponseEntity<?> getAllGroupStyle() throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<GroupStyle> groupStyleList = groupStyleService.getGroupStyle();
            resp= new ResponseEntity<List<GroupStyle>>(
                    groupStyleList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Group Style doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}