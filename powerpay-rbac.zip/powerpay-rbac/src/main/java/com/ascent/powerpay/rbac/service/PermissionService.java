package com.ascent.powerpay.rbac.service;

import com.ascent.powerpay.rbac.domain.Permission;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface PermissionService
{

    Permission savePermission(String managedEntity_id, Permission permission) throws NotFoundException;

    void saveBulkUpload(MultipartFile file) throws NotFoundException;

    Permission getPermissionById(String permission_id) throws NotFoundException;

    Permission getPermissionByCode(String permission_Code) throws NotFoundException;

    List<Permission> getAllPermission() throws NotFoundException;

    Permission updatePermission(String managedEntity_Code, String permission_Code,
                                Permission permission) throws NotFoundException;

    void deletePermissionById(String permission_Code) throws NotFoundException;

    void deletePermissionByCode(String permission_code) throws NotFoundException;
}
