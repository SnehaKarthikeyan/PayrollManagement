package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.domain.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RoleRepository extends JpaRepository<Role, String> {
    Role findByManagedEntityIdAndId(String managedEntityCode, String roleId);
    Role findByManagedEntityIdAndCode(String managedEntityId, String code);
    Role findByCode(String roleCode);
    List<Role> findAllByManagedEntityId(String managedEntityId);
}
