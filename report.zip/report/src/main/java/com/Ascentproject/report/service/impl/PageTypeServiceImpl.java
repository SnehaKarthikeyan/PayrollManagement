package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.PageType;
import com.Ascentproject.report.repository.PageTypeRepository;
import com.Ascentproject.report.service.PageTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PageTypeServiceImpl implements PageTypeService {
    @Autowired
    public PageTypeRepository pageTypeRepository;

    public List<PageType> savePageType(List<PageType> pageTypeList)
    {
        return pageTypeRepository.saveAll(pageTypeList);
    }
    public  List<PageType> getPageType()
    {
        List<PageType> pageTypeList= pageTypeRepository.findAll().stream()
                .collect(Collectors.toList());
        return pageTypeList;
    }
}
