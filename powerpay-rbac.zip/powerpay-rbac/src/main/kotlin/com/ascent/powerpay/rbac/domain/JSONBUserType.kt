package com.ascent.powerpay.rbac.domain

import com.fasterxml.jackson.databind.ObjectMapper
import org.hibernate.engine.spi.SharedSessionContractImplementor
import org.hibernate.internal.util.ReflectHelper
import org.hibernate.usertype.ParameterizedType
import org.hibernate.usertype.UserType
import java.io.Serializable
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Types
import java.util.*

class JSONBUserType @JvmOverloads constructor(var classType: Class<Any>? = null) : UserType, ParameterizedType, Serializable {
    companion object {
        private const val serialVersionUID: Long = 1L
        const val CLASS_TYPE = "classType"
        private val MAPPER = ObjectMapper()
    }

    override fun deepCopy(value: Any?) =
            value ?: MAPPER.readValue(MAPPER.writeValueAsString(value), this.classType)

    override fun replace(original: Any?, target: Any?, owner: Any?) = deepCopy(original)

    override fun equals(x: Any?, y: Any?) = Objects.equals(x, y)

    override fun returnedClass() = classType

    override fun assemble(cached: Serializable, owner: Any) = deepCopy(cached)

    override fun disassemble(value: Any?) = MAPPER.writeValueAsString(value)

    override fun sqlTypes() = intArrayOf(Types.JAVA_OBJECT)

    override fun hashCode(x: Any?) = Objects.hashCode(x)

    override fun setParameterValues(params: Properties) {
        classType = ReflectHelper.classForName(params.getProperty(CLASS_TYPE), this.javaClass)
    }

    override fun nullSafeGet(rs: ResultSet, names: Array<out String>, session: SharedSessionContractImplementor?,
                             owner: Any?) = rs.getString(names[0])?.let { MAPPER.readValue(it, this.classType) }

    override fun nullSafeSet(st: PreparedStatement, value: Any?, index: Int,
                             session: SharedSessionContractImplementor?) =
            value?.let { st.setObject(index, MAPPER.writeValueAsString(it), Types.OTHER) } ?: st.setNull(index,
                    Types.OTHER)

    override fun isMutable() = true

}