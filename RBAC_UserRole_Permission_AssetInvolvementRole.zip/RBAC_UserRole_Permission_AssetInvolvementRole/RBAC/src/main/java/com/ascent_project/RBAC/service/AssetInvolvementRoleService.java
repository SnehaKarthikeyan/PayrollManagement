package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.model.*;
import com.ascent_project.RBAC.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetInvolvementRoleService {

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private AssetInvolvementRoleRepository assetInvolvementRoleRepository;

    @Autowired
    private PrivilegeRepository privilegeRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public AssetInvolvementRole getOneAssetInvolvementRole(Long assetInvolvementRole_id) {
        AssetInvolvementRole assetInvolvementRole;
        assetInvolvementRole = assetInvolvementRoleRepository.findById(assetInvolvementRole_id).get();
        return assetInvolvementRole;
    }

    public Long saveAssetInvolvementRole(Long managedEntity_id, Long privilege_id, Long permission_id, Long userRole_id, AssetInvolvementRole assetInvolvementRole) {
        ManagedEntity managedEntity = managedEntityRepository.findById(managedEntity_id).get();
        Privilege privilege = privilegeRepository.findById(privilege_id).get();
        Permission permission = permissionRepository.findById(permission_id).get();
        UserRole userRole = userRoleRepository.findById(userRole_id).get();
        assetInvolvementRole.setManagedEntity(managedEntity);
        assetInvolvementRole.setPrivilege(privilege);
        assetInvolvementRole.setPermission(permission);
        assetInvolvementRole.setUserRole(userRole);
        assetInvolvementRoleRepository.save(assetInvolvementRole);
        return userRole.getId();
    }

    public List<AssetInvolvementRole> getAllAssetInvolvementRoles(Long managedEntity_id) {
        List<AssetInvolvementRole> assetInvolvementRoles = assetInvolvementRoleRepository.findByManagedEntityId(managedEntity_id);
        return assetInvolvementRoles;
    }
}
