package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.exception.PrivilegeNotFoundException;
import com.ascent_project.RBAC.model.Privilege;
import com.ascent_project.RBAC.repository.ManagedEntityRepository;
import com.ascent_project.RBAC.repository.PrivilegeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PrivilegeService {

    @Autowired
    private PrivilegeRepository privilegeRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    public Long savePrivilege(Long managedEntityId, Privilege privilege) {
        return managedEntityRepository.findById(managedEntityId).map(managedEntity -> {
            privilege.setManagedEntity(managedEntity);
                return privilegeRepository.save(privilege).getId();
        }).orElseThrow(() -> new PrivilegeNotFoundException("Unable to save Privilege"));
    }

    public List<Privilege> getAllPrivilege(Long managedEntityId) {
        List<Privilege> result = privilegeRepository.findByManagedEntityId(managedEntityId);
        return result;
    }

    public Privilege getPrivilegeById(Long managedEntityId,Long privilegeId) {
        Privilege result = privilegeRepository.findByIdAndManagedEntityId(privilegeId, managedEntityId);
        return result;
    }

    public Privilege updatePrivilegeById(Long managedEntityId, Long privilegeId, Privilege privilegeRequest) {
        return privilegeRepository.findById(privilegeId).map(privilege -> {
            if(privilegeRequest.getAction()!=null){
                privilege.setAction(privilegeRequest.getAction());}
            if(privilegeRequest.getFunction()!=null) {
                privilege.setFunction(privilegeRequest.getFunction());
            }
            return privilegeRepository.save(privilege);
        }).orElseThrow(() -> new PrivilegeNotFoundException("Unable to find Privilege"));
    }

    public void deletePrivilege(Long managedEntityId, Long privilegeId) {
        Privilege result = getPrivilegeById(managedEntityId, privilegeId);
        privilegeRepository.delete(result);
    }
}
