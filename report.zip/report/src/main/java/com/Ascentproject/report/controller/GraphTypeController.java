package com.Ascentproject.report.controller;

import com.Ascentproject.report.domain.Category;
import com.Ascentproject.report.domain.GraphType;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.CategoryService;
import com.Ascentproject.report.service.GraphTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/graphtype", "/manage/graphtype"})

public class GraphTypeController {
    @Autowired
    private GraphTypeService graphTypeService;

    @CrossOrigin
    @PostMapping
    public ResponseEntity<?> saveGraphType(@RequestBody List<GraphType> graphTypeList){
        ResponseEntity<?> responseEntity = null;
        try{

            List<GraphType> graphTypeList1= graphTypeService.saveGraphType(graphTypeList);
            if(graphTypeList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save GraphType ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<GraphType>>(
                    graphTypeList, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save GraphType ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    @GetMapping
    public ResponseEntity<?> getAllGraphType() throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<GraphType> graphTypeList = graphTypeService.getGraphType();
            resp= new ResponseEntity<List<GraphType>>(
                    graphTypeList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("GraphType doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}