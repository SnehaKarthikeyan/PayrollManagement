package com.ascentProject.rbac.service;


import org.springframework.stereotype.Component;
import com.ascentProject.rbac.domain.MenuPrivilege;

import java.util.List;

@Component
public interface PrivilegeService {
    public List<MenuPrivilege> savePrivilege(List<MenuPrivilege> privilegeList);

    public void deleteOnePrivilegeByCode(String code);
    public void  deleteOnePrivilegeById(String privilege_id);
    public void  deleteOnePrivilegeByParentId(String parent_id);
}


