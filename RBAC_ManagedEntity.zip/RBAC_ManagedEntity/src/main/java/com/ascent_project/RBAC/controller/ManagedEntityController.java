package com.ascent_project.RBAC.controller;


import com.ascent_project.RBAC.model.ManagedEntity;
import com.ascent_project.RBAC.service.IManagedEntityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.ascent_project.RBAC.exception.EntityNotFoundException;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/managedEntity")
public class ManagedEntityController {
    @Autowired
    private IManagedEntityService service;
    @PostMapping
    public ResponseEntity<String> saveEntity(@RequestBody ManagedEntity me){
        ResponseEntity<String> resp = null;
        try{
            Long id = service.saveEntity(me);
            if(id==null) {
                resp = new ResponseEntity<String>(
                        "Entity "+me.getId()+" already created", HttpStatus.INTERNAL_SERVER_ERROR); //201-created
            }
            else{
                resp = new ResponseEntity<String>(
                        "Entity "+me.getId()+"  created", HttpStatus.CREATED); //201-created
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp = new ResponseEntity<String>(
                    "Unable to save entity",
                    HttpStatus.INTERNAL_SERVER_ERROR); //500-Internal Server Error
        }
        return resp;
    }
    @GetMapping
    public ResponseEntity<?> getAllEntity() {
        ResponseEntity<?> resp=null;
        try {
            List<ManagedEntity> list= service.getAllEntity();
            resp= new ResponseEntity<List<ManagedEntity>>(list,HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            resp = new ResponseEntity<String>(
                    "Unable to get entity",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return resp;
    }
    @GetMapping("/{id}")
    public ResponseEntity<?> getOneEntity(@PathVariable Long id){
        ResponseEntity<?> resp= null;
        try {
            ManagedEntity me= service.getOneEntity(id);
            resp= new ResponseEntity<ManagedEntity>(me,HttpStatus.OK);
        }catch (EntityNotFoundException nfe) {
            throw nfe;
        }catch (Exception e) {
            e.printStackTrace();
            resp = new ResponseEntity<String>(
                    "Unable to find Entity",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return resp;
    }


    @DeleteMapping ("/{id}")
    public ResponseEntity<String> deleteEntity(@PathVariable Long id){

        ResponseEntity<String> resp= null;
        try {
            service.deleteEntity(id);
            resp= new ResponseEntity<String> (
                    "Entity '"+id+"' deleted",HttpStatus.OK);

        } catch (EntityNotFoundException nfe) {
            throw nfe;
        } catch (Exception e) {
            e.printStackTrace();
            resp= new ResponseEntity<String>(
                    "Unable to delete Entity", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return resp;
    }

}
