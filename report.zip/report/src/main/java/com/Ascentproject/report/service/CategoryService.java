package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.Category;
import java.util.List;

public interface CategoryService {
   List<Category> saveCategory(List<Category> categoryList);
   List<Category> getCategory();
}
