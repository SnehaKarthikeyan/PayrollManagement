package com.Ascentproject.report.service.impl;

import com.Ascentproject.report.domain.Report;
import com.Ascentproject.report.service.ReportService;
import org.springframework.stereotype.Service;
import com.Ascentproject.report.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
public class ReportServiceImpl implements ReportService {
    @Autowired
    private ReportRepository reportRepository;

    public Report saveReport(int tenantId, Report report) {
            report.setTenantId(tenantId);
            return reportRepository.save(report);
    }

    public Report findReportById(int tenantId, int reportId) {
        Report report= reportRepository.findByTenantIdAndId(tenantId,reportId);
        return report;
    }

    public Report updateReport(Report report, Report report1) {
      report1.setCode(report.getCode());
      report1.setName(report.getName());
      report1.setCategoryId(report.getCategoryId());
      report1.setDescription(report.getDescription());
      report1.setReportTypeId(report.getReportTypeId());
      report1.setGraphTypeId(report.getGraphTypeId());
      report1.setPreviousDataMonth(report.getPreviousDataMonth());
      report1.setExcelPassword(report.getExcelPassword());
      report1.setExcelSheetPassword(report.getExcelSheetPassword());
      report1.setReportNameFormat(report.getReportNameFormat());
      report1.setBatchReport(report.isBatchReport());
      report1.setPeriodicReport(report.isPeriodicReport());
      report1.setRecordStatus(report.isRecordStatus());
      return reportRepository.save(report1);
    }

    public List<Report> getReports(int tenantId) {
        List<Report> reportList = reportRepository.findByTenantId(tenantId);
        return reportList;
    }

    public Report findReportByName(int tenantId, String reportName) {
       Report report =reportRepository.findByTenantIdAndName(tenantId,reportName);
       return report;
    }

    public void deleteOneReportByCode(int tenantId, String reportCode) {
        Report report =reportRepository.findByTenantIdAndCode(tenantId,reportCode);
        reportRepository.delete(report);
    }

    public void deleteOneReportById(int tenantId, int reportId) {
        Report report =reportRepository.findByTenantIdAndId(tenantId,reportId);
        reportRepository.delete(report);
    }
}
