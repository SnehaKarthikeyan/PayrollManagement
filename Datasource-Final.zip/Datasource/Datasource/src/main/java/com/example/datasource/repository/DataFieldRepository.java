package com.example.datasource.repository;

import com.example.datasource.domain.DataField;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface DataFieldRepository extends JpaRepository<DataField, Long> {
    DataField findByDatasourceIdAndId(long datasourceId, long dataFieldId);
    List<DataField> findByDatasourceId(long datasourceId);
    List<DataField> getByDatasourceId(long datasourceId);
}
