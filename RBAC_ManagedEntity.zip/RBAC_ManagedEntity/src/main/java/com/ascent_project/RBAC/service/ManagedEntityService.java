package com.ascent_project.RBAC.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ascent_project.RBAC.model.ManagedEntity;
import com.ascent_project.RBAC.exception.EntityNotFoundException;
import com.ascent_project.RBAC.repository.ManagedEntityRepository;


@Service
public class ManagedEntityService implements IManagedEntityService {

    @Autowired
    private ManagedEntityRepository repo;


    @Override
    public Long saveEntity(ManagedEntity me) {
        boolean exists =repo.existsById(me.getId());
        if(exists)
        {
            return null;
        }
        Long id = repo.save(me).getId();
        return id;
    }


    @Override
    public void deleteEntity(Long id) {
       ManagedEntity me = getOneEntity(id);
        repo.delete(me);
    }


    @Override
    public ManagedEntity getOneEntity(Long id) {

        ManagedEntity me = repo.findById(id)
                .orElseThrow(()->new EntityNotFoundException(
                        new StringBuffer().append("Entity  '")
                                .append(id)
                                .append("' not exist")
                                .toString())
                );
        return me;
    }

  @Override
    public List<ManagedEntity> getAllEntity() {
        List<ManagedEntity> list = repo.findAll();
        return list;
    }



}


