package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.ReportDataSource;
import java.util.List;

public interface ReportDataSourceService {

     List<ReportDataSource> saveReportDataSource(int reportId,List<ReportDataSource> reportDataSourceList);
     List<ReportDataSource> getReportDataSource(int reportId);
     int findByReportId(int reportId);
    List<ReportDataSource> updateDatasource(int reportId, List<ReportDataSource> reportDataSourceList);
}
