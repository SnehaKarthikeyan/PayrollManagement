package com.Ascentproject.report.service.impl;

public class ReportOptionServiceImpl {
}
