package com.ascent.powerpay.rbac.util;


import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public final class ContextTracker {

    private static final ThreadLocal<Map<String, Object>> activityHolder = new ThreadLocal<>();
    private static final String DRAFT_KEY = "draft";

    private ContextTracker() {
    }

    public static void setDraftMode(boolean draft) {
        HashMap<String, Object> values = new HashMap<>();
        values.put(DRAFT_KEY, draft);
        activityHolder.set(values);
    }

    public static boolean draftMode() {
        if (!hasTrackingContext()) {
            return false;
        }
        final Map<String, Object> stateHolder = activityHolder.get();
        return (boolean) stateHolder.getOrDefault(
                DRAFT_KEY, false);
    }

    public static boolean hasTrackingContext() {
        final Map<String, Object> stateHolder = activityHolder.get();
        return stateHolder != null;
    }


    public static void reset() {
        activityHolder.remove();
    }

}
