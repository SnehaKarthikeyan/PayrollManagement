package com.ascent_project.RBAC.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PRIVILEGES")
public class Privilege {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "FUNCTION")
    private String function;

    @Column(name = "ACTION")
    private String action;

    @ManyToOne
    @JoinColumn(name = "MANAGED_ENTITY_ID")
    @OnDelete( action = OnDeleteAction.CASCADE)
    private ManagedEntity managedEntity;

}
