package com.Ascentproject.report.service;

import com.Ascentproject.report.domain.ReportPage;
import java.util.List;

public interface ReportPageService {
    List<ReportPage> saveReportPage(int reportId,List<ReportPage> reportPageList);

    List<ReportPage> getReportPage(int reportId);
}
