package com.ascent_project.RBAC.BulkHelper;

import com.ascent_project.RBAC.model.ManagedEntity;
import com.ascent_project.RBAC.model.Permission;
import com.ascent_project.RBAC.repository.ManagedEntityRepository;
import com.ascent_project.RBAC.repository.PermissionRepository;
import com.ascent_project.RBAC.service.UserRoleService;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Component
public class BulkHelperPermission {
    public static String TYPE = "text/csv";
    static String[] HEADER = { "id", "managedEntity_id", "name", "description", "valid_for" };
    @Autowired
    UserRoleService userRoleService;
    //@Autowired
      //      static
     //UserRoleRepository userRoleRepository;
  // UserRoleRepository userRoleRepository;
  //  public BulkHelper(UserRoleService  service)
   // {
    //    this.userRoleService=service;
    //}
    public static boolean hasCSVFormat(MultipartFile file) {

        if (!TYPE.equals(file.getContentType())) {
            return false;
        }

        return true;
    }

    public static List<Permission> csvToJson(InputStream is, ManagedEntityRepository managedEntityRepository, PermissionRepository permissionRepository) {
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            try (CSVParser csvParser = new CSVParser(fileReader,
                    CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim())) {

                List<Permission> permissions = new ArrayList<Permission>();

                Iterable<CSVRecord> csvRecords = csvParser.getRecords();

                for (CSVRecord csvRecord : csvRecords) {
                    Long id=Long.parseLong(csvRecord.get("Id"));
                    ManagedEntity managedEntity = managedEntityRepository.findByManagedEntityId(Long.parseLong(csvRecord.get("managed_entity_id"))).get(0);
                    Permission permission = permissionRepository.findByPermissionId(Long.parseLong(csvRecord.get("permission_id"))).get(0);
                    String name= csvRecord.get("name");
                    String description= csvRecord.get("description");
                    String valid_for= csvRecord.get("valid_for");


                    Permission individualPermission = new Permission(
                            id, managedEntity,name, description, valid_for);
                    permissions.add(individualPermission);
                }

                return permissions;
            }
        } catch (IOException e) {
            throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
        }
    }

}

