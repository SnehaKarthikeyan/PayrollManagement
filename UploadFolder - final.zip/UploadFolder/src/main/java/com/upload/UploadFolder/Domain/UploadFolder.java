package com.upload.UploadFolder.Domain;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;


@Table(name = "Upload_Folder")
@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class UploadFolder {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "CLIENT_ID")
    private int clientId;

    @Column(name = "FOLDER_NAME")
    private String folderName;

    @Column(name = "MAX_COUNT_PER_MONTH")
    private int maximumCountPerMonth;

    @Column(name = "MESSAGE_ID")
    private int messageId;

    @Column(name= "CREATED_BY_ID")
    private int createdById;

    @Column(name= "CREATED_DATE")
    private int createdDate;

    @Column(name= "CREATED_BY_IP")
    private String createdByIp;

    @Column(name= "LAST_MODIFIED_BY_ID")
    private int lastModifiedById;

    @Column(name= "LAST_MODIFIED_BY_IP")
    private String lastModifiedByIp;

    @Column(name= "LAST_MODIFIED_DATE")
    private int lastModifiedDate;

    @Column(name= "RECORD_STATUS_ID")
    private int recordStatusId;

    @Column(name= "ISACTIVE")
    private boolean isActive;

    @Column(name= "REF_ID")
    private int refId;
}

