package com.example.datasource.repository;

import com.example.datasource.domain.DatasourceOptions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DatasourceOptionsRepository extends JpaRepository<DatasourceOptions, Long> {
    DatasourceOptions findByDatasourceIdAndId(long datasourceId, long datasourceOptionsId);
    List<DatasourceOptions> findByDatasourceId(long datasourceId);
}
