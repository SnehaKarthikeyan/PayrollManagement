package com.ascent_project.RBAC;

import com.ascent_project.RBAC.model.IndividualParty;
import com.sun.istack.NotNull;
import org.junit.Assert;
import org.junit.jupiter.api.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.Assert.*;
import static org.springframework.mock.http.server.reactive.MockServerHttpRequest.delete;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class IndividualPartyTests {

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    private String getRootUrl() {
        return "http://localhost:" + port;
    }

    @AfterEach
    public void removeRecords() {
        IndividualParty[] individualParties= getIndividualParties(getStringHttpParty());
        for (IndividualParty individualParty : individualParties) {
            delete(individualParty.getId());
        }
    }

    @NotNull
    private IndividualParty getIndividualParty(String code, String name)  {
        IndividualParty individualParty = new IndividualParty();
        individualParty.setCode(code);
        individualParty.setName(name);
        return individualParty;
    }

    private IndividualParty addIndividualPartyAPI(IndividualParty individualParty) {
        HttpEntity<IndividualParty> entity = getIndividualPartyHttpEntity(individualParty);
        ResponseEntity<IndividualParty> result=this.restTemplate.postForEntity(getRootUrl() + "/user/api/v1", entity, IndividualParty.class);
        Assert.assertEquals(201,result.getStatusCodeValue());
        IndividualParty individualParty1 = result.getBody();
        return individualParty1;
    }

    private IndividualParty[] getIndividualParties(HttpEntity<String> entity) {
        ResponseEntity<IndividualParty[]> response = restTemplate.exchange(getRootUrl() + "/user/api/v1",
                HttpMethod.GET, entity, IndividualParty[].class);
        return response.getBody();
    }

    @NotNull
    private HttpEntity<String> getStringHttpParty() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("powerpayTenantId", "user_permission_test");
        return new HttpEntity<String>(null, headers);
    }

    @NotNull
    private HttpEntity<IndividualParty> getIndividualPartyHttpEntity(IndividualParty individualParty) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("powerpayTenantId", "individual_party_test");
        return new HttpEntity<>(individualParty, headers);
    }

    @Test
    public void testGetAllIndividualParty(){
        IndividualParty individualParty = getIndividualParty("code1", "name1");
        individualParty = addIndividualPartyAPI(individualParty);

        Assert.assertEquals("code1", individualParty.getCode());
        Assert.assertEquals("name1", individualParty.getName());

        individualParty = getIndividualParty("code2", "name2");
        individualParty = addIndividualPartyAPI(individualParty);

        HttpEntity<String> entity = getStringHttpParty();
        IndividualParty[] result = getIndividualParties(entity);
        Assert.assertNotNull(result);
        assertTrue(result.length > 0);

    }

    @Test
    public void testGetIndividualPartyById() {
        IndividualParty individualParty = getIndividualParty("code3","name3");
        individualParty = addIndividualPartyAPI(individualParty);
        String id = individualParty.getId();

        individualParty = restTemplate.getForObject(getRootUrl() + "/user/api/v1/individualPartyId/" + id, IndividualParty.class);
        Assert.assertNotNull(individualParty);
        Assert.assertEquals("code2", individualParty.getCode());
        Assert.assertEquals("name2", individualParty.getName());
    }

   @Test
    public void testGetIndividualPartyByCode() {

        IndividualParty individualParty = getIndividualParty("code4", "name4");
        individualParty = addIndividualPartyAPI(individualParty);
        String code = individualParty.getCode();

        individualParty = restTemplate.getForObject(getRootUrl() + "/user/api/v1/individualPartyCode/" + code, IndividualParty.class);
        Assert.assertNotNull(individualParty);
        Assert.assertEquals("code3", individualParty.getCode());
        Assert.assertEquals("name3", individualParty.getName());
    }

    @Test
    public void testDeleteIndividualPartyByCode() {
        IndividualParty individualParty = getIndividualParty("code5", "name5");
        individualParty = addIndividualPartyAPI(individualParty);
        String code = individualParty.getCode();
        markForDelete(code);
        try {
            IndividualParty individualParty1 = restTemplate.getForObject(getRootUrl() + "/user/api/v1/individualPartyCode/" + code, IndividualParty.class);
            Assert.assertNull(individualParty1);
        } catch (final HttpClientErrorException e) {
            fail("object status should have been saved.");
        }
    }

    private void markForDelete(String code) {
        restTemplate.delete(getRootUrl() + "/user/api/v1/individualPartyCode/" + code);
    }
}
