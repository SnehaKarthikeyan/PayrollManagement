package com.example.privilege;

import com.example.privilege.model.ManagedEntity;
import com.example.privilege.model.MenuPrivilege;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.google.gson.Gson;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
@AutoConfigureMockMvc
class PrivilegeTests {
	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private ObjectMapper mapper;

	@LocalServerPort
	private int port;
	private String getRootUrl()
	{
		return "http://localhost:" + port;
	}
    @BeforeEach
    public void createManagedEntity() throws Exception {
        ManagedEntity managedEntity =getManagedEntity("entityCode1",
                "entityType1", "entityName1");
        managedEntity = addManagedEntityAPI(managedEntity);
        assertNotNull(managedEntity);
        assertEquals("entityCode1", managedEntity.getCode());
        assertEquals("entityType1", managedEntity.getType());
        assertEquals("entityName1", managedEntity.getName());
    }

	private ManagedEntity addManagedEntityAPI( ManagedEntity managedEntity)  throws Exception{
		Gson gson = new Gson();
		String meStr = gson.toJson(managedEntity);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.post("/manage/managedentity" )
						.contentType(MediaType.APPLICATION_JSON)
						.content(meStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();
		ManagedEntity managedEntity1= getManagedEntity(mvcResult);
		return managedEntity1;
	}

	private ManagedEntity getManagedEntity(MvcResult mvcResult)  throws  IOException{
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), ManagedEntity.class);
	}

	@NotNull
	private ManagedEntity getManagedEntity(String code, String type, String name) {
        ManagedEntity managedEntity = new ManagedEntity();
        managedEntity.setName(name);
         managedEntity.setType(type);
        managedEntity.setCode(code);
        return managedEntity;
    }

	private List<MenuPrivilege> addAllPrivilegeAPI(List<MenuPrivilege> me) throws Exception {
		Gson gson = new Gson();
		String meStr = gson.toJson(me);
		System.out.println(meStr);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.post("/manage/privilege/managedentity/entityCode1")
						.contentType(MediaType.APPLICATION_JSON)
						.content(meStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();

		ObjectMapper mapper = new ObjectMapper();
		List<MenuPrivilege> menuPrivilegeList = mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), new TypeReference<List<MenuPrivilege>>(){});
		return menuPrivilegeList;
	}

	private MenuPrivilege updatePrivilegeByCodeAPI(MenuPrivilege me) throws Exception {
		Gson gson = new Gson();
		String meStr = gson.toJson(me);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.put("/manage/privilege/managedentity/entityCode1/privilege/" + me.getCode())
						.contentType(MediaType.APPLICATION_JSON)
						.content(meStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		MenuPrivilege menuPrivilegeResult = getPrivilege(mvcResult);
		return menuPrivilegeResult;
	}

	private MenuPrivilege updatePrivilegeByIdAPI(MenuPrivilege me) throws Exception {
		Gson gson = new Gson();
		String meStr = gson.toJson(me);
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.post("/manage/privilege/managedentity/entityCode1/privilege/" + me.getId())
						.contentType(MediaType.APPLICATION_JSON)
						.content(meStr)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();
		MenuPrivilege menuPrivilegeResult = getPrivilege(mvcResult);
		return menuPrivilegeResult;
	}

	private void updatePrivilegeByParentChildCode(String parent,String child) throws Exception {

		 this.mockMvc.perform(RestDocumentationRequestBuilders
						.put("/manage/privilege/managedentity/entityCode1/privilege/" + parent+"/"+child)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isAccepted())
				.andReturn();
	}

	private MenuPrivilege getPrivilege(MvcResult mvcResult) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(mvcResult.getResponse().getContentAsByteArray(), MenuPrivilege.class);
	}

	@Test
	public List<MenuPrivilege> testSavePrivilege() throws Exception {
		InputStream inputStream= MenuPrivilege.class.getResourceAsStream("/data/source.json");
		CollectionType collectionType = mapper.getTypeFactory().constructCollectionType(List.class, MenuPrivilege.class);
		List<MenuPrivilege> menuPrivilegeList = mapper.readValue(inputStream, collectionType);
		List<MenuPrivilege> menuPrivilegeList1=addAllPrivilegeAPI(menuPrivilegeList);
		MenuPrivilege menuPrivilege=menuPrivilegeList1.get(0);
		assertEquals("fff", menuPrivilege.getCode());
		assertEquals("file", menuPrivilege.getName());
		assertNotNull(menuPrivilege.getId());
		return menuPrivilegeList1;
	}

	private MenuPrivilege getPrivilegeById(String id) throws Exception {
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.get("/manage/privilege/managedentity/entityCode1/privilege/" + id)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
		MenuPrivilege menuPrivilege = getPrivilege(mvcResult);
		return menuPrivilege;
	}

	private MenuPrivilege getPrivilegeByCode(String code) throws Exception {
		MvcResult mvcResult = this.mockMvc.perform(RestDocumentationRequestBuilders
						.get("/manage/privilege/managedentity/entityCode1/privilege")
				.accept(MediaType.APPLICATION_JSON)
				.param("privilegeCode", code))
				.andExpect(status().isOk())
				.andReturn();
		MenuPrivilege  menuPrivilegeArray = getPrivilege(mvcResult);
		return menuPrivilegeArray;
	}

	@Test
	public void testGetAllPrivilege() throws Exception {
		List<MenuPrivilege> menuPrivilegeList= new ArrayList<>();
		menuPrivilegeList =testSavePrivilege();
		MenuPrivilege menuPrivilege=new MenuPrivilege();
		menuPrivilege=menuPrivilegeList.get(0);
		assertNotNull(menuPrivilege.getId());
		assertEquals("file",menuPrivilege.getName());
		assertEquals("fff",menuPrivilege.getCode());
		assertEquals(2,menuPrivilegeList.size());
	}

	@Test
	public void testGetPrivilegeById() throws Exception {
		List<MenuPrivilege> menuPrivilegeList= testSavePrivilege();
		MenuPrivilege menuPrivilege = menuPrivilegeList.get(0);
		String id = menuPrivilege.getId();
		menuPrivilege = getPrivilegeById(id);
		assertEquals("file",menuPrivilege.getName());
		assertEquals("fff",menuPrivilege.getCode());
		assertNotNull(id);
	}

	@Test
	public void testGetPrivilegeByCode() throws Exception {
		List<MenuPrivilege> menuPrivilegeList=testSavePrivilege();
		MenuPrivilege menuPrivilege=new MenuPrivilege();
		menuPrivilege=menuPrivilegeList.get(0);
		String code=menuPrivilege.getCode();
		menuPrivilege=getPrivilegeByCode(code);
		assertEquals("fff",menuPrivilege.getCode());
	}

	@Test
	public void testUpdatePrivilegeById() throws Exception {
		List<MenuPrivilege> menuPrivilegeList=testSavePrivilege();
		MenuPrivilege menuPrivilege=menuPrivilegeList.get(0);
		menuPrivilege.setName("file1");
		menuPrivilege.setActive(true);
		menuPrivilege.setMenuOrder(1l);
		menuPrivilege.setCode("ff2");
		menuPrivilege.setParent(null);
		String id=menuPrivilege.getId();
		menuPrivilege=updatePrivilegeByIdAPI(menuPrivilege);
		assertNotNull(menuPrivilege);
		assertEquals(id,menuPrivilege.getId());
		assertEquals("ff2", menuPrivilege.getCode());
		assertEquals("file1", menuPrivilege.getName());
	}

	@Test
	public void testUpdatePrivilegeByCode() throws Exception {
		List<MenuPrivilege> menuPrivilegeList=testSavePrivilege();
		MenuPrivilege menuPrivilege=menuPrivilegeList.get(0);
		menuPrivilege.setName("file1");
		menuPrivilege.setActive(true);
		menuPrivilege.setMenuOrder(1l);
		menuPrivilege.setParent(null);
		String code=menuPrivilege.getCode();
		menuPrivilege=updatePrivilegeByCodeAPI(menuPrivilege);
		assertNotNull(menuPrivilege);
		assertEquals(code, menuPrivilege.getCode());
		assertEquals("file1", menuPrivilege.getName());
	}

	@Test
	public void testUpdatePrivilegeByParentAndChildCode() throws Exception {
		List<MenuPrivilege> menuPrivilegeList=testSavePrivilege();
		MenuPrivilege menuPrivilege=menuPrivilegeList.get(0);
		String child=menuPrivilege.getCode();
		System.out.println(child);
		MenuPrivilege menuPrivilege1=menuPrivilegeList.get(1);
		String parent=menuPrivilege1.getCode();
		System.out.println(parent);
		updatePrivilegeByParentChildCode(parent,child);
	}

	@Test
	public void testDeletePrivilegeById() throws Exception {
		List<MenuPrivilege> menuPrivilegeList= testSavePrivilege();
		MenuPrivilege menuPrivilege=menuPrivilegeList.get(0);
		String id = menuPrivilege.getId();
		delete(id);
		try {
			this.mockMvc.perform(RestDocumentationRequestBuilders
							.get("/manage/privilege/managedentity/entityCode1/privilege/"+ id)
							.accept(MediaType.APPLICATION_JSON))
					.andExpect(status().isBadRequest());
		} catch (final Exception e) {
			fail("object status should have been saved.");
		}
	}

	@Test
	public void testDeletePrivilegeByCode() throws Exception {
		List<MenuPrivilege> menuPrivilegeList=testSavePrivilege();
		MenuPrivilege menuPrivilege=menuPrivilegeList.get(0);
		String code = menuPrivilege.getCode();
		markForDelete(code);
		try {
			this.mockMvc.perform(RestDocumentationRequestBuilders
							.get("/manage/privilege/managedentity/entityCode1/privilege")
							.accept(MediaType.APPLICATION_JSON)
							.param("privilegeCode",code))
					.andExpect(status().isBadRequest());
		}
		catch (final HttpClientErrorException e) {
			fail("object status should have been saved.");
		}
	}

	private void markForDelete(String code) throws Exception {
		this.mockMvc.perform(RestDocumentationRequestBuilders
						.delete("/manage/privilege/managedentity/entityCode1/privilege")
						.param("privilegeCode",code))
				.andExpect(status().isOk());
	}

	private void delete(String id) throws Exception {
		this.mockMvc.perform(RestDocumentationRequestBuilders
						.delete("/manage/privilege/managedentity/entityCode1/privilegeId/internal/" + id))
				.andExpect(status().isOk());
	}
}