package com.Ascentproject.report.repository;

import com.Ascentproject.report.domain.DatasourceOptions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DatasourceOptionsRepository extends JpaRepository<DatasourceOptions, Long> {
}
