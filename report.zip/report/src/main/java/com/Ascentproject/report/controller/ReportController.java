package com.Ascentproject.report.controller;

import com.Ascentproject.report.domain.Report;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.ReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/report", "/manage/report"})
public class ReportController {

    @Autowired
    private ReportService reportService;

    @CrossOrigin
    @PostMapping("/tenant/{tenantId}")
    public ResponseEntity<?> savePrivilege(@PathVariable int tenantId, @RequestBody Report report){
        ResponseEntity<?> responseEntity = null;
        try{

            Report reports = reportService.saveReport(tenantId,report);
            if(reports.getId()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save report",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<Report>(
                    reports, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save report ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PostMapping("/tenant/{tenantId}/report/{reportId}")
    public ResponseEntity<?> updateOrCopyById(@RequestBody Report report, @PathVariable int tenantId,@PathVariable int reportId) throws NotFoundException {
        ResponseEntity<?> resp = null;
        try{
            Report report1 = reportService.findReportById(tenantId,reportId);
            if(report1==null)
                resp = new ResponseEntity<String>("Report doesn't exist", HttpStatus.BAD_REQUEST);

            Report report2 = reportService.updateReport(report,report1);
            resp = new ResponseEntity<Report>(report2, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }

    @GetMapping("/tenant/{tenantId}/report")
    public ResponseEntity<?> getAllReports(@PathVariable("tenantId") int tenantId,
                                              @RequestParam(required = false) String reportName) throws NotFoundException {
        ResponseEntity<?> resp=null;

        if(reportName == null || reportName.length() == 0) {
            List<Report> reportList = reportService.getReports(tenantId);
            try{
                resp= new ResponseEntity<List<Report>>(
                        reportList, HttpStatus.OK);
            }
            catch (Exception exception){
                log.error(exception.getMessage(),exception);
                resp = new ResponseEntity<String>("Report doesn't exist", HttpStatus.BAD_REQUEST);
            }
        }
        else{
            resp= getReportByName(tenantId,reportName);
        }
        return resp;
    }



    @GetMapping("/tenant/{tenantId}/reportId/internal/{reportId}")
    public ResponseEntity<?> getReportById(@PathVariable  int tenantId ,@PathVariable int reportId ) {
        ResponseEntity<?> resp=null;
        try {

            Report report=reportService.findReportById(tenantId,reportId);
            if(report==null)
            {
                resp = new ResponseEntity<String>(
                        "Unable to get report ",
                        HttpStatus.BAD_REQUEST);

            }
            resp= new ResponseEntity<Report>(report, HttpStatus.OK);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>(
                    "Unable to get report",
                    HttpStatus.BAD_REQUEST);
        }
        return resp;
    }

    @NotNull
    public ResponseEntity<?> getReportByName(@PathVariable int tenantId,@RequestParam(required = false)String reportName) {
        ResponseEntity<?> resp=null;
        try {

            Report report=reportService.findReportByName(tenantId,reportName);
            if(report.getName()==null)
            {
                resp = new ResponseEntity<String>(
                        "Unable to get Report ",
                        HttpStatus.BAD_REQUEST);

            }
            resp= new ResponseEntity<Report>(report, HttpStatus.OK);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>(
                    "Unable to get Report",
                    HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


    @DeleteMapping("/tenant/{tenantId}/report")
    public ResponseEntity<String> deleteOnePrivilege(@PathVariable  int tenantId,@RequestParam String reportCode){

        ResponseEntity<String> responseEntity= null;
        try {
            reportService.deleteOneReportByCode(tenantId,reportCode);
            responseEntity= new ResponseEntity<String> (
                    "Report '"+reportCode+"' deleted",HttpStatus.OK);

        }
        catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Report", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/tenant/{tenantId}/reportId/internal/{reportId}")
    public ResponseEntity<String> deleteOneReportById(@PathVariable int tenantId,@PathVariable int reportId){
        ResponseEntity<String> responseEntity= null;
        try {
           reportService.deleteOneReportById(tenantId,reportId);
            responseEntity= new ResponseEntity<String> (
                    "privilege  '"+reportId+"' deleted",HttpStatus.OK);

        }
        catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity= new ResponseEntity<String>(
                    "Unable to delete Privilege", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}



