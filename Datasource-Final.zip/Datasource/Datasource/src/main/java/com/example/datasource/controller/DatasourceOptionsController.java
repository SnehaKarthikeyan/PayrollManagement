package com.example.datasource.controller;

import com.example.datasource.domain.DatasourceOptions;
import com.example.datasource.service.DatasourceOptionsService;
import com.example.datasource.service.DatasourceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/datasourceoptions","/manage/datasourceoptions"})
public class DatasourceOptionsController {
    @Autowired
    private DatasourceOptionsService datasourceOptionsService;

    @Autowired
    private DatasourceService datasourceService;

    @PostMapping("/{datasourceCode}")
    public ResponseEntity<?> saveDatasourceOptions(@PathVariable("datasourceCode") String datasourceCode, @RequestBody List<DatasourceOptions> datasourceOptions) {
        ResponseEntity<?> responseEntity = null;
        try {
            for(DatasourceOptions datasourceOptions1: datasourceOptions) {
                datasourceOptionsService.saveDatasourceOptions(datasourceCode, datasourceOptions1);
            }
            responseEntity = new ResponseEntity<List<DatasourceOptions>>(datasourceOptions, HttpStatus.CREATED);
        } catch(Exception e) {
            log.debug("Unable to save Datasource Options");
            responseEntity = new ResponseEntity<List<DatasourceOptions>>(datasourceOptions, HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{datasourceCode}/search")
    public ResponseEntity<?> getDatasourceOptionsById(@PathVariable("datasourceCode") String datasourceCode, @RequestParam("id") long datasourceOptionsId) {
        ResponseEntity<?> responseEntity= null;
        try {
            DatasourceOptions datasourceOptions= datasourceOptionsService.getDatasourceOptionsById(datasourceCode, datasourceOptionsId);
            responseEntity = new ResponseEntity<DatasourceOptions>(datasourceOptions, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource Options");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource Options", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("/{datasourceCode}")
    public ResponseEntity<?> getAllDatasourceOptions(@PathVariable("datasourceCode") String datasourceCode) {
        ResponseEntity<?> responseEntity= null;
        try {
            List<Object> datasourceOptions = datasourceOptionsService.getAllDatasourceOptions(datasourceCode);
            responseEntity= new ResponseEntity<List<Object>>(datasourceOptions,HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to get Datasource Options");
            responseEntity = new ResponseEntity<String>("Unable to get Datasource Options", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @PutMapping("/{datasourceCode}/{datasourceOptionsId}")
    public ResponseEntity<?> updateDatasourceOptions(@PathVariable("datasourceCode") String datasourceCode,
                                                     @PathVariable("datasourceOptionsId") long datasourceOptionsId,
                                                     @RequestBody DatasourceOptions datasourceOptions) {
        ResponseEntity<?> responseEntity = null;
        try {
            DatasourceOptions datasourceOptions1 = datasourceOptionsService.updateDatasourceOptions(datasourceCode, datasourceOptionsId, datasourceOptions);
            responseEntity = new ResponseEntity<DatasourceOptions>(datasourceOptions1, HttpStatus.OK);
        } catch(Exception e) {
            log.debug("Unable to update Datasource Options");
            responseEntity = new ResponseEntity<String>("Unable to update Datasource Options", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @DeleteMapping("/{datasourceCode}")
    public ResponseEntity<?> deleteDatasourceOptionsById(@PathVariable("datasourceCode") String datasourceCode, @RequestParam("id") long datasourceOptionsId) {
        ResponseEntity<?> responseEntity= null;
        try {
            datasourceOptionsService.deleteDatasourceOptionsById(datasourceCode, datasourceOptionsId);
            responseEntity = new ResponseEntity<String> ("Datasource Options '"+datasourceOptionsId+"' deleted", HttpStatus.OK);
        } catch (Exception e) {
            log.debug("Unable to delete Datasource Options");
            responseEntity = new ResponseEntity<String>("Unable to delete Datasource Options", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
