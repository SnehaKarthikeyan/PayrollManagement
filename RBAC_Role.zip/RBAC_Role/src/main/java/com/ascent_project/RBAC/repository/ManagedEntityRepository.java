package com.ascent_project.RBAC.repository;


import com.ascent_project.RBAC.model.ManagedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManagedEntityRepository extends JpaRepository<ManagedEntity, Long> {

}
