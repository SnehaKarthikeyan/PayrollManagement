package com.upload.UploadFolder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadFolderApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadFolderApplication.class, args);
	}

}
