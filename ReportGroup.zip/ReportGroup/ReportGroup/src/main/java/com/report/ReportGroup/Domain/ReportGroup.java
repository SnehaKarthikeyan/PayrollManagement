package com.report.ReportGroup.Domain;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;


@Table(name = "REPORT_GROUP")
@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityListeners(AuditingEntityListener.class)
@Slf4j
public class ReportGroup {
        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private int id;

        @Column(name = "PARENT_ID")
        private int parentId;

        @Column(name = "CODE")
        private String code;

        @Column(name = "NAME")
        private String name;

        @Column(name = "REPORT_ID")
        private int reportId;

        @Column(name= "SORT_ORDER")
        private int sortOrder;

        @Column(name= "EXCEL_PASSWORD")
        private String excelPassword;

        @Column(name= "EXCEL_SHEET_PASSWORD")
        private String excelSheetPassword;

        @Column(name= "REPORT_NAME_FORMAT")
        private String reportNameFormat;

        @Column(name= "INCLUDE_BATCH")
        private byte includeBatch;

        @Column(name= "INCLUDE_DATA_RANGE")
        private byte includeDataRange;

        @Column(name= "ENABLE_DATABACKUP")
        private byte enableDataBackup;

        @Column(name= "RECORD_STATUS_ID")
        private int recordStatusId;

        @Column(name= "ISACTIVE")
        private boolean isActive;
}

