package com.ascent.powerpay.rbac.service.serviceImpl;

import com.ascent.powerpay.rbac.domain.IndividualParty;
import com.ascent.powerpay.rbac.domain.InvolvementIdentification;
import com.ascent.powerpay.rbac.domain.ManagedEntity;
import com.ascent.powerpay.rbac.exception.NotFoundException;
import com.ascent.powerpay.rbac.repository.IndividualPartyRepository;
import com.ascent.powerpay.rbac.repository.InvolvementIdentificationRepository;
import com.ascent.powerpay.rbac.repository.ManagedEntityRepository;
import com.ascent.powerpay.rbac.service.InvolvementIdentificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class InvolvementIdentificationServiceImpl implements InvolvementIdentificationService
{

    @Autowired
    private InvolvementIdentificationRepository involvementIdentificationRepository;

    @Autowired
    private ManagedEntityRepository managedEntityRepository;

    @Autowired
    private IndividualPartyRepository individualPartyRepository;

    public InvolvementIdentification saveInvolvementIdentification(String managedEntityCode, String userCode,
                                                                   InvolvementIdentification involvementIdentification) throws NotFoundException {
        boolean exists = false;
        if(involvementIdentification.getId() != null)
        {
            exists = involvementIdentificationRepository.existsById(involvementIdentification.getId());
        }
        if(exists)
        {
            return null;
        }
        ManagedEntity managedEntity = getManagedEntity(managedEntityCode);
        involvementIdentification.setManagedEntityId(managedEntity.getId());
        IndividualParty individualParty = getIndividualParty(userCode);
        involvementIdentification.setIndividualPartyId(individualParty.getId());
        involvementIdentification.setActive(true);
        InvolvementIdentification involvementIdentification1 = involvementIdentificationRepository.
                save(involvementIdentification);
        return involvementIdentification1;
    }

    private ManagedEntity getManagedEntity(String managedEntityCode) throws NotFoundException {
        ManagedEntity me = managedEntityRepository.findByCode(managedEntityCode);
        if(me == null) throw new NotFoundException(managedEntityCode + " Managed Entity Not Found");
        return me;
    }

    private IndividualParty getIndividualParty(String userCode) throws NotFoundException {
        IndividualParty me = individualPartyRepository.findByCode(userCode);
        if(me == null) throw new NotFoundException(userCode + " User Not Found");
        return me;
    }

    public InvolvementIdentification getInvolvementIdentificationById(String managedEntityCode,String userCode,String involvementIdentificationId) throws NotFoundException {
        String managedEntityId = null;
        String individualPartyId = null;
        InvolvementIdentification involvementIdentification = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        IndividualParty ip = getIndividualParty(userCode);
        if(me != null && ip != null) {
            managedEntityId = me.getId();
            individualPartyId = ip.getId();
        involvementIdentification = involvementIdentificationRepository.
                findByManagedEntityIdAndIndividualPartyIdAndId(managedEntityId,individualPartyId,involvementIdentificationId);
        } else {
            log.info("Involvement Identification object not found for {}, {} & {}", managedEntityCode, userCode, involvementIdentificationId);
        }
        return involvementIdentification;
    }

    public InvolvementIdentification getInvolvementIdentificationByCode(String managedEntityCode, String userCode, String involvementIdentificationCode) throws NotFoundException {
        String managedEntityId = null;
        String individualPartyId = null;
        InvolvementIdentification involvementIdentification = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        IndividualParty ip = getIndividualParty(userCode);
        if(me != null && ip != null) {
            managedEntityId = me.getId();
            individualPartyId = ip.getId();
        involvementIdentification = involvementIdentificationRepository.
                findByManagedEntityIdAndIndividualPartyIdAndCode(managedEntityId,individualPartyId,involvementIdentificationCode);
        } else {
            log.info("Involvement Identification object not found for {}, {} & {}", managedEntityCode, userCode, involvementIdentificationCode);
        }
        return involvementIdentification;
    }

    public List<InvolvementIdentification> getAllInvolvementIdentification(String managedEntityCode,String userCode) throws NotFoundException {
        String managedEntityId = null;
        String individualPartyId = null;
        List<InvolvementIdentification> list = null;
        ManagedEntity me = getManagedEntity(managedEntityCode);
        IndividualParty ip = getIndividualParty(userCode);
        if(me != null && ip != null) {
            managedEntityId = me.getId();
            individualPartyId = ip.getId();
        list = involvementIdentificationRepository.findAllByManagedEntityIdAndIndividualPartyId(managedEntityId,individualPartyId);
        } else {
            log.info("Managed Entity and User object not found for {} & {}", managedEntityCode, userCode);
        }
        return list;
    }

    public InvolvementIdentification updateInvolvementIdentification(String managedEntityCode, String userCode,
                                                                     String involvementIdentificationCode,
                                                                     InvolvementIdentification
                                                                             involvementIdentification) throws NotFoundException {
        ManagedEntity managedEntity = getManagedEntity(managedEntityCode);
        IndividualParty individualParty = getIndividualParty(userCode);
        InvolvementIdentification involvementIdentification1 = involvementIdentificationRepository.
                findByManagedEntityIdAndIndividualPartyIdAndCode(managedEntity.getId(),individualParty.getId(),involvementIdentificationCode);
        involvementIdentification1.setCode(involvementIdentification.getCode());
        involvementIdentification1.setName(involvementIdentification.getName());
        involvementIdentification1.setActive(true);
        return involvementIdentificationRepository.save(involvementIdentification1);
    }

    public void deleteInvolvementIdentificationById(String managedEntityCode, String userCode, String involvementIdentificationId)
            throws NotFoundException {
        InvolvementIdentification involvementIdentification =
                getInvolvementIdentificationById(managedEntityCode,userCode,involvementIdentificationId);
        involvementIdentificationRepository.delete(involvementIdentification);
    }

    public void deleteInvolvementIdentificationByCode(String managedEntityCode, String userCode, String involvementIdentificationCode)
            throws NotFoundException
    {
        InvolvementIdentification involvementIdentification =
                getInvolvementIdentificationByCode(managedEntityCode, userCode, involvementIdentificationCode);
        involvementIdentification.setActive(false);
        involvementIdentificationRepository.save(involvementIdentification);
    }

}
