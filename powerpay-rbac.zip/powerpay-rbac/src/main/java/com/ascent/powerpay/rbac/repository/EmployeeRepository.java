package com.ascent.powerpay.rbac.repository;

import com.ascent.powerpay.rbac.domain.Employee;
import com.ascent.powerpay.rbac.util.SearchCriteria;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

@Repository
@Transactional
public class EmployeeRepository extends AbstractGenericRepository {

    @Override
    public List<?> searchEntity(List<SearchCriteria> params) {
        CriteriaQuery<?> query = getCriteraQuery(entityManager, params, Employee.class);

        List<?> result = entityManager.createQuery(query).getResultList();
        return result;
    }

    @Override
    Object processAggregateQuery(String queryString) {
        return null;
    }

    @Override
    List<Object> processQuery(String queryString) {
        return entityManager.createNativeQuery(queryString, Employee.class).getResultList();
    }

}
