package com.ascent_project.RBAC.service;

import com.ascent_project.RBAC.exception.RoleNotFoundException;
import com.ascent_project.RBAC.model.Role;
import com.ascent_project.RBAC.repository.Role_Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Role_Service {

    @Autowired
    private Role_Repository repository;


    public void deleteRole(Long id) {
        Role role = getOneRole(id);
        repository.delete(role);
    }

    public List<Role> getAllRoles() {
        List<Role> list = repository.findAll();

        return list;
    }

    public Role getOneRole(Long id) {
        Role role = repository.findById(id)
                .orElseThrow(()->new RoleNotFoundException(
                        new StringBuffer().append("Product  '")
                                .append(id)
                                .append("' not exist")
                                .toString())
                );
        return role;
    }

    public Long saveRole(Role role) {
        boolean exists = repository.existsById(role.getId());
        if(exists){
            return null;
        }
        Long id = repository.save(role).getId();
        return id;
    }


}
