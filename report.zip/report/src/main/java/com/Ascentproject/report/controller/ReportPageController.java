package com.Ascentproject.report.controller;

import com.Ascentproject.report.domain.ReportPage;
import com.Ascentproject.report.exception.NotFoundException;
import com.Ascentproject.report.service.ReportPageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping(path = {"/api/v1/reportpage", "/manage/reportpage"})

public class ReportPageController {
    @Autowired
    private ReportPageService reportPageService;

    @CrossOrigin
    @PostMapping("reportId/{reportId}")
    public ResponseEntity<?> saveReportPage(@PathVariable int reportId,@RequestBody List<ReportPage> reportPageList){
        ResponseEntity<?> responseEntity = null;
        try{
            List<ReportPage> reportPageList1= reportPageService.saveReportPage(reportId,reportPageList);
            if(reportPageList1.size()==0)
                responseEntity = new ResponseEntity<String>(
                        "Unable to save Report Page ",
                        HttpStatus.BAD_REQUEST);

            responseEntity= new ResponseEntity<List<ReportPage>>(
                    reportPageList1, HttpStatus.CREATED);
        } catch (Exception exception) {
            log.error(exception.getMessage(),exception);
            responseEntity = new ResponseEntity<String>(
                    "Unable to save Report Page ",
                    HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }

    @GetMapping("reportId/{reportId}")
    public ResponseEntity<?> getAllReportPage(@PathVariable int reportId) throws NotFoundException {
        ResponseEntity<?> resp=null;
        try{
            List<ReportPage> reportPageList = reportPageService.getReportPage(reportId);
            resp= new ResponseEntity<List<ReportPage>>(
                    reportPageList, HttpStatus.OK);
        }
        catch (Exception exception){
            log.error(exception.getMessage(),exception);
            resp = new ResponseEntity<String>("Report Page doesn't exist", HttpStatus.BAD_REQUEST);
        }
        return resp;
    }


}
